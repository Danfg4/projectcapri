import { createDatabase } from '../../src/server/db/database.ts';
import { MemoryEngine } from '../../src/server/core/memory-engine.ts';

interface WriterArgs {
  dbPath: string;
  writerId: number;
  uniqueWrites: number;
  sharedWrites: number;
}

const [dbPath, writerIdText, uniqueWritesText, sharedWritesText] = process.argv.slice(2);
if (!dbPath || !writerIdText || !uniqueWritesText || !sharedWritesText) {
  throw new Error('Argumentos de worker incompletos.');
}
const input: WriterArgs = {
  dbPath,
  writerId: Number(writerIdText),
  uniqueWrites: Number(uniqueWritesText),
  sharedWrites: Number(sharedWritesText),
};
const db = createDatabase(input.dbPath);

try {
  const memory = new MemoryEngine(db);
  for (let index = 0; index < input.uniqueWrites; index += 1) {
    memory.upsertFact({
      category: 'project',
      key: `writer_${input.writerId}_${index}`,
      content: `Registro concorrente exclusivo do processo ${input.writerId}, item ${index}.`,
      userConfirmed: true,
    });
  }
  for (let index = 0; index < input.sharedWrites; index += 1) {
    memory.upsertFact({
      category: 'project',
      key: 'shared_concurrent_key',
      content: 'Conteúdo idempotente compartilhado entre processos SQLite independentes.',
      userConfirmed: true,
    });
  }
  process.stdout.write(`${JSON.stringify({ ok: true, writerId: input.writerId, uniqueWrites: input.uniqueWrites, sharedWrites: input.sharedWrites })}\n`);
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.stack ?? error.message : String(error)}\n`);
  process.exitCode = 1;
} finally {
  db.close();
}
