import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterEach, describe, expect, it } from 'vitest';
import { createDatabase } from '../../src/server/db/database.ts';
import { MemoryEngine } from '../../src/server/core/memory-engine.ts';

describe('Certificação de concorrência SQLite — processos e conexões independentes', () => {
  let tempDir: string | undefined;

  afterEach(() => {
    if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
    tempDir = undefined;
  });

  it('serializa escritores em processos distintos sem perder dados nem duplicar a chave compartilhada', async () => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-sqlite-processes-'));
    const dbPath = path.join(tempDir, 'concurrency.db');

    // Initialize schema/migrations once before independent processes race to write.
    const initial = createDatabase(dbPath);
    initial.close();

    const processCount = 4;
    const uniqueWritesPerProcess = 12;
    const sharedWritesPerProcess = 30;
    const writerPath = fileURLToPath(new URL('./sqlite-concurrency-writer.ts', import.meta.url));

    const runWriter = (writerId: number) => new Promise<{ ok: boolean; writerId: number; uniqueWrites: number; sharedWrites: number }>((resolve, reject) => {
      const child = spawn(process.execPath, [writerPath, dbPath, String(writerId), String(uniqueWritesPerProcess), String(sharedWritesPerProcess)], {
        cwd: process.cwd(),
        env: process.env,
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      let stdout = '';
      let stderr = '';
      if (!child.stdout || !child.stderr) {
        child.kill();
        reject(new Error('Não foi possível capturar stdout/stderr do processo escritor.'));
        return;
      }
      child.stdout.setEncoding('utf8');
      child.stderr.setEncoding('utf8');
      child.stdout.on('data', (chunk: string) => { stdout += chunk; });
      child.stderr.on('data', (chunk: string) => { stderr += chunk; });
      child.once('error', reject);
      child.once('close', (code, signal) => {
        if (code !== 0) {
          reject(new Error(`Processo escritor ${writerId} terminou com código ${code}, sinal ${signal ?? 'nenhum'}: ${stderr.slice(-2000)}`));
          return;
        }
        try {
          const result = JSON.parse(stdout.trim().split('\n').at(-1) ?? '') as { ok: boolean; writerId: number; uniqueWrites: number; sharedWrites: number };
          if (!result.ok || result.writerId !== writerId) throw new Error('Resultado do processo escritor inválido.');
          resolve(result);
        } catch (error) {
          reject(error);
        }
      });
    });

    const settled = await Promise.allSettled(Array.from({ length: processCount }, (_, index) => runWriter(index + 1)));
    const rejected = settled.filter((item): item is PromiseRejectedResult => item.status === 'rejected');
    if (rejected.length) {
      throw new AggregateError(rejected.map((item) => item.reason), 'Um ou mais processos SQLite concorrentes falharam.');
    }
    expect(settled).toHaveLength(processCount);

    const db = createDatabase(dbPath);
    try {
      const memory = new MemoryEngine(db);
      const sharedFacts = memory.listFacts(false).filter((fact) => fact.key === 'shared_concurrent_key' && fact.status === 'active');
      const uniqueFacts = memory.listFacts(false).filter((fact) => fact.key.startsWith('writer_') && fact.status === 'active');
      const integrity = db.prepare('PRAGMA integrity_check').get() as { integrity_check: string };

      expect(sharedFacts).toHaveLength(1);
      expect(sharedFacts[0].content).toContain('idempotente compartilhado');
      expect(uniqueFacts).toHaveLength(processCount * uniqueWritesPerProcess);
      expect(integrity.integrity_check).toBe('ok');
    } finally {
      db.close();
    }
  }, 45_000);
});
