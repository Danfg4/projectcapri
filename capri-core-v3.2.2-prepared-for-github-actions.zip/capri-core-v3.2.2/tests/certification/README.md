# Testes adicionais de certificação

`sqlite-concurrency.test.ts` acrescenta um teste de concorrência real com quatro processos Bun e conexões independentes `better-sqlite3` sobre o mesmo arquivo SQLite. Cada processo executa gravações exclusivas e disputa a mesma chave idempotente. O teste confere a quantidade de registros, unicidade da chave compartilhada e `PRAGMA integrity_check`.

O processo auxiliar importa o mesmo `createDatabase` e `MemoryEngine` do projeto; não simula SQLite nem substitui o driver real. O teste ainda precisa ser executado no GitHub Actions com Bun 1.4.5, porque o ambiente de edição atual não possui Bun. Qualquer incompatibilidade de subprocessos/native addon ou falha de lock/timeout deve aparecer como falha real no relatório.
