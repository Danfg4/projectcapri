import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest';
import Database from 'better-sqlite3';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { ModelDefinition, ProviderId } from '../src/core/types.ts';
import {
  AdapterExecutionError,
  type AdapterExecuteInput,
  type AdapterExecuteOutput,
  type ProviderAdapter,
} from '../src/server/adapters/base.ts';
import { CapriCoreOrchestrator } from '../src/server/core/orchestrator.ts';
import { createDatabase } from '../src/server/db/database.ts';
import { QuotaController } from '../src/server/core/quota-controller.ts';
import { GeminiAdapter } from '../src/server/adapters/gemini.adapter.ts';

function createStubAdapter(
  provider: ProviderId,
  options: {
    configured: boolean;
    handler?: (input: AdapterExecuteInput) => Promise<AdapterExecuteOutput>;
  },
): ProviderAdapter {
  return {
    provider,
    isConfigured: () => options.configured,
    async listModels(): Promise<string[]> {
      if (!options.configured) return [];
      const catalogs: Record<ProviderId, string[]> = {
        gemini: ['gemini-3.1-flash-lite', 'gemini-3.8-flash'],
        groq: ['llama-3.1-8b-instant', 'llama-3.3-70b-versatile'],
        openai: ['gpt-4o-mini', 'gpt-4o'],
        anthropic: ['claude-haiku-5-5', 'claude-opus-5-5'],
        deepseek: ['deepseek-flash', 'deepseek-v4-pro'],
        xai: ['latest', 'grok-420-reasoning'],
      };
      return catalogs[provider];
    },
    async execute(input: AdapterExecuteInput): Promise<AdapterExecuteOutput> {
      if (!options.configured) {
        throw new AdapterExecutionError({
          provider,
          errorType: 'missing_key',
          retryable: false,
          message: `Chave ausente para ${provider}`,
        });
      }
      if (options.handler) {
        return options.handler(input);
      }
      return {
        text: `Resposta simulada em teste unitário por ${input.model.displayName}`,
        inputTokens: 120,
        outputTokens: 45,
        totalTokens: 165,
        latencyMs: 42,
        rawModelUsed: input.model.modelName,
      };
    },
  };
}

function buildAdapters(overrides: Partial<Record<ProviderId, ProviderAdapter>> = {}) {
  const base: Record<ProviderId, ProviderAdapter> = {
    gemini: createStubAdapter('gemini', { configured: true }),
    groq: createStubAdapter('groq', { configured: false }),
    openai: createStubAdapter('openai', { configured: false }),
    anthropic: createStubAdapter('anthropic', { configured: false }),
    deepseek: createStubAdapter('deepseek', { configured: false }),
    xai: createStubAdapter('xai', { configured: false }),
  };
  return { ...base, ...overrides };
}

describe('Capri Core — Multi-LLM Orchestration Engine', () => {
  let db: ReturnType<typeof createDatabase>;

  beforeEach(() => {
    db = createDatabase(':memory:');
  });

  afterEach(() => {
    db.close();
  });

  it('1. Classifica intenções corretamente e equilibra recursos entre modelos econômicos e avançados', async () => {
    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters(),
    });

    const simpleResult = await orchestrator.orchestrate({
      prompt: 'Oi, resuma em uma frase o que é HTTP.',
    });

    expect(simpleResult.ok).toBe(true);
    expect(simpleResult.trace.intent).toBe('quick_summary');
    expect(simpleResult.trace.finalModelId).toBe('gemini/gemini-3.1-flash-lite');

    const codingResult = await orchestrator.orchestrate({
      prompt:
        'Escreva uma arquitetura TypeScript com função async para validar webhook e explicar os trade-offs de segurança passo a passo.',
      sessionId: simpleResult.sessionId,
    });

    expect(codingResult.ok).toBe(true);
    expect(['coding', 'complex_reasoning']).toContain(codingResult.trace.intent);
    expect(codingResult.trace.finalModelId).toBe('gemini/gemini-3.8-flash');
  });

  it('2. Respeita estritamente a prioridade manual do usuário sem substituir silenciosamente', async () => {
    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters(),
    });

    // Groq não configurado: seleção manual sem fallback autorizado deve informar claramente a limitação
    const blocked = await orchestrator.orchestrate({
      prompt: 'Explique recursão.',
      routingMode: 'manual',
      requestedModelId: 'groq/llama-3.3-70b-versatile',
      allowFallbackOnManual: false,
    });

    expect(blocked.ok).toBe(false);
    expect(blocked.trace.finalStatus).toBe('blocked');
    expect(blocked.error?.code).toBe('NO_COMPATIBLE_MODEL_AVAILABLE');
    expect(blocked.error?.message).toContain('GROQ_API_KEY');

    // Seleção manual para modelo econômico mesmo em prompt complexo deve ser respeitada
    const forced = await orchestrator.orchestrate({
      prompt: 'Analise a arquitetura distribuída e trade-offs de consistência eventual.',
      routingMode: 'manual',
      requestedModelId: 'gemini/gemini-3.1-flash-lite',
    });

    expect(forced.ok).toBe(true);
    expect(forced.trace.finalModelId).toBe('gemini/gemini-3.1-flash-lite');
  });

  it('3. Controla cotas RPM/RPD antes de encaminhar e evita esgotar modelos sem limite', async () => {
    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters(),
    });

    // Limita gemini-3.1-flash-lite a 1 requisição/minuto
    orchestrator.modelRegistry.updateModel('gemini/gemini-3.1-flash-lite', {
      rpmLimit: 1,
    });

    const first = await orchestrator.orchestrate({ prompt: 'Olá, tudo bem?' });
    expect(first.ok).toBe(true);
    expect(first.trace.finalModelId).toBe('gemini/gemini-3.1-flash-lite');

    // Segunda chamada simples no mesmo minuto deve detectar cota esgotada no flash-lite e rotear para gemini-3.8-flash
    const second = await orchestrator.orchestrate({ prompt: 'Olá novamente!' });
    expect(second.ok).toBe(true);
    expect(second.trace.finalModelId).toBe('gemini/gemini-3.8-flash');
    const flashEval = second.trace.candidates.find(
      (c) => c.modelId === 'gemini/gemini-3.1-flash-lite',
    );
    expect(flashEval?.eligible).toBe(false);
    expect(flashEval?.availability).toBe('quota_exhausted');
  });

  it('4. Executa fallback automático limitado preservando memória compartilhada entre modelos', async () => {
    let capturedSystemPrompt = '';
    let groqSystemPrompt = '';
    let capturedHistoryLength = 0;

    const groqFailing = createStubAdapter('groq', {
      configured: true,
      handler: async (input) => {
        groqSystemPrompt = input.systemInstruction;
        throw new AdapterExecutionError({
          provider: 'groq',
          errorType: 'rate_limit',
          retryable: true,
          statusCode: 429,
          message: '429 Too Many Requests no Groq',
        });
      },
    });

    const geminiCapturing = createStubAdapter('gemini', {
      configured: true,
      handler: async (input) => {
        capturedSystemPrompt = input.systemInstruction;
        capturedHistoryLength = input.history.length;
        return {
          text: 'Atendido pelo Gemini após fallback do Groq.',
          inputTokens: 200,
          outputTokens: 60,
          totalTokens: 260,
          latencyMs: 95,
          rawModelUsed: input.model.modelName,
        };
      },
    });

    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters({ groq: groqFailing, gemini: geminiCapturing }),
    });

    // Configura Groq 70B com prioridade máxima e Gemini 3.8 Flash como fallback secundário
    orchestrator.modelRegistry.updateModel('groq/llama-3.3-70b-versatile', { priority: 100 });
    orchestrator.modelRegistry.updateModel('gemini/gemini-3.8-flash', { priority: 60 });

    const res = await orchestrator.orchestrate({
      prompt: 'Lembre que meu projeto usa TypeScript estrito.\nAgora escreva uma função TypeScript para somar dois números.',
      maxFallbackAttempts: 2,
    });

    expect(res.ok).toBe(true);
    expect(res.extractedMemories.length).toBeGreaterThanOrEqual(1);
    expect(res.trace.selectedModelId).toBe('groq/llama-3.3-70b-versatile');
    expect(res.trace.finalModelId).toBe('gemini/gemini-3.8-flash');
    expect(res.trace.fallbackAttempts).toHaveLength(2);
    expect(res.trace.fallbackAttempts[0].status).toBe('failed');
    expect(res.trace.fallbackAttempts[1].status).toBe('success');
    expect(capturedSystemPrompt).toContain('meu projeto usa TypeScript estrito');
    expect(groqSystemPrompt).toBe(capturedSystemPrompt);
    expect(capturedHistoryLength).toBe(0);
  });

  it('5. Nunca simula respostas quando nenhum provedor possui chave configurada', async () => {
    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters({
        gemini: createStubAdapter('gemini', { configured: false }),
      }),
    });

    const result = await orchestrator.orchestrate({
      prompt: 'Explique o que é uma API REST.',
    });

    expect(result.ok).toBe(false);
    expect(result.answer).toBeNull();
    expect(result.trace.finalStatus).toBe('blocked');
    expect(result.error?.message).toContain('GEMINI_API_KEY');
    expect(result.trace.selectionReason).not.toContain('Contexto não montado');
  });

  it('6. Persiste memória compartilhada e histórico de sessão entre trocas explícitas de modelo', async () => {
    const seenPrompts: string[] = [];
    const seenHistoryCounts: number[] = [];

    const geminiInspector = createStubAdapter('gemini', {
      configured: true,
      handler: async (input) => {
        seenPrompts.push(input.systemInstruction);
        seenHistoryCounts.push(input.history.length);
        return {
          text: `Respondido por ${input.model.modelName}`,
          inputTokens: 90,
          outputTokens: 30,
          totalTokens: 120,
          latencyMs: 50,
          rawModelUsed: input.model.modelName,
        };
      },
    });

    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters({ gemini: geminiInspector }),
    });

    orchestrator.sharedMemory.upsertFact({
      category: 'identity',
      key: 'idioma_preferido',
      content: 'Responder sempre em português do Brasil.',
      importance: 9,
    });

    const turn1 = await orchestrator.orchestrate({
      prompt: 'Qual é o foco da arquitetura?',
      routingMode: 'manual',
      requestedModelId: 'gemini/gemini-3.1-flash-lite',
    });

    const turn2 = await orchestrator.orchestrate({
      prompt: 'Continue a partir da resposta anterior.',
      sessionId: turn1.sessionId,
      routingMode: 'manual',
      requestedModelId: 'gemini/gemini-3.8-flash',
    });

    expect(turn1.ok).toBe(true);
    expect(turn2.ok).toBe(true);
    expect(seenPrompts[1]).toContain('Responder sempre em português do Brasil.');
    expect(seenHistoryCounts[1]).toBe(2);

    const summary = orchestrator.quotaController.getUsageSummary();
    expect(summary.totalRequests).toBe(2);
    expect(summary.totalTokens).toBe(240);
  });

  it('8. Modo manual sem modelo selecionado bloqueia em vez de cair silenciosamente no Smart Router', async () => {
    const orchestrator = new CapriCoreOrchestrator({
      db,
      adapters: buildAdapters(),
    });

    const result = await orchestrator.orchestrate({
      prompt: 'Explique consistência eventual.',
      routingMode: 'manual',
    });

    expect(result.ok).toBe(false);
    expect(result.trace.finalStatus).toBe('blocked');
    expect(result.trace.routingMode).toBe('manual');
    expect(result.error?.message).toContain('exige um modelo selecionado');
  });

  it('9. SQLite em arquivo mantém fatos e mensagens após fechar e reabrir a conexão', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-core-persist-'));
    const dbPath = path.join(tempDir, 'persistent.db');

    try {
      const firstConnection = createDatabase(dbPath);
      const firstOrchestrator = new CapriCoreOrchestrator({
        db: firstConnection,
        adapters: buildAdapters(),
      });
      firstOrchestrator.sharedMemory.upsertFact({
        category: 'project',
        key: 'persistencia_teste',
        content: 'Este fato deve sobreviver ao fechamento do SQLite.',
        importance: 10,
      });
      const session = firstOrchestrator.sharedMemory.ensureSession();
      firstOrchestrator.sharedMemory.addMessage({
        sessionId: session.id,
        role: 'user',
        content: 'Mensagem persistente de teste.',
      });
      firstConnection.close();

      const secondConnection = createDatabase(dbPath);
      try {
        const secondOrchestrator = new CapriCoreOrchestrator({
          db: secondConnection,
          adapters: buildAdapters(),
        });
        expect(secondOrchestrator.sharedMemory.listFacts(true).some(
          (fact) => fact.key === 'persistencia_teste',
        )).toBe(true);
        expect(secondOrchestrator.sharedMemory.getSessionMessages(session.id, 10).some(
          (message) => message.content === 'Mensagem persistente de teste.',
        )).toBe(true);
      } finally {
        secondConnection.close();
      }
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  it('7. API REST /api/v1 valida entradas, expõe status real dos provedores e persiste memória', async () => {
    const { createApp } = await import('../server.ts');
    const apiToken = 'test-only-capri-token-0123456789abcdef';
    const adminToken = 'test-only-capri-admin-token-0123456789';
    const { app, db: appDb, orchestrator: appOrchestrator } = createApp(':memory:', apiToken, adminToken);
    const server = app.listen(0);

    try {
      const address = server.address();
      if (!address || typeof address === 'string') {
        throw new Error('Porta inválida no servidor de teste.');
      }
      const baseUrl = `http://127.0.0.1:${address.port}`;

      const healthRes = await fetch(`${baseUrl}/api/v1/health`, { headers: { Authorization: `Bearer ${apiToken}` } });
      expect(healthRes.status).toBe(200);
      const unauthenticatedHealth = await fetch(`${baseUrl}/api/v1/health`);
      expect(unauthenticatedHealth.status).toBe(401);

      const health = (await healthRes.json()) as { status: string; engine: string; database: { connected: boolean; integrity: string }; providers: Array<{ provider: string }> };
      expect(health.status).toBe('ok');
      expect(health.engine).toBe('Capri Core');
      expect(health.database.connected).toBe(true);
      expect(health.database.integrity).toBe('ok');
      expect(health.providers.some((p) => p.provider === 'groq')).toBe(true);

      const badOrchestrate = await fetch(`${baseUrl}/api/v1/orchestrate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiToken}` },
        body: JSON.stringify({ prompt: '   ' }),
      });
      expect(badOrchestrate.status).toBe(400);

      const forbiddenMemoryCreate = await fetch(`${baseUrl}/api/v1/memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiToken}` },
        body: JSON.stringify({ category: 'project', key: 'unauthorized', content: 'must not persist' }),
      });
      expect(forbiddenMemoryCreate.status).toBe(403);

      const memCreate = await fetch(`${baseUrl}/api/v1/memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({
          category: 'project',
          key: 'nome_assistente',
          content: 'Capri Core Multi-LLM',
          importance: 10,
        }),
      });
      expect(memCreate.status).toBe(201);

      const restrictedCreate = await fetch(`${baseUrl}/api/v1/memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({
          category: 'knowledge', key: 'restricted_audit', content: 'Registro reservado para administração.',
          sensitivity: 'restricted',
        }),
      });
      expect(restrictedCreate.status).toBe(201);

      const privateCreate = await fetch(`${baseUrl}/api/v1/memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ category: 'knowledge', key: 'private_audit', content: 'Nota privada visível apenas na interface protegida.', sensitivity: 'private' }),
      });
      expect(privateCreate.status).toBe(201);

      const sensitivityFact = appOrchestrator.memoryEngine.upsertFact({
        category: 'knowledge', key: 'sensitivity_guard_api', content: 'Fato protegido para validar autorização.', sensitivity: 'restricted', userConfirmed: true,
      });
      const forbiddenSensitivityChange = await fetch(`${baseUrl}/api/v1/memory/${sensitivityFact.id}/sensitivity`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiToken}` },
        body: JSON.stringify({ sensitivity: 'private', confirmDowngrade: true }),
      });
      expect(forbiddenSensitivityChange.status).toBe(403);
      const unconfirmedSensitivityChange = await fetch(`${baseUrl}/api/v1/memory/${sensitivityFact.id}/sensitivity`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ sensitivity: 'private' }),
      });
      expect(unconfirmedSensitivityChange.status).toBe(400);
      const confirmedSensitivityChange = await fetch(`${baseUrl}/api/v1/memory/${sensitivityFact.id}/sensitivity`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
        body: JSON.stringify({ sensitivity: 'private', confirmDowngrade: true }),
      });
      expect(confirmedSensitivityChange.status).toBe(200);

      const originalForReject = appOrchestrator.memoryEngine.upsertFact({
        category: 'preference', key: 'api_rejection', content: 'Valor anterior preservado.', userConfirmed: true,
      });
      const pendingForReject = appOrchestrator.memoryEngine.upsertFact({
        category: 'preference', key: 'api_rejection', content: 'Proposta nova pendente.', userConfirmed: false,
      });
      const forbiddenReject = await fetch(`${baseUrl}/api/v1/memory/${pendingForReject.id}/reject`, {
        method: 'POST', headers: { Authorization: `Bearer ${apiToken}` },
      });
      expect(forbiddenReject.status).toBe(403);
      const rejectedResponse = await fetch(`${baseUrl}/api/v1/memory/${pendingForReject.id}/reject`, {
        method: 'POST', headers: { Authorization: `Bearer ${adminToken}` },
      });
      expect(rejectedResponse.status).toBe(200);
      const rejectedAgain = await fetch(`${baseUrl}/api/v1/memory/${pendingForReject.id}/reject`, {
        method: 'POST', headers: { Authorization: `Bearer ${adminToken}` },
      });
      expect(rejectedAgain.status).toBe(200);
      const confirmRejected = await fetch(`${baseUrl}/api/v1/memory/${pendingForReject.id}/confirm`, {
        method: 'POST', headers: { Authorization: `Bearer ${adminToken}` },
      });
      expect(confirmRejected.status).toBe(404);
      expect(appOrchestrator.memoryEngine.listFacts(true).find((fact) => fact.id === originalForReject.id)?.content)
        .toBe('Valor anterior preservado.');

      const memList = await fetch(`${baseUrl}/api/v1/memory`, { headers: { Authorization: `Bearer ${apiToken}` } });
      const memData = (await memList.json()) as { facts: Array<{ key: string }> };
      expect(memData.facts.some((f) => f.key === 'nome_assistente')).toBe(true);
      expect(memData.facts.some((f) => f.key === 'restricted_audit')).toBe(false);
      expect(memData.facts.some((f) => f.key === 'private_audit')).toBe(true);
      const adminMemList = await fetch(`${baseUrl}/api/v1/memory`, { headers: { Authorization: `Bearer ${adminToken}` } });
      const adminMemData = (await adminMemList.json()) as { facts: Array<{ key: string }> };
      expect(adminMemData.facts.some((f) => f.key === 'restricted_audit')).toBe(true);
      expect(adminMemData.facts.some((f) => f.key === 'private_audit')).toBe(true);

      const zipRes = await fetch(`${baseUrl}/api/v1/export/zip`, { headers: { Authorization: `Bearer ${adminToken}` } });
      expect(zipRes.status).toBe(200);
      expect(zipRes.headers.get('content-type')).toContain('application/zip');
      const zipBuffer = Buffer.from(await zipRes.arrayBuffer());
      expect(zipBuffer.subarray(0, 2).toString('utf8')).toBe('PK');
    } finally {
      server.close();
      appDb.close();
    }
  });
  it('10. Não trata um modelo recém-cadastrado como disponível antes de consultar o catálogo autenticado', async () => {
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters() });
    const beforeVerification = orchestrator.modelRegistry.getModelById('gemini/gemini-3.1-flash-lite');
    expect(beforeVerification?.availability).toBe('unverified');

    await orchestrator.modelRegistry.refreshAvailability();
    const afterVerification = orchestrator.modelRegistry.getModelById('gemini/gemini-3.1-flash-lite');
    expect(afterVerification?.availability).toBe('available');
  });

  it('11. Não repete tentativas em modelos do mesmo provedor no fallback automático', async () => {
    const attemptedProviders: ProviderId[] = [];
    const groqFailing = createStubAdapter('groq', {
      configured: true,
      handler: async (input) => {
        attemptedProviders.push('groq');
        throw new AdapterExecutionError({ provider: 'groq', errorType: 'rate_limit', retryable: true, statusCode: 429, message: 'rate limited' });
      },
    });
    const geminiSuccess = createStubAdapter('gemini', {
      configured: true,
      handler: async (input) => {
        attemptedProviders.push('gemini');
        return { text: 'ok', inputTokens: 1, outputTokens: 1, totalTokens: 2, latencyMs: 10, rawModelUsed: input.model.modelName };
      },
    });
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters({ groq: groqFailing, gemini: geminiSuccess }) });
    orchestrator.modelRegistry.updateModel('groq/llama-3.3-70b-versatile', { priority: 100 });
    orchestrator.modelRegistry.updateModel('gemini/gemini-3.8-flash', { priority: 60 });

    const result = await orchestrator.orchestrate({
      prompt: 'Escreva uma arquitetura TypeScript com função async, algoritmo e trade-offs de segurança.',
      maxFallbackAttempts: 3,
    });
    expect(result.ok).toBe(true);
    expect(attemptedProviders).toEqual(['groq', 'gemini']);
    expect(new Set(attemptedProviders).size).toBe(attemptedProviders.length);
  });

  it('12. Preserva histórico de sessão quando o primeiro provedor falha e o fallback usa outro', async () => {
    let fallbackHistory: string[] = [];
    const geminiAdapter = createStubAdapter('gemini', {
      configured: true,
      handler: async (input) => {
        fallbackHistory = input.history.map((turn) => `${turn.role}:${turn.content}`);
        return { text: 'resposta', inputTokens: 2, outputTokens: 2, totalTokens: 4, latencyMs: 12, rawModelUsed: input.model.modelName };
      },
    });
    const groqAdapter = createStubAdapter('groq', {
      configured: true,
      handler: async () => {
        throw new AdapterExecutionError({ provider: 'groq', errorType: 'upstream_error', retryable: true, message: 'upstream indisponível' });
      },
    });
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters({ gemini: geminiAdapter, groq: groqAdapter }) });
    const first = await orchestrator.orchestrate({
      prompt: 'Meu projeto utiliza SQLite persistente.',
      routingMode: 'manual',
      requestedModelId: 'gemini/gemini-3.1-flash-lite',
    });
    expect(first.ok).toBe(true);
    orchestrator.modelRegistry.updateModel('groq/llama-3.3-70b-versatile', { priority: 100 });
    orchestrator.modelRegistry.updateModel('gemini/gemini-3.8-flash', { priority: 60 });

    const second = await orchestrator.orchestrate({
      prompt: 'Agora escreva uma função TypeScript para acessar o banco.',
      sessionId: first.sessionId,
      maxFallbackAttempts: 2,
    });
    expect(second.ok).toBe(true);
    expect(second.trace.finalProvider).toBe('gemini');
    expect(fallbackHistory).toContain('user:Meu projeto utiliza SQLite persistente.');
    expect(fallbackHistory).toContain('assistant:Resposta simulada em teste unitário por Gemini 3.1 Flash-Lite');
  });

  it('13. Seleção manual estrita não troca de modelo após erro de autenticação', async () => {
    const failingManual = createStubAdapter('gemini', {
      configured: true,
      handler: async () => {
        throw new AdapterExecutionError({ provider: 'gemini', errorType: 'auth_error', retryable: false, statusCode: 401, message: 'credencial recusada' });
      },
    });
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters({ gemini: failingManual }) });
    const result = await orchestrator.orchestrate({
      prompt: 'Explique o que é uma API.',
      routingMode: 'manual',
      requestedModelId: 'gemini/gemini-3.1-flash-lite',
      allowFallbackOnManual: false,
    });
    expect(result.ok).toBe(false);
    expect(result.trace.fallbackAttempts).toHaveLength(1);
    expect(result.trace.fallbackAttempts[0].errorType).toBe('auth_error');
  });

  it('14. Modelo cadastrado com ID ausente no catálogo autenticado fica inválido e não é roteado', async () => {
    const geminiWithoutNewId: ProviderAdapter = {
      ...createStubAdapter('gemini', { configured: true }),
      async listModels() { return ['gemini-3.1-flash-lite', 'gemini-3.8-flash']; },
    };
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters({ gemini: geminiWithoutNewId }) });
    const created = orchestrator.modelRegistry.registerModel({
      provider: 'gemini',
      modelName: 'capri-model-nao-existente',
      displayName: 'Modelo de teste inexistente',
      capabilityTier: 'balanced',
      strengths: ['general_chat'],
    });
    expect(created.availability).toBe('unverified');
    await orchestrator.modelRegistry.refreshAvailability(true);
    const verified = orchestrator.modelRegistry.getModelById(created.id);
    expect(verified?.availability).toBe('invalid_model');

    const result = await orchestrator.orchestrate({
      prompt: 'Teste de seleção manual.',
      routingMode: 'manual',
      requestedModelId: created.id,
    });
    expect(result.ok).toBe(false);
    expect(result.trace.finalStatus).toBe('blocked');
    expect(result.error?.message).toContain('não consta no catálogo');
  });

  it('15. Cooldown de provedor permanece no SQLite após recriar o controlador', () => {
    const firstController = new QuotaController(db);
    firstController.setCooldown('gemini/gemini-3.1-flash-lite', 60_000, 'rate_limit');
    const secondController = new QuotaController(db);
    expect(secondController.getCooldownUntil('gemini/gemini-3.1-flash-lite')).not.toBeNull();
  });

  it('16. Migra identificadores legados do catálogo e remove preços padrão não verificados', () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-core-migration-'));
    const dbPath = path.join(tempDir, 'migration.db');
    const oldId = 'gemini/gemini-4-hydrogen';
    try {
      const legacyDb = createDatabase(dbPath);
      legacyDb.prepare('UPDATE models SET id = ?, model_name = ?, display_name = ?, cost_per_1k_input = 0.00015, cost_per_1k_output = 0.0006 WHERE id = ?')
        .run(oldId, 'gemini-4-hydrogen', 'Gemini 4 Hydrogen', 'gemini/gemini-3.8-flash');
      legacyDb.prepare('UPDATE sessions SET active_model_override = ? WHERE id = ?').run(oldId, 'session-principal');
      legacyDb.prepare('DELETE FROM schema_migrations WHERE version = 1').run();
      legacyDb.close();

      const migratedDb = createDatabase(dbPath);
      try {
        const model = migratedDb.prepare('SELECT id, model_name, cost_per_1k_input, cost_per_1k_output FROM models WHERE id = ?')
          .get('gemini/gemini-3.8-flash') as { id: string; model_name: string; cost_per_1k_input: number; cost_per_1k_output: number };
        expect(model.model_name).toBe('gemini-3.8-flash');
        expect(model.cost_per_1k_input).toBe(0);
        expect(model.cost_per_1k_output).toBe(0);
        const session = migratedDb.prepare('SELECT active_model_override FROM sessions WHERE id = ?').get('session-principal') as { active_model_override: string };
        expect(session.active_model_override).toBe('gemini/gemini-3.8-flash');
      } finally {
        migratedDb.close();
      }
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  it('17. Smart Router bloqueia seleção manual incompatível com o contexto estimado', async () => {
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters() });
    const smallContext = orchestrator.modelRegistry.registerModel({
      id: 'gemini/test-small-context',
      provider: 'gemini',
      modelName: 'gemini-3.1-flash-lite',
      displayName: 'Gemini contexto mínimo (teste)',
      capabilityTier: 'balanced',
      strengths: ['general_chat'],
      maxContextTokens: 1,
    });
    await orchestrator.modelRegistry.refreshAvailability(true);
    expect(orchestrator.modelRegistry.getModelById(smallContext.id)?.availability).toBe('available');

    const result = await orchestrator.orchestrate({
      prompt: 'Explique o funcionamento da memória compartilhada.',
      routingMode: 'manual',
      requestedModelId: smallContext.id,
    });
    expect(result.ok).toBe(false);
    expect(result.trace.finalStatus).toBe('blocked');
    expect(result.error?.message).toContain('contexto estimado');
  });

  it('18. Smart Router usa latência observada recente quando há telemetria disponível', () => {
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters() });
    const model = orchestrator.modelRegistry.getModelById('gemini/gemini-3.1-flash-lite');
    if (!model) throw new Error('Modelo seed não encontrado no teste.');
    orchestrator.quotaController.recordUsage({
      traceId: 'trace-latency-test',
      sessionId: 'session-principal',
      model,
      status: 'success',
      latencyMs: 123,
      inputTokens: 1,
      outputTokens: 1,
      totalTokens: 2,
    });
    expect(orchestrator.modelRegistry.getModelById(model.id)?.avgLatencyMs).toBe(123);
  });

});


describe('GeminiAdapter — cancelamento efetivo', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    delete process.env.CAPRI_TEST_GEMINI_KEY;
  });

  it('aborta a requisição HTTP quando o timeout é excedido', async () => {
    process.env.CAPRI_TEST_GEMINI_KEY = 'test-key';
    let abortObserved = false;

    vi.stubGlobal('fetch', (_url: string, init?: RequestInit) =>
      new Promise<Response>((_resolve, reject) => {
        init?.signal?.addEventListener('abort', () => {
          abortObserved = true;
          reject(new DOMException('The operation was aborted', 'AbortError'));
        }, { once: true });
      }),
    );

    const model: ModelDefinition = {
      id: 'gemini/test-model',
      provider: 'gemini',
      modelName: 'gemini-test-model',
      displayName: 'Gemini test model',
      envKey: 'CAPRI_TEST_GEMINI_KEY',
      enabled: true,
      capabilityTier: 'balanced',
      strengths: ['general_chat'],
      costPer1kInput: 0,
      costPer1kOutput: 0,
      avgLatencyMs: 1,
      priority: 1,
      rpmLimit: 10,
      rpdLimit: 100,
      tpdLimit: 10000,
      maxContextTokens: 10000,
      notes: '',
      updatedAt: new Date().toISOString(),
    };

    const adapter = new GeminiAdapter();
    await expect(adapter.execute({
      model,
      prompt: 'Teste de timeout',
      systemInstruction: 'Teste',
      history: [],
      intent: 'general_chat',
      complexity: 'low',
      timeoutMs: 20,
    })).rejects.toMatchObject({ errorType: 'timeout', retryable: true });

    expect(abortObserved).toBe(true);
  });
});

describe('Capri Core v3.2 — Memory Engine', () => {
  let db: ReturnType<typeof createDatabase>;

  beforeEach(() => {
    db = createDatabase(':memory:');
  });

  afterEach(() => {
    db.close();
  });

  it('recupera fatos de longo prazo em outra sessão e mantém fatos de sessão isolados', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const first = memory.createSession('Origem');
    const second = memory.createSession('Destino');

    memory.upsertFact({
      category: 'project', key: 'projeto_capri', content: 'O projeto Capri usa arquitetura multi-LLM.',
      userConfirmed: true, sourceType: 'user_explicit', importance: 9,
    });
    memory.upsertFact({
      category: 'knowledge', key: 'nota_sessao', content: 'Detalhe restrito desta sessão.',
      scope: 'session', sessionId: first.id, userConfirmed: true,
    });

    const context = memory.buildPortableContext(second.id, undefined, 'Como funciona a arquitetura do projeto Capri?');
    expect(context.systemInstruction).toContain('arquitetura multi-LLM');
    expect(context.systemInstruction).not.toContain('Detalhe restrito desta sessão');
  });

  it('mantém contradições pendentes até confirmação explícita e preserva histórico', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const original = memory.upsertFact({
      category: 'preference', key: 'idioma', content: 'Prefere respostas em português.',
      userConfirmed: true, sourceType: 'user_explicit',
    });
    const candidate = memory.upsertFact({
      category: 'preference', key: 'idioma', content: 'Prefere respostas em inglês.',
      userConfirmed: false, sourceType: 'inferred', confidence: 0.55,
    });

    expect(candidate.status).toBe('pending_confirmation');
    expect(memory.listFacts(true).find((fact) => fact.id === original.id)?.content)
      .toBe('Prefere respostas em português.');

    const confirmed = memory.confirmFact(candidate.id);
    expect(confirmed?.userConfirmed).toBe(true);
    expect(memory.listFacts(false).find((fact) => fact.id === original.id)?.active).toBe(false);
    expect(memory.getFactHistory(candidate.id).some((event) => event.eventType === 'confirmed')).toBe(true);
  });

  it('exige validade para memória temporária e não recupera registros expirados', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const session = memory.createSession('Temporária');
    expect(() => memory.upsertFact({
      category: 'knowledge', key: 'temporario', content: 'Não deve persistir sem expiração.', scope: 'temporary',
      sessionId: session.id,
    })).toThrow('Memória temporária exige expiresAt.');
    expect(() => memory.upsertFact({
      category: 'knowledge', key: 'temporario_sem_sessao', content: 'Temporária sem sessão.', scope: 'temporary',
      expiresAt: '2099-01-01T00:00:00.000Z',
    })).toThrow('Memória de sessão ou temporária exige sessionId.');

    const otherSession = memory.createSession('Outra sessão');
    memory.upsertFact({
      category: 'knowledge', key: 'temporario_isolado', content: 'Contexto temporário exclusivo.', scope: 'temporary',
      sessionId: session.id, expiresAt: '2099-01-01T00:00:00.000Z', userConfirmed: true,
    });
    const ownContext = memory.buildPortableContext(session.id, undefined, 'Contexto temporário exclusivo');
    const otherContext = memory.buildPortableContext(otherSession.id, undefined, 'Contexto temporário exclusivo');
    expect(ownContext.systemInstruction).toContain('Contexto temporário exclusivo');
    expect(otherContext.systemInstruction).not.toContain('Contexto temporário exclusivo');

    memory.upsertFact({
      category: 'knowledge', key: 'expirado', content: 'Conteúdo expirado.', scope: 'temporary',
      sessionId: session.id, expiresAt: '2000-01-01T00:00:00.000Z', userConfirmed: true,
    });
    const context = memory.buildPortableContext(session.id, undefined, 'Conteúdo expirado');
    expect(context.systemInstruction).not.toContain('Conteúdo expirado.');
    expect(() => memory.upsertFact({
      category: 'knowledge', key: 'credencial', content: 'Minha senha é exemplo123', userConfirmed: true,
    })).toThrow('Conteúdo potencialmente sensível');
  });

  it('não permite sobrescrever diretamente fato confirmado e deduplica proposta pendente', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const original = memory.upsertFact({
      category: 'preference', key: 'idioma_patch', content: 'Prefere português.', userConfirmed: true,
    });
    const candidate1 = memory.updateFact(original.id, { content: 'Prefere inglês.' });
    const candidate2 = memory.upsertFact({
      category: 'preference', key: 'idioma_patch', content: 'Prefere inglês.', userConfirmed: false,
      sourceType: 'admin',
    });
    expect(candidate1?.status).toBe('pending_confirmation');
    expect(candidate2.id).toBe(candidate1?.id);
    expect(memory.listFacts(false).filter((fact) => fact.key === 'idioma_patch')).toHaveLength(2);
    expect(memory.listFacts(true).find((fact) => fact.id === original.id)?.content).toBe('Prefere português.');
  });

  it('migra banco legado preservando sessões, mensagens e fatos, e é idempotente', () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-memory-migration-'));
    const dbPath = path.join(tempDir, 'legacy.db');
    try {
      const legacy = new Database(dbPath);
      legacy.pragma('foreign_keys = ON');
      legacy.exec(`
        CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL);
        CREATE TABLE sessions (id TEXT PRIMARY KEY, title TEXT NOT NULL, active_model_override TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE messages (id TEXT PRIMARY KEY, session_id TEXT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL,
          model_id TEXT, provider TEXT, intent TEXT, trace_id TEXT, created_at TEXT NOT NULL,
          FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE);
        CREATE TABLE memory_facts (id TEXT PRIMARY KEY, category TEXT NOT NULL, key TEXT NOT NULL, content TEXT NOT NULL,
          source_model TEXT, importance INTEGER NOT NULL DEFAULT 5, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
      `);
      legacy.prepare('INSERT INTO sessions VALUES (?, ?, NULL, ?, ?)').run('legacy-session', 'Sessão legada', 't0', 't1');
      legacy.prepare('INSERT INTO messages VALUES (?, ?, ?, ?, NULL, NULL, NULL, NULL, ?)')
        .run('legacy-message', 'legacy-session', 'user', 'Mensagem preservada', 't1');
      legacy.prepare('INSERT INTO memory_facts VALUES (?, ?, ?, ?, NULL, 9, 1, ?, ?)')
        .run('legacy-fact', 'project', 'projeto', 'Memória preservada', 't0', 't1');
      legacy.close();

      const migrated = createDatabase(dbPath);
      expect(migrated.prepare("SELECT content FROM messages WHERE id = 'legacy-message'").get()).toEqual({ content: 'Mensagem preservada' });
      expect(migrated.prepare("SELECT content, scope, source_type, user_confirmed FROM memory_facts WHERE id = 'legacy-fact'").get())
        .toEqual({ content: 'Memória preservada', scope: 'long_term', source_type: 'legacy', user_confirmed: 0 });
      expect(migrated.pragma('foreign_key_check')).toEqual([]);
      expect(migrated.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = 2').get()).toEqual({ n: 1 });
      migrated.close();

      const reopened = createDatabase(dbPath);
      expect(reopened.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = 2').get()).toEqual({ n: 1 });
      reopened.prepare(`INSERT INTO memory_facts (id, category, key, content, created_at, updated_at, scope, session_id)
        VALUES ('session-fact', 'knowledge', 'escopo', 'Memória da sessão', 't0', 't1', 'session', 'legacy-session')`).run();
      reopened.prepare(`INSERT INTO memory_events (id, memory_fact_id, event_type, actor_type, created_at)
        VALUES ('event-legacy', 'legacy-fact', 'updated', 'admin', 't1')`).run();
      reopened.prepare(`INSERT INTO memory_relations (from_fact_id, to_fact_id, relation_type, created_at)
        VALUES ('legacy-fact', 'session-fact', 'related_to', 't1')`).run();
      reopened.prepare("DELETE FROM sessions WHERE id = 'legacy-session'").run();
      expect(reopened.prepare("SELECT COUNT(*) AS n FROM messages WHERE session_id = 'legacy-session'").get()).toEqual({ n: 0 });
      expect(reopened.prepare("SELECT COUNT(*) AS n FROM memory_facts WHERE id = 'session-fact'").get()).toEqual({ n: 0 });
      reopened.prepare("DELETE FROM memory_facts WHERE id = 'legacy-fact'").run();
      expect(reopened.prepare("SELECT COUNT(*) AS n FROM memory_events WHERE memory_fact_id = 'legacy-fact'").get()).toEqual({ n: 0 });
      expect(reopened.prepare("SELECT COUNT(*) AS n FROM memory_relations WHERE from_fact_id = 'legacy-fact' OR to_fact_id = 'legacy-fact'").get()).toEqual({ n: 0 });
      reopened.close();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  it('faz rollback integral da migração de memória quando uma etapa falha', () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-memory-rollback-'));
    const dbPath = path.join(tempDir, 'legacy-failure.db');
    try {
      const legacy = new Database(dbPath);
      legacy.exec(`
        CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL);
        CREATE TABLE sessions (id TEXT PRIMARY KEY, title TEXT NOT NULL, active_model_override TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE messages (id TEXT PRIMARY KEY, session_id TEXT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL,
          model_id TEXT, provider TEXT, intent TEXT, trace_id TEXT, created_at TEXT NOT NULL,
          FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE);
        CREATE TABLE memory_facts (id TEXT PRIMARY KEY, category TEXT NOT NULL, key TEXT NOT NULL, content TEXT NOT NULL,
          source_model TEXT, importance INTEGER NOT NULL DEFAULT 5, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TRIGGER fail_memory_migration BEFORE INSERT ON schema_migrations WHEN NEW.version = 2
        BEGIN SELECT RAISE(ABORT, 'injected migration failure'); END;
      `);
      legacy.close();

      expect(() => createDatabase(dbPath)).toThrow('injected migration failure');
      const check = new Database(dbPath);
      const columns = check.pragma('table_info(memory_facts)') as Array<{ name: string }>;
      expect(columns.some((column) => column.name === 'scope')).toBe(false);
      expect(check.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name IN ('memory_relations', 'memory_events')").get())
        .toEqual({ n: 0 });
      check.close();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  it('aplica a migração v2 sem remover tabelas-base e mantém esquema de memória compatível', () => {
    const migration = db.prepare('SELECT name FROM schema_migrations WHERE version = 2').get() as { name: string } | undefined;
    expect(migration?.name).toBe('add-central-memory-engine-metadata-relations-and-event-history');
    const auditR2Migration = db.prepare('SELECT name FROM schema_migrations WHERE version = 3').get() as { name: string } | undefined;
    expect(auditR2Migration?.name).toBe('memory-engine-audit-r2-rejection-and-sensitivity-events');
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all() as Array<{ name: string }>;
    expect(tables.map((table) => table.name)).toEqual(expect.arrayContaining([
      'sessions', 'messages', 'memory_facts', 'memory_relations', 'memory_events',
    ]));
    const columns = db.pragma('table_info(memory_facts)') as Array<{ name: string }>;
    expect(columns.map((column) => column.name)).toEqual(expect.arrayContaining([
      'scope', 'session_id', 'source_type', 'confidence', 'user_confirmed', 'status', 'expires_at',
    ]));
  });

  it('serializa gravações concorrentes e evita duplicar a mesma memória', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    await Promise.all(Array.from({ length: 8 }, () => Promise.resolve().then(() => memory.upsertFact({
      category: 'project', key: 'chave_unica', content: 'Conteúdo idempotente.', userConfirmed: true,
    }))));
    const matches = memory.listFacts(false).filter((fact) => fact.key === 'chave_unica');
    expect(matches).toHaveLength(1);
  });

  it('exclui memórias private e restricted do contexto enviado aos provedores', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const session = memory.createSession('Privacidade');
    memory.upsertFact({ category: 'project', key: 'normal_context', content: 'O projeto Capri usa SQLite para persistência.', userConfirmed: true });
    memory.upsertFact({ category: 'knowledge', key: 'private_context', content: 'Anotação privada de contexto da Capri.', sensitivity: 'private', userConfirmed: true });
    memory.upsertFact({ category: 'knowledge', key: 'restricted_context', content: 'Anotação restrita da Capri.', sensitivity: 'restricted', userConfirmed: true });
    const context = memory.buildPortableContext(session.id, undefined, 'Como funciona a persistência do projeto Capri?');
    expect(context.systemInstruction).toContain('SQLite para persistência');
    expect(context.systemInstruction).not.toContain('Anotação privada');
    expect(context.systemInstruction).not.toContain('Anotação restrita');
  });

  it('rejeita proposta pendente de forma transacional e idempotente sem alterar o fato anterior', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const original = memory.upsertFact({ category: 'preference', key: 'idioma_rejeicao', content: 'Prefere português.', userConfirmed: true });
    const proposal = memory.upsertFact({ category: 'preference', key: 'idioma_rejeicao', content: 'Prefere inglês.', userConfirmed: false, sourceType: 'inferred' });
    expect(proposal.status).toBe('pending_confirmation');
    const rejected = memory.rejectFact(proposal.id);
    expect(rejected?.status).toBe('rejected');
    expect(rejected?.active).toBe(false);
    expect(memory.rejectFact(proposal.id)?.status).toBe('rejected');
    expect(memory.confirmFact(proposal.id)).toBeNull();
    expect(() => memory.updateFact(proposal.id, { active: true })).toThrow('não podem ser reativadas');
    expect(() => memory.upsertFact({ id: proposal.id, category: 'preference', key: 'idioma_rejeicao', content: 'Proposta nova pendente.', userConfirmed: true })).toThrow('rejeitadas não podem ser reativadas');
    expect(memory.listFacts(true).find((fact) => fact.id === original.id)?.content).toBe('Prefere português.');
    const rejectionEvents = memory.getFactHistory(proposal.id).filter((event) => event.eventType === 'proposal_rejected');
    expect(rejectionEvents).toHaveLength(1);
    expect(rejectionEvents[0].oldValue).not.toContain('content');
    expect(rejectionEvents[0].newValue).not.toContain('content');
  });

  it('expande relações relacionadas sem atravessar sessões, ciclos, duplicações ou conflitos', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const session = memory.createSession('Relações');
    const other = memory.createSession('Outra sessão');
    const root = memory.upsertFact({ category: 'project', key: 'capri_architecture', content: 'Capri Core organiza o Memory Engine e o Smart Router.', userConfirmed: true, importance: 10 });
    const related = memory.upsertFact({ category: 'knowledge', key: 'durability_note', content: 'Transações locais garantem durabilidade atômica.', userConfirmed: true, importance: 8 });
    const derived = memory.upsertFact({ category: 'knowledge', key: 'event_history', content: 'Eventos históricos preservam alterações de estado.', userConfirmed: true, importance: 8 });
    const otherSessionFact = memory.upsertFact({ category: 'knowledge', key: 'other_session', content: 'Segredo contextual de outra sessão.', scope: 'session', sessionId: other.id, userConfirmed: true });
    const privateRelated = memory.upsertFact({ category: 'knowledge', key: 'private_related', content: 'Relação privada não pode sair.', sensitivity: 'private', userConfirmed: true });
    const expiredRelated = memory.upsertFact({ category: 'knowledge', key: 'expired_related', content: 'Relação já expirada.', scope: 'temporary', sessionId: session.id, expiresAt: '2000-01-01T00:00:00.000Z', userConfirmed: true });
    const contradiction = memory.upsertFact({ category: 'project', key: 'capri_architecture', content: 'A arquitetura não usa SQLite.', userConfirmed: false });
    const pendingBase = memory.upsertFact({ category: 'knowledge', key: 'pending_related', content: 'Fato anterior sobre fila de propostas.', userConfirmed: true });
    const pendingRelated = memory.upsertFact({ category: 'knowledge', key: 'pending_related', content: 'PENDENTE não pode ser contexto atual.', userConfirmed: false });
    const rejectedBase = memory.upsertFact({ category: 'knowledge', key: 'rejected_related', content: 'Fato anterior preservado após rejeição.', userConfirmed: true });
    const rejectedRelated = memory.upsertFact({ category: 'knowledge', key: 'rejected_related', content: 'REJEITADO não pode ser contexto atual.', userConfirmed: false });
    memory.rejectFact(rejectedRelated.id);
    const supersededBase = memory.upsertFact({ category: 'knowledge', key: 'superseded_related', content: 'SUPERADO não pode ser contexto atual.', userConfirmed: true });
    const supersedingProposal = memory.upsertFact({ category: 'knowledge', key: 'superseded_related', content: 'Nova versão confirmada.', userConfirmed: false });
    memory.confirmFact(supersedingProposal.id);
    expect(() => memory.updateFact(supersededBase.id, { active: true })).toThrow('não podem ser reativados');
    expect(() => memory.upsertFact({ id: supersededBase.id, category: 'knowledge', key: 'superseded_related', content: 'SUPERADO não pode ser contexto atual.', userConfirmed: true })).toThrow('não podem ser reativados por upsert');
    memory.relateFacts(root.id, related.id, 'related_to');
    memory.relateFacts(related.id, root.id, 'related_to');
    memory.relateFacts(root.id, derived.id, 'derived_from');
    memory.relateFacts(root.id, otherSessionFact.id, 'related_to');
    memory.relateFacts(root.id, privateRelated.id, 'derived_from');
    memory.relateFacts(root.id, expiredRelated.id, 'related_to');
    memory.relateFacts(root.id, pendingRelated.id, 'related_to');
    memory.relateFacts(root.id, rejectedRelated.id, 'derived_from');
    memory.relateFacts(root.id, supersededBase.id, 'related_to');
    memory.relateFacts(root.id, contradiction.id, 'contradicts');
    memory.relateFacts(contradiction.id, root.id, 'supersedes');
    const context = memory.buildPortableContext(session.id, undefined, 'Explique a arquitetura do Capri Core e seu armazenamento SQLite.');
    expect(context.systemInstruction).toContain('Memory Engine');
    expect(context.systemInstruction).toContain('durabilidade atômica');
    expect(context.systemInstruction).toContain('Eventos históricos preservam alterações');
    expect(context.systemInstruction).not.toContain('Segredo contextual de outra sessão');
    expect(context.systemInstruction).not.toContain('Relação privada');
    expect(context.systemInstruction).not.toContain('Relação já expirada');
    expect(context.systemInstruction).not.toContain('PENDENTE não pode ser contexto atual');
    expect(context.systemInstruction).not.toContain('REJEITADO não pode ser contexto atual');
    expect(context.systemInstruction).not.toContain('SUPERADO não pode ser contexto atual');
    expect(context.systemInstruction).not.toContain('A arquitetura não usa SQLite');
    expect((context.systemInstruction.match(/durability_note/g) ?? []).length).toBe(1);
  });

  it('aplica orçamento global conservador, reserva resposta e nunca remove a mensagem atual', async () => {
    const { applyGlobalContextBudget, estimateConservativeTokens } = await import('../src/server/core/context-budget.ts');
    expect(estimateConservativeTokens('abc')).toBe(1);
    expect(estimateConservativeTokens('漢字')).toBe(2);
    expect(estimateConservativeTokens('🙂')).toBe(1);
    const memoryCandidates = Array.from({ length: 20 }, (_, i) => ({ id: `m${i}`, score: 20 - i, line: `- Memória ${i}: ${'conteúdo longo '.repeat(15)}` }));
    const recentHistory = Array.from({ length: 20 }, (_, i) => ({ role: (i % 2 ? 'assistant' : 'user') as 'assistant' | 'user', content: `Mensagem histórica ${i}: ${'histórico '.repeat(12)}` }));
    const prompt = 'MENSAGEM ATUAL QUE NÃO PODE SER REMOVIDA';
    const result = applyGlobalContextBudget({ maxContextTokens: 1024, systemBase: 'Instrução de sistema obrigatória.', customSystemPrompt: 'Instrução adicional.', currentPrompt: prompt, memoryCandidates, recentHistory });
    expect(result.currentPromptPreserved).toBe(true);
    expect(result.reservedOutputTokens).toBeGreaterThan(0);
    expect(result.omittedMemoryCount + result.omittedHistoryCount).toBeGreaterThan(0);
    expect(result.estimatedInputTokens + result.reservedOutputTokens + result.safetyMarginTokens).toBeLessThanOrEqual(1024);
    expect(() => applyGlobalContextBudget({ maxContextTokens: 1024, systemBase: 'Sistema obrigatório.', currentPrompt: 'mensagem '.repeat(500), memoryCandidates: [], recentHistory: [] })).toThrow('mensagem atual foi preservada');
    for (const maxContextTokens of [4096, 32768, 128000]) {
      const scaled = applyGlobalContextBudget({ maxContextTokens, systemBase: 'Sistema obrigatório.',
        customSystemPrompt: 'Instrução de usuário.', currentPrompt: prompt, memoryCandidates, recentHistory });
      expect(scaled.estimatedInputTokens + scaled.reservedOutputTokens + scaled.safetyMarginTokens).toBeLessThanOrEqual(maxContextTokens);
      expect(scaled.currentPromptPreserved).toBe(true);
    }
  });

  it('mantém MemoryEngine como instância central e envia o mesmo contexto aos seis provedores', async () => {
    const providers: ProviderId[] = ['gemini', 'groq', 'openai', 'anthropic', 'deepseek', 'xai'];
    const modelIds: Record<ProviderId, string> = {
      gemini: 'gemini/gemini-3.1-flash-lite', groq: 'groq/llama-3.1-8b-instant',
      openai: 'openai/gpt-4o-mini', anthropic: 'anthropic/claude-haiku-5-5',
      deepseek: 'deepseek/deepseek-flash', xai: 'xai/latest',
    };
    const captured: Array<{ provider: ProviderId; systemInstruction: string; history: AdapterExecuteInput['history']; maxOutputTokens?: number }> = [];
    const overrides: Partial<Record<ProviderId, ProviderAdapter>> = {};
    for (const provider of providers) {
      overrides[provider] = createStubAdapter(provider, { configured: true, handler: async (input) => {
        captured.push({ provider, systemInstruction: input.systemInstruction, history: input.history, maxOutputTokens: input.maxOutputTokens });
        return { text: 'ok', inputTokens: 1, outputTokens: 1, totalTokens: 2, latencyMs: 1, rawModelUsed: input.model.modelName };
      } });
    }
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters(overrides) });
    expect(orchestrator.sharedMemory).toBe(orchestrator.memoryEngine);
    orchestrator.memoryEngine.upsertFact({ category: 'project', key: 'shared_provider_fact', content: 'O contexto central é compartilhado entre os seis provedores Capri.', userConfirmed: true });
    for (const provider of providers) {
      const session = orchestrator.memoryEngine.createSession(`Sessão ${provider}`);
      const result = await orchestrator.orchestrate({ prompt: 'Explique o contexto central compartilhado entre os provedores Capri.', sessionId: session.id, routingMode: 'manual', requestedModelId: modelIds[provider] });
      expect(result.ok).toBe(true);
    }
    expect(captured.map((item) => item.provider).sort()).toEqual([...providers].sort());
    expect(new Set(captured.map((item) => item.systemInstruction)).size).toBe(1);
    expect(captured.every((item) => item.systemInstruction.includes('contexto central é compartilhado'))).toBe(true);
    expect(captured.every((item) => (item.maxOutputTokens ?? 0) > 0)).toBe(true);
  });

  it('protege alteração de sensibilidade e exige confirmação explícita para reduzir classificação', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const fact = memory.upsertFact({ category: 'knowledge', key: 'sensitivity_test', content: 'Classificação restrita de teste.', sensitivity: 'restricted', userConfirmed: true });
    expect(() => memory.updateFact(fact.id, { sensitivity: 'normal' })).toThrow('não pode ser reduzida');
    expect(() => memory.changeSensitivity(fact.id, 'private')).toThrow('confirmação explícita');
    expect(memory.changeSensitivity(fact.id, 'private', true)?.sensitivity).toBe('private');
    expect(memory.getFactHistory(fact.id).some((event) => event.eventType === 'sensitivity_changed')).toBe(true);
  });


  it('prioriza fatos lexicalmente relevantes e evita inserir memórias sem relação com a solicitação', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const session = memory.createSession('Relevância');
    memory.upsertFact({ category: 'project', key: 'capri_router', content: 'O Smart Router seleciona modelos compatíveis com a intenção.', userConfirmed: true, importance: 10 });
    memory.upsertFact({ category: 'knowledge', key: 'receita_bolo', content: 'Receita de bolo de cenoura com cobertura de chocolate.', userConfirmed: true, importance: 10 });
    const context = memory.buildPortableContext(session.id, undefined, 'Como o Smart Router seleciona modelos?');
    expect(context.systemInstruction).toContain('Smart Router seleciona modelos');
    expect(context.systemInstruction).not.toContain('Receita de bolo de cenoura');
  });


  it('remove conteúdo private/restricted do histórico antes de reutilizá-lo em provedores externos', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const session = memory.createSession('Redação de histórico privado');
    const privateContent = 'Anotação privada confidencial Capri 7F3A9';
    const restrictedContent = 'Registro restrito confidencial Capri 9B2C1';
    memory.upsertFact({ category: 'knowledge', key: 'private_history_redaction', content: privateContent, sensitivity: 'private', userConfirmed: true });
    memory.upsertFact({ category: 'knowledge', key: 'restricted_history_redaction', content: restrictedContent, sensitivity: 'restricted', userConfirmed: true });
    memory.addMessage({ sessionId: session.id, role: 'assistant', content: `Resumo anterior: ${privateContent}. ${restrictedContent}.` });
    const context = memory.buildPortableContext(session.id, undefined, 'Continue o resumo.');
    expect(context.history).toHaveLength(1);
    expect(context.history[0].content).not.toContain(privateContent);
    expect(context.history[0].content).not.toContain(restrictedContent);
    expect(context.history[0].content.match(/conteúdo de memória privada\/restrita omitido/g)).toHaveLength(2);
  });

  it('roteia prompts longos pelo limite real dos modelos em vez de um orçamento preliminar fixo de 8k', async () => {
    const captured: string[] = [];
    const overrides: Partial<Record<ProviderId, ProviderAdapter>> = {
      gemini: createStubAdapter('gemini', { configured: true, handler: async (input) => {
        captured.push(input.prompt);
        return { text: 'prompt longo recebido', inputTokens: 7000, outputTokens: 4, totalTokens: 7004, latencyMs: 1, rawModelUsed: input.model.modelName };
      } }),
    };
    const orchestrator = new CapriCoreOrchestrator({ db, adapters: buildAdapters(overrides) });
    const session = orchestrator.memoryEngine.createSession('Prompt longo');
    const prompt = `Auditoria Capri ${'detalhe '.repeat(7500)}`;
    const result = await orchestrator.orchestrate({
      prompt, sessionId: session.id, routingMode: 'manual', requestedModelId: 'gemini/gemini-3.1-flash-lite',
    });
    expect(result.ok).toBe(true);
    expect(captured).toEqual([prompt]);
  });

  it('limita a expansão relacional a oito fatos adicionais', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const session = memory.createSession('Limite de expansão');
    const root = memory.upsertFact({ category: 'project', key: 'capri_memory_root', content: 'Capri Memory Engine arquitetura central.', userConfirmed: true, importance: 10 });
    for (let i = 0; i < 12; i++) {
      const fact = memory.upsertFact({ category: 'knowledge', key: `connected_${i}`, content: `Fato conectado de baixa sobreposição número ${i}.`, userConfirmed: true });
      memory.relateFacts(root.id, fact.id, 'related_to');
    }
    const context = memory.buildPortableContext(session.id, undefined, 'Capri Memory Engine arquitetura central', { maxContextTokens: 200000 });
    expect(context.factsCount).toBeLessThanOrEqual(9);
  });


  it('migra a trilha de eventos v2 para v3 preservando eventos e permitindo rejeição, com idempotência', () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-memory-events-v3-'));
    const dbPath = path.join(tempDir, 'events-v2.db');
    try {
      const legacy = new Database(dbPath);
      legacy.pragma('foreign_keys = ON');
      legacy.exec(`
        CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL);
        INSERT INTO schema_migrations VALUES (2, 'memory-v2', '2026-01-01T00:00:00.000Z');
        CREATE TABLE sessions (id TEXT PRIMARY KEY, title TEXT NOT NULL, active_model_override TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE memory_facts (id TEXT PRIMARY KEY, content TEXT NOT NULL);
        CREATE TABLE memory_events (id TEXT PRIMARY KEY, memory_fact_id TEXT NOT NULL,
          event_type TEXT NOT NULL CHECK (event_type IN ('created','updated','confirmed','conflict_detected','superseded','deactivated','reactivated')),
          old_value_json TEXT, new_value_json TEXT, actor_type TEXT NOT NULL DEFAULT 'system', actor_id TEXT,
          created_at TEXT NOT NULL, FOREIGN KEY (memory_fact_id) REFERENCES memory_facts(id) ON DELETE CASCADE);
        INSERT INTO memory_facts VALUES ('fact-v2', 'preservar');
        INSERT INTO memory_events VALUES ('event-v2', 'fact-v2', 'created', NULL, '{"content":"preservar"}', 'user', NULL, '2026-01-01T00:00:00.000Z');
      `);
      legacy.close();

      const migrated = createDatabase(dbPath);
      expect(migrated.prepare('SELECT event_type, new_value_json FROM memory_events WHERE id = ?').get('event-v2'))
        .toEqual({ event_type: 'created', new_value_json: '{"content":"preservar"}' });
      migrated.prepare(`INSERT INTO memory_events (id, memory_fact_id, event_type, actor_type, created_at)
        VALUES ('event-rejected', 'fact-v2', 'proposal_rejected', 'admin', '2026-01-02T00:00:00.000Z')`).run();
      expect(migrated.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = 3').get()).toEqual({ n: 1 });
      migrated.close();

      const reopened = createDatabase(dbPath);
      expect(reopened.prepare('SELECT COUNT(*) AS n FROM memory_events').get()).toEqual({ n: 2 });
      expect(reopened.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = 3').get()).toEqual({ n: 1 });
      reopened.close();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  it('faz rollback da migração v3 sem perder eventos v2 quando a gravação da versão falha', () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'capri-memory-events-v3-rollback-'));
    const dbPath = path.join(tempDir, 'events-v2-rollback.db');
    try {
      const legacy = new Database(dbPath);
      legacy.pragma('foreign_keys = ON');
      legacy.exec(`
        CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL);
        INSERT INTO schema_migrations VALUES (2, 'memory-v2', '2026-01-01T00:00:00.000Z');
        CREATE TABLE sessions (id TEXT PRIMARY KEY, title TEXT NOT NULL, active_model_override TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE memory_facts (id TEXT PRIMARY KEY, content TEXT NOT NULL);
        CREATE TABLE memory_events (id TEXT PRIMARY KEY, memory_fact_id TEXT NOT NULL,
          event_type TEXT NOT NULL CHECK (event_type IN ('created','updated','confirmed','conflict_detected','superseded','deactivated','reactivated')),
          old_value_json TEXT, new_value_json TEXT, actor_type TEXT NOT NULL DEFAULT 'system', actor_id TEXT,
          created_at TEXT NOT NULL, FOREIGN KEY (memory_fact_id) REFERENCES memory_facts(id) ON DELETE CASCADE);
        INSERT INTO memory_facts VALUES ('fact-v2', 'preservar');
        INSERT INTO memory_events VALUES ('event-v2', 'fact-v2', 'created', NULL, NULL, 'user', NULL, '2026-01-01T00:00:00.000Z');
        CREATE TRIGGER fail_audit_r2_migration BEFORE INSERT ON schema_migrations WHEN NEW.version = 3
          BEGIN SELECT RAISE(ABORT, 'injected audit-r2 migration failure'); END;
      `);
      legacy.close();

      expect(() => createDatabase(dbPath)).toThrow('injected audit-r2 migration failure');
      const afterFailure = new Database(dbPath);
      expect(afterFailure.prepare('SELECT COUNT(*) AS n FROM memory_events WHERE id = ?').get('event-v2')).toEqual({ n: 1 });
      expect(afterFailure.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = 3').get()).toEqual({ n: 0 });
      afterFailure.exec('DROP TRIGGER fail_audit_r2_migration');
      afterFailure.close();

      const recovered = createDatabase(dbPath);
      expect(recovered.prepare('SELECT COUNT(*) AS n FROM schema_migrations WHERE version = 3').get()).toEqual({ n: 1 });
      expect(recovered.prepare('SELECT COUNT(*) AS n FROM memory_events WHERE id = ?').get('event-v2')).toEqual({ n: 1 });
      recovered.close();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });


  it('herda a sensibilidade mais protetiva ao propor substituição de um fato private ou restricted', async () => {
    const { MemoryEngine } = await import('../src/server/core/memory-engine.ts');
    const memory = new MemoryEngine(db);
    const original = memory.upsertFact({ category: 'knowledge', key: 'restricted_replacement', content: 'Informação reservada original.', sensitivity: 'restricted', userConfirmed: true });
    const proposal = memory.upsertFact({ category: 'knowledge', key: 'restricted_replacement', content: 'Informação reservada atualizada.', userConfirmed: false });
    expect(proposal.status).toBe('pending_confirmation');
    expect(proposal.sensitivity).toBe('restricted');
    expect(memory.confirmFact(proposal.id)?.sensitivity).toBe('restricted');
    expect(memory.listFacts(false).find((fact) => fact.id === original.id)?.status).toBe('superseded');
  });

});
