# Capri Core v3.2.0 audit-r1 — Resultados individuais

| Teste/verificação | Resultado | Observação |
|---|---|---|
| Parser TypeScript/TSX | APROVADO | 30 arquivos; TypeScript global 5.8.3; zero erros de sintaxe. |
| Imports relativos | APROVADO | Zero imports relativos sem arquivo de destino. |
| `package.json` JSON | APROVADO | Parse válido. |
| `bun.lock` | BLOQUEADO | Bun CLI ausente; lockfile não foi validado pelo parser Bun. |
| Quantidade de casos Vitest preparados | APROVADO (inventário) | 27 casos declarados no arquivo de testes; não executados.
| ZIP pré-auditoria | APROVADO | `unzip -t` sem erros. |
| Backup v3.1.1 | APROVADO | `unzip -t` sem erros; hash preservado. |
| SQL: banco legado vazio | APROVADO (réplica SQL) | Estrutura de migração criada no harness Python/SQLite. |
| SQL: sessão/mensagem/fato legado | APROVADO (réplica SQL) | Registros preservados e metadados padrão aplicados. |
| SQL: execução repetida | APROVADO (réplica SQL) | Migração versionada sem duplicação. |
| SQL: `foreign_key_check` | APROVADO (réplica SQL) | Sem violações no cenário sintético. |
| SQL: exclusão de fato → eventos/relações | APROVADO (réplica SQL) | Cascatas verificadas. |
| SQL: exclusão de sessão → mensagens/fatos de sessão | APROVADO (réplica SQL) | Cascatas verificadas. |
| SQL: falha injetada e rollback | APROVADO (réplica SQL) | Colunas/tabelas novas não permaneceram. |
| Migração real `better-sqlite3` | BLOQUEADO | Dependência não instalada; teste Vitest preparado, não executado. |
| Persistência real após reabrir DB | BLOQUEADO | Teste existe, Vitest indisponível. |
| Recuperação entre sessões | BLOQUEADO | Teste existe, Vitest indisponível. |
| Isolamento de memórias temporárias | BLOQUEADO | Correção e teste adicionados, Vitest indisponível. |
| Atualização/contradição/confirmar | BLOQUEADO | Testes existem/foram ampliados, Vitest indisponível. |
| API e autorização | BLOQUEADO | Testes de API existentes e teste de fatos restritos ampliado, runtime indisponível. |
| Fallback e contexto comum | BLOQUEADO | Testes unitários existentes, Vitest indisponível. |
| Seis adaptadores | NÃO TESTADO | Inspeção de código; nenhuma chamada real autenticada. |
| Concorrência SQLite | NÃO TESTADO | Não foi possível executar `better-sqlite3`/Vitest. |
| `npm run typecheck` | BLOQUEADO | TS2688: `node` e `vite/client` ausentes. |
| `npm test` | BLOQUEADO | `vitest: not found`. |
| `npm run build` | BLOQUEADO | `vite: not found`. |

## Evidência de rede e dependências

`npm ping --fetch-retries=0 --fetch-timeout=8000` retornou `EAI_AGAIN` ao resolver `registry.npmjs.org`. `node_modules` está ausente, Bun não está instalado e o pacote não contém `package-lock.json`. Não foi feita instalação com npm que pudesse ignorar `bun.lock` e resolver versões diferentes.

## Resultado global

**NÃO CERTIFICADO.** Os resultados APROVADOS são apenas verificações estáticas, de integridade de arquivos e uma réplica independente do DDL. Os testes funcionais de aplicação continuam bloqueados ou não testados.
