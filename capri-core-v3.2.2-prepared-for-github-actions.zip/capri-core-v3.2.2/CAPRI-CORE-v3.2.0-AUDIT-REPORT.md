# Capri Core v3.2.0 — Relatório de Auditoria Técnica (audit-r1)

**Data:** 2026-11-26  
**Base auditada:** `capri-core-project-v3.2.0.zip` (pré-auditoria)  
**Escopo:** inspeção de código, correções localizadas, revisão de migração, segurança de memória, contexto/orquestração e preparação de validação.  
**Status geral:** **NÃO CERTIFICADA** — validações funcionais essenciais permanecem bloqueadas pela indisponibilidade do registry npm e pela ausência das dependências.

## 1. Preservação e cadeia de custódia

- A v3.1.1 original não foi modificada.
- O backup original da v3.1.1 não foi sobrescrito. O ZIP de backup preservado e o ZIP v3.1.1 de entrega têm hashes de contêiner diferentes, mas a comparação das árvores extraídas não encontrou diferenças de arquivos.
- Antes de qualquer correção, foi criado backup integral da árvore de desenvolvimento v3.2.0 e cópia do ZIP original.
- A cópia de desenvolvimento auditada é isolada.
- Nenhum banco real foi aberto, migrado ou alterado. O pacote não contém um banco de dados de produção/usuário.
- Não houve publicação, deploy ou exposição de API.

### Hashes preservados

- ZIP v3.2.0 pré-auditoria: `2af7eaa5b6c452b629a9fc139292a7ac4392510457bc6134e775177bb2d832f1`
- Backup original v3.1.1: `a5740397f2a2bb06c7924f5cfe9e3936d08d0928eb599f28b46b9755c351bb43`

## 2. Inventário e escopo inspecionado

O pacote contém 43 entradas na versão pré-auditoria, incluindo 30 arquivos TypeScript/TSX. Foram inventariados os arquivos do projeto e inspecionados os caminhos centrais de memória, banco, API, frontend, orquestração, Smart Router, adaptadores, registro de modelos, cotas, exportação e configuração de execução.

Arquivos centrais revisados:

- `src/server/core/memory-engine.ts`
- `src/server/core/shared-memory.ts`
- `src/server/core/orchestrator.ts`
- `src/server/db/database.ts`
- `src/server/routes/api.ts`
- `src/core/types.ts`
- `src/lib/api.ts`
- `src/components/MemoryView.tsx`
- `tests/capri-core.test.ts`
- `src/server/adapters/{index,base,gemini.adapter,openai-compatible.adapter,anthropic.adapter}.ts`
- `src/server/core/{smart-router,model-registry,quota-controller,intent-classifier,project-exporter}.ts`
- `server.ts`, `package.json`, `bun.lock`, `tsconfig.json`, `vite.config.ts`, `.env.example`, `README.md`

## 3. Problemas encontrados e correções aplicadas

| Prioridade | Problema encontrado | Correção na cópia audit-r1 |
|---|---|---|
| Alta | Memórias `temporary` eram selecionadas sem filtro de sessão, permitindo contexto temporário de uma conversa em outra. | `temporary` agora exige `sessionId`, é gravada com essa sessão e recuperada somente nessa sessão. |
| Alta | `PATCH` podia sobrescrever conteúdo/chave/categoria de um fato ativo sem confirmação. | Alterações de conteúdo passam a criar proposta pendente relacionada ao fato anterior. Propostas pendentes podem ser revisadas sem ativação; a confirmação continua explícita. |
| Alta | `GET /memory` e histórico podiam expor fatos `restricted` ao token comum. | Rotas de listagem/histórico ocultam fatos `restricted` de usuários não administradores. O token administrativo continua autorizado. |
| Média | `confirmFact` consultava a proposta antes de abrir a transação, criando janela de corrida. | Consulta e confirmação agora ocorrem dentro de transação `IMMEDIATE`. |
| Média | Atualização de metadados não era transacional. | `updateFact` agora executa em transação `IMMEDIATE`. |
| Média | Datas com offsets distintos eram comparadas como texto e podiam ser interpretadas incorretamente. | Novas datas e datas atualizadas são normalizadas para ISO UTC antes da persistência. |
| Média | `listFacts(true)` não considerava `valid_from`. | A listagem de fatos ativos também respeita início de validade e expiração. |
| Média | Propostas idênticas podiam ser duplicadas em chamadas repetidas. | `upsertFact` reaproveita uma proposta pendente idêntica. |
| Média | Atualizar fato existente podia apagar a expiração ao omitir `expiresAt`. | O valor de expiração existente é preservado quando o campo não é fornecido. |
| Média | Falha durante inicialização/migração podia deixar conexão SQLite aberta. | `createDatabase` fecha a conexão se a inicialização falhar. |
| Média | A migração de memória verificava colunas antes de adquirir lock, com risco de corrida entre inicializações simultâneas. | Rechecagem da versão e colunas foi movida para dentro da transação `IMMEDIATE`. |

### Arquivos de código modificados

1. `src/server/core/shared-memory.ts`
2. `src/server/db/database.ts`
3. `src/server/routes/api.ts`
4. `tests/capri-core.test.ts`

Não foram adicionadas dependências e não foram removidas funcionalidades do projeto. A alteração de conteúdo via `PATCH` foi preservada como proposta pendente, em vez de sobrescrita silenciosa.

## 4. Arquitetura e comportamento observados

### Memória e persistência

- `memory_facts` permanece como repositório canônico.
- `sessions` e `messages` permanecem como histórico e sessões.
- `memory_relations` e `memory_events` são tabelas adicionais.
- Fatos de longo prazo são elegíveis entre sessões.
- Fatos de sessão e temporários são limitados à sessão associada.
- Expiração é aplicada na recuperação; registros expirados não são removidos automaticamente do SQLite.
- A extração automática existente reconhece diretivas explícitas de memória. Não foi encontrada sumarização automática geral de conversas antigas.

### Orquestrador, Smart Router e fallback

- O orquestrador instancia um único `MemoryEngine` e mantém `sharedMemory` como alias compatível para a mesma instância.
- O contexto portátil é montado antes de gravar a mensagem atual.
- O mesmo `systemInstruction` e histórico são enviados à tentativa primária e às tentativas de fallback.
- O Smart Router recebe estimativa do tamanho de contexto e mantém a seleção/fallback existentes.

### Seis provedores

- Gemini usa `systemInstruction` e histórico do contexto.
- Anthropic recebe `system` e histórico.
- OpenAI, Groq, DeepSeek e xAI usam `OpenAICompatibleAdapter`, com a instrução de sistema e histórico na mesma estrutura de mensagens.
- A compatibilidade é sustentada pela leitura do código e pela interface comum dos adaptadores. Não houve chamadas reais autenticadas aos seis provedores nesta auditoria.

## 5. Limitações e pendências identificadas

Estas questões não foram alteradas porque exigem validação funcional ou decisão de política/arquitetura:

1. **`MemoryEngine` é uma subclasse fina:** a lógica efetiva permanece em `SharedMemoryManager`. Existe uma instância central compartilhada, mas a separação de responsabilidades ainda é nominal.
2. **Recuperação heurística:** usa sobreposição lexical, importância, confiança, recência e bônus de relações. A consulta limita os candidatos a 250 fatos antes do ranking; isso pode omitir um fato antigo e relevante.
3. **Relações não são percorridas:** a quantidade de relações influencia a pontuação, mas o conteúdo dos fatos vizinhos não é expandido automaticamente para o contexto.
4. **Orçamento aproximado:** tokens são estimados por caracteres divididos por quatro. Orçamento de memória e histórico é separado; a estimativa não equivale ao tokenizer de cada provedor. O `systemPrompt` customizado também não tem limite próprio.
5. **Continuidade entre sessões é baseada em fatos:** mensagens antigas de outras sessões não são recuperadas como histórico; não existe sumarizador de sessão implementado. Portanto, não se deve prometer recuperação de qualquer detalhe conversacional anterior se ele não tiver sido promovido a fato.
6. **Sensibilidade `private`:** a regra atual exclui `restricted` do contexto enviado ao provedor, mas `private` ainda pode ser incluída. É necessária uma decisão explícita sobre se `private` também deve ficar fora de chamadas a provedores externos.
7. **Rejeição de proposta:** o tipo `rejected` existe, mas não foi identificado endpoint/método de rejeição de propostas pendentes.
8. **Escopo de autenticação:** o servidor é desenhado como instalação local de usuário único. O token comum pode consultar dados de memória não restritos e sessões. Não há isolamento multiusuário/por proprietário de sessão.
9. **Armazenamento em repouso:** SQLite é persistido sem criptografia de banco implementada no projeto.
10. **Expiração:** fatos expirados deixam de ser recuperados, mas permanecem armazenados e aparecem em listagens administrativas não filtradas.

## 6. Migração v3.1.1 → v3.2.0

A migração v2 é aditiva: acrescenta colunas em `memory_facts`, cria `memory_relations` e `memory_events`, cria índices e registra a versão em `schema_migrations`. `sessions`, `messages` e `memory_facts` são preservadas. A chave estrangeira `session_id` em `memory_facts` usa `ON DELETE CASCADE`; relações e eventos também usam cascata ao excluir o fato.

Foi criado um teste Vitest de migração usando banco legado em arquivo, com preservação de sessão/mensagem/fato, repetição da migração, integridade referencial e cascatas. Foi criado também teste de rollback por falha injetada no registro da migração.

Além disso, um harness independente em Python/SQLite executou uma réplica do DDL da migração e passou 12 verificações. **A réplica não executa a função TypeScript `migrateMemoryEngine` nem usa `better-sqlite3`; portanto, a migração real permanece BLOQUEADA até Vitest e runtime estarem disponíveis.**

Nenhum banco de usuário/produção foi migrado.

## 7. Resultados de validação

| Critério | Status | Evidência/limite |
|---|---|---|
| Integridade do ZIP pré-auditoria | APROVADO | `unzip -t` sem erros; SHA-256 preservado. |
| Inventário e parsing TypeScript/TSX | APROVADO | 30 arquivos; parser TypeScript 5.8.3 reportou zero erros sintáticos. |
| Imports relativos | APROVADO | Nenhum destino relativo ausente no verificador estático. |
| JSON de `package.json` | APROVADO | Parse válido. |
| SQL da migração (réplica Python/SQLite) | APROVADO | 12 verificações passaram; não é execução da função de produção. |
| Migração real com `better-sqlite3` | BLOQUEADO | Dependência ausente; registry npm retorna `EAI_AGAIN`. |
| Persistência real via Capri Core | BLOQUEADO | Testes Vitest não executáveis. |
| Recuperação entre sessões | BLOQUEADO | Teste existe; Vitest não executável. |
| Isolamento de sessão/temporária | BLOQUEADO | Correção e teste adicionados; Vitest não executável. |
| Contradição e confirmação | BLOQUEADO | Testes existentes/atualizados; Vitest não executável. |
| Exclusão e cascatas via aplicação | BLOQUEADO | DDL foi simulado; camada `better-sqlite3` não executada. |
| Endpoints/API de memória | BLOQUEADO | Código revisado e teste de visibilidade restrita adicionado; servidor de teste não executável. |
| Compartilhamento nos seis provedores | BLOQUEADO | Caminhos dos adaptadores revisados; sem testes de integração autenticados. |
| Fallback com mesmo contexto | BLOQUEADO | Caminho do orquestrador e testes unitários existentes revisados; Vitest não executável. |
| TypeScript typecheck | BLOQUEADO | `tsc --noEmit` falhou antes da análise por ausência de `@types/node` e `vite/client`. |
| Vitest | BLOQUEADO | `vitest: not found`. |
| Build de produção | BLOQUEADO | `vite: not found`. |
| Testes de concorrência reais | NÃO TESTADO | Sem runtime `better-sqlite3` e Vitest. |
| Integração real com provedores | NÃO TESTADO | Sem credenciais e sem execução de rede autenticada. |
| Certificação para produção | REPROVADO | Critérios essenciais funcionais permanecem bloqueados/não testados. |

### Comandos realmente executados

- `npm ping --fetch-retries=0 --fetch-timeout=8000` → `EAI_AGAIN registry.npmjs.org`.
- `npm run typecheck` → erro TS2688 por ausência de tipos Node/Vite.
- `npm test` → `vitest: not found`.
- `npm run build` → `vite: not found`.
- Parser estático TypeScript 5.8.3 em 30 arquivos → 0 erros de sintaxe e 0 imports relativos sem destino.
- Harness Python/SQLite 3.46.1 → 12 verificações de DDL/cascata/rollback passaram.

O TypeScript global 5.8.3 não é substituto para o compilador declarado no lockfile do projeto (`typescript` 7.x). O resultado de parsing é exclusivamente sintático.

## 8. Instalação e execução quando o ambiente estiver disponível

O projeto contém `bun.lock`; para respeitar as versões fixadas, usar Bun e instalação congelada, sem atualizar o lockfile:

```bash
bun install --frozen-lockfile
bun run typecheck
bun run test
bun run build
```

Para iniciar em desenvolvimento, depois de configurar `.env` com tokens distintos de pelo menos 32 caracteres e as chaves dos provedores desejados:

```bash
bun run dev
```

Configurações essenciais:

- `CAPRI_API_TOKEN`: token comum, mínimo 32 caracteres.
- `CAPRI_ADMIN_TOKEN`: token administrativo diferente, mínimo 32 caracteres.
- `CAPRI_HOST=127.0.0.1` como bind padrão.
- `CAPRI_DB_PATH` opcional para apontar a um banco de teste.

Não usar um banco de produção para os testes de migração. Criar cópia física do banco, verificar o hash da cópia e apontar `CAPRI_DB_PATH` para ela.

## 9. Conclusão

A cópia audit-r1 recebeu correções localizadas e testes adicionais foram preparados. A validação sintática e a réplica SQL passaram. Entretanto, a migração real, o typecheck completo, Vitest, build, API em runtime, concorrência e chamadas reais dos provedores não foram executados.

**A Capri Core v3.2.0 audit-r1 não está certificada nem pronta para produção.** O próximo marco obrigatório é restaurar acesso ao registry, instalar exatamente o lockfile Bun e executar a suíte completa sobre banco descartável/cópia de teste.
