# Comparação audit-r1 → audit-r2 → auditoria final

## Comparação de estrutura audit-r1 → audit-r2 original

| Métrica | Resultado |
|---|---:|
| Arquivos audit-r1 | 45 |
| Arquivos audit-r2 | 60 |
| Adicionados | 15 |
| Removidos | 0 |
| Alterados | 17 |
| Dependências adicionadas/atualizadas | 0 |

### Arquivos adicionados na audit-r2

- `src/server/core/context-budget.ts`
- `src/server/core/memory-policy.ts`
- `src/server/core/memory-relations.ts`
- `CAPRI-CORE-v3.2.0-AUDIT-R2-REPORT.md`
- `CAPRI-CORE-v3.2.0-AUDIT-R2-TEST-RESULTS.md`
- `audit-r2/evidence/r1/*` (evidências históricas preservadas)
- `audit-r2/evidence/r2/*` (evidências da implementação audit-r2)

### Arquivos alterados na audit-r2

`README.md`, `SHA256SUMS.txt`, `metadata.json`, `src/App.tsx`, `src/components/MemoryView.tsx`, `src/components/UsageApiView.tsx`, `src/lib/api.ts`, `src/server/adapters/anthropic.adapter.ts`, `src/server/adapters/base.ts`, `src/server/adapters/gemini.adapter.ts`, `src/server/adapters/openai-compatible.adapter.ts`, `src/server/core/memory-engine.ts`, `src/server/core/orchestrator.ts`, `src/server/core/shared-memory.ts`, `src/server/db/database.ts`, `src/server/routes/api.ts`, `tests/capri-core.test.ts`.

## Lockfiles

- `package.json` SHA-256: `769038014f5aaf0332b25f05e9e17db19bffdbd1c70293d51cf83225edec2a3f` — idêntico à audit-r1.
- `bun.lock` SHA-256: `4b938e4811b07062aa70f3fab74e4b81c9ad30ed53d11cc37bf71dae279680f7` — idêntico à audit-r1.

## Correções independentes da auditoria final sobre audit-r2

Somente na cópia final foram alterados:

- `src/server/core/context-budget.ts` — estimador heurístico com contagem individual de code points não latinos.
- `src/server/core/memory-engine.ts` — cálculo do footprint obrigatório para roteamento e redação de conteúdos private/restricted em histórico anterior.
- `src/server/core/orchestrator.ts` — consulta do registro de modelos antes do cálculo de contexto; remoção do pré-orçamento fixo de 8k.
- `src/server/core/shared-memory.ts` — consulta eficiente de conteúdos sensíveis e bloqueio de reativação de fatos substituídos.
- `src/server/core/smart-router.ts` — elegibilidade por orçamento de entrada após reserva/margem, com mensagens de bloqueio corretas.
- `tests/capri-core.test.ts` — novos testes e ampliações de cenários.

Nenhum arquivo da audit-r1 ou da audit-r2 original foi modificado. O patch final contém somente essas diferenças da cópia de auditoria.
