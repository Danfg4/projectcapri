# Capri Core v3.2.2 — Guia de certificação pelo GitHub Actions

**Estado:** ambiente preparado; certificação funcional ainda pendente. O workflow não declara sucesso antes da execução real e contém um gate de cobertura que verifica a presença do teste de concorrência com conexões SQLite independentes; a aprovação depende da execução real desse teste.

## O que o workflow faz

- Executa em `push`, `pull_request` e `workflow_dispatch` (execução manual).
- Usa runner `ubuntu-24.04`, Bun `1.4.5` fixado e actions oficiais com referências fixas.
- Executa `bun install --frozen-lockfile` e verifica que o hash de `bun.lock` permanece idêntico.
- Executa `bun run typecheck`, a suíte Vitest completa por `bun run test:certification` (40 testes originais + 1 teste adicional de concorrência em processos Bun) e `bun run build`.
- Publica logs e relatórios mesmo se uma etapa anterior falhar.
- Não executa `npm`, não injeta chaves reais e não chama provedores pagos. As variáveis de chave dos seis provedores ficam vazias.
- Usa apenas `contents: read`; não usa `pull_request_target`, não grava no repositório e não entrega segredos a PRs de forks.

## Colocar o projeto em um repositório GitHub

1. Baixe e extraia o ZIP `capri-core-v3.2.2-prepared-for-github-actions.zip` no celular (aplicativo **Arquivos** → toque no ZIP → **Extrair**).
2. Entre em [github.com](https://github.com) e faça login ou crie uma conta.
3. Toque no botão **+** e escolha **New repository**. Dê um nome como `capri-core` e deixe o repositório **Private** se não quiser publicar o código.
4. Crie o repositório sem adicionar README, `.gitignore` ou licença (esses arquivos já vêm no pacote).
5. O GitHub precisa receber os arquivos e pastas extraídos na raiz do repositório — especialmente `package.json`, `bun.lock`, `src/`, `tests/`, `scripts/` e `.github/workflows/`. Não envie somente o ZIP dentro do repositório: o GitHub não extrai ZIP automaticamente.
6. No navegador do celular, abra o repositório, use **Add file → Upload files**. Se o seletor do Android não permitir selecionar pastas completas preservando a estrutura, use o navegador em **modo para computador** e faça upload da pasta extraída (arraste a pasta para a área de upload, quando suportado). Confira antes de confirmar que `.github/workflows/capri-certification.yml` aparece com esse caminho exato.
7. Confirme em **Commit changes**. O primeiro `push` inicia o workflow automaticamente.

> Dica para celular: a etapa de envio de muitas pastas pode ser limitada pelo navegador/app. Se não conseguir preservar os caminhos, não crie os arquivos manualmente nem envie apenas o ZIP; peça ajuda para fazer o primeiro upload por um computador ou por um serviço de sincronização Git confiável. Depois disso, a execução e o download dos relatórios podem ser feitos pelo celular.

## Ativar e executar manualmente

1. No repositório, toque na aba **Actions**.
2. Se o GitHub mostrar a mensagem para habilitar workflows, toque em **I understand my workflows, go ahead and enable them**.
3. Abra **Capri Core — certificação funcional** na lista à esquerda.
4. Toque em **Run workflow**, escolha a branch principal e confirme em **Run workflow**.
5. Abra a execução mais recente para acompanhar cada etapa. Uma etapa vermelha indica falha; etapas posteriores podem aparecer como ignoradas quando uma etapa obrigatória falha.

## Onde baixar os relatórios

1. Abra a execução em **Actions**.
2. Desça até **Artifacts** no fim da página.
3. Baixe `capri-core-certification-N` (o número varia por execução).
4. No celular, toque no ZIP baixado e extraia-o.

Dentro do artefato:

- `certification/reports/test-results-individual.md` e `.json`: resultado de cada teste.
- `certification/reports/test-summary.md` e `.json`: resumo geral.
- `certification/reports/typecheck-report.json` e `build-report.json`: estado dessas etapas.
- `certification/reports/sqlite-migration-evidence.json`: evidências dos testes SQLite/migrações.
- `certification/reports/security-privacy-report.json`: HTTP/autorização, privacidade e adaptadores stub.
- `certification/reports/concurrency-evidence.json`: resultado do teste concorrente com processos independentes.
- `certification/reports/coverage-gaps.md` e `.json`: lacunas que bloqueiam a certificação.
- `certification/logs/`: logs sanitizados, incluindo falhas.
- `certification/reports/SHA256SUMS.txt`: hashes SHA-256 dos relatórios, logs e arquivos de build existentes.
- `dist/`: build de produção, se a etapa de build tiver sido concluída.

## Como interpretar falhas

- **Install:** falha no Bun, registry, dependência nativa ou lockfile. O comando é congelado; não execute `bun install` sem `--frozen-lockfile` para tentar contornar.
- **Typecheck:** erro de tipos; corrigir a origem, sem desativar `strict` nem relaxar verificações.
- **Vitest:** relatório individual mostra o teste e a falha. Os 40 testes originais e o teste adicional de concorrência (41 no total) precisam executar; nenhum teste ignorado conta como aprovação.
- **Build:** erro no Vite ou ausência de `dist/index.html`.
- **Coverage gate:** bloqueia a certificação se a matriz obrigatória estiver incompleta. O pacote acrescenta um teste com quatro processos Bun e conexões SQLite independentes. A presença do teste não equivale a aprovação: ele precisa passar na execução real do Vitest.
- **Artifact:** mesmo com falha, o workflow tenta publicar relatórios e logs. Se não houver artefato, verifique a etapa de upload.

## Segurança

- Não cadastre tokens nem chaves de provedores em **Secrets** para este workflow.
- Não altere o evento para `pull_request_target`.
- Não conceda permissões `write` ao `GITHUB_TOKEN`.
- Os tokens que aparecem nos testes HTTP são valores locais de teste, não credenciais de serviço.

## Critério de certificação

A v3.2.2 está **preparada para certificação automatizada**, não funcionalmente certificada. A certificação só poderá ser declarada depois de uma execução real no GitHub com instalação congelada, typecheck, os 40 testes originais, o teste de concorrência independente, build e todos os gates de cobertura obrigatórios aprovados.
