# Capri Core v3.2.0 — Memory Engine: arquitetura e validação

## Estado da entrega

Esta é uma cópia de desenvolvimento derivada da v3.1.1. A versão original não foi modificada. A migração é aditiva e transacional. Dependências npm não estavam disponíveis no ambiente: `node_modules` não existe e a resolução DNS de `registry.npmjs.org` não retornou endereço. Por isso, Vitest, TypeScript typecheck, build e integração real com provedores não podem ser declarados aprovados.

## Auditoria confirmada da base

- `memory_facts` continha `id`, `category`, `key`, `content`, `source_model`, `importance`, `active`, `created_at`, `updated_at`.
- `sessions` e `messages` são o histórico; mensagens são removidas em cascata ao excluir sessão.
- `SharedMemoryManager` era instanciado uma vez no `CapriCoreOrchestrator`.
- O contexto anterior selecionava até 20 fatos por importância/atualização e até 14 mensagens da sessão atual, sem busca contextual entre sessões.
- Os seis provedores (Gemini, Groq, OpenAI, Anthropic, DeepSeek e xAI) recebem `systemInstruction` e `history` do mesmo ponto central do orquestrador.

## Modelo de dados definitivo

### Tabelas preservadas

- `sessions`: sessões e preferências de modelo por sessão.
- `messages`: histórico conversacional vinculado à sessão.
- `memory_facts`: registro canônico de memória, sem uma tabela paralela de itens ou preferências.

### Novas tabelas

`memory_relations`

- Chave composta: `(from_fact_id, to_fact_id, relation_type)`.
- Tipos: `related_to`, `contradicts`, `supersedes`, `derived_from`.
- Chaves estrangeiras com `ON DELETE CASCADE`.

`memory_events`

- Um evento por criação, atualização, confirmação, conflito detectado ou substituição.
- Guarda snapshots JSON anterior/novo e ator.
- Eventos acompanham o ciclo de vida do fato; excluir o fato exclui seus eventos para que a exclusão seja efetiva também no histórico.

### Colunas aditivas em `memory_facts`

- `scope`: `long_term`, `session`, `temporary`.
- `session_id`: obrigatório para escopo `session`, FK para `sessions` com cascata.
- `source_type`, `source_ref`: proveniência.
- `confidence`: número entre 0 e 1.
- `user_confirmed`: confirmação explícita.
- `status`: `active`, `pending_confirmation`, `superseded`, `rejected`.
- `valid_from`, `expires_at`: validade temporal.
- `last_accessed_at`: telemetria de recuperação.
- `superseded_by`: referência lógica ao registro substituto.
- `sensitivity`: `normal`, `private`, `restricted`; `restricted` não é injetado no contexto.

### Como os tipos lógicos são representados

| Tipo lógico | Representação |
|---|---|
| Longo prazo | `scope='long_term'` |
| Sessão | `scope='session'` + `session_id` |
| Temporária | `scope='temporary'` + `expires_at` obrigatório |
| Preferência | `category='preference'` |
| Conhecimento aprendido | `category='knowledge'` + proveniência/confiança |
| Confirmação | `user_confirmed` + evento `confirmed` |
| Contradição | candidato pendente + relação `contradicts` |
| Atualização/substituição | `memory_events` + relação `supersedes` |

## Migração SQL proposta e implementada

A migração `schema_migrations.version = 2`, `add-central-memory-engine-metadata-relations-and-event-history`, executa dentro de transação. Ela:

1. Adiciona colunas a `memory_facts` com defaults retrocompatíveis.
2. Cria `memory_relations` e `memory_events`.
3. Cria índices por escopo/estado, sessão, expiração, categoria/importância, relação e histórico.
4. Marca registros antigos como `source_type='legacy'`, confiança `0.65` e não confirmados, sem apagar ou reescrever seu conteúdo.
5. Registra a versão aplicada.

Nenhuma tabela existente é removida ou reconstruída. `sessions`, `messages` e `memory_facts` permanecem.

## Recuperação contextual

A consulta busca fatos ativos, não pendentes, dentro da validade e acessíveis à sessão atual: todos os `long_term`, apenas os `session` da sessão corrente e os `temporary` ainda válidos. Até 250 candidatos são pontuados localmente por:

- sobreposição lexical entre prompt, chave, conteúdo e categoria;
- importância;
- confiança;
- recência;
- bônus limitado por escopo/categoria e relações `related_to`/`derived_from`.

O orçamento inicial é de 1.800 tokens estimados para fatos e 3.200 para histórico recente (estimativa caracteres/4, não tokenizer). A busca não depende de provedor nem de embeddings. O contexto final é montado uma vez pelo Memory Engine e entregue pelo orquestrador ao adaptador selecionado; o fallback reutiliza o mesmo contexto.

## Contradições e atualização

Uma alteração de conteúdo para a mesma chave/categoria/escopo não sobrescreve silenciosamente o fato ativo. Ela cria candidato `pending_confirmation` e relação `contradicts`. A confirmação administrativa via `POST /api/v1/memory/:id/confirm` arquiva o fato anterior, cria relação `supersedes` e confirma o novo. O histórico pode ser consultado em `GET /api/v1/memory/:id/history`. A edição administrativa direta existente continua sendo uma ação de correção explícita e é registrada como evento.

## Compatibilidade

- `orchestrator.sharedMemory` continua exposto como alias compatível.
- Novo `orchestrator.memoryEngine` passa a ser a camada central usada para montar contexto.
- Adaptadores, Smart Router, fallback, cotas, sessões, mensagens e rotas existentes são preservados.
- Endpoints existentes de leitura, criação, edição e exclusão de memória continuam disponíveis; foram adicionados confirmação e histórico.
- Nenhuma dependência foi adicionada ou atualizada. Versão do pacote passa a `3.2.0`.

## Arquivos alterados

- `package.json`
- `metadata.json`
- `README.md`
- `src/core/types.ts`
- `src/server/db/database.ts`
- `src/server/core/shared-memory.ts`
- `src/server/core/orchestrator.ts`
- `src/server/routes/api.ts`
- `src/lib/api.ts`
- `src/App.tsx`
- `src/components/MemoryView.tsx`
- `tests/capri-core.test.ts`

## Arquivo novo

- `src/server/core/memory-engine.ts`

## Testes adicionados

- Recuperação de memória de longo prazo entre sessões e isolamento de memória de sessão.
- Contradição pendente até confirmação explícita, com preservação do fato anterior e histórico.
- Exigência de expiração para memória temporária e exclusão de registros expirados da recuperação.

## Validações realmente executadas

- `node --experimental-strip-types --check` em todos os arquivos `.ts` do projeto: passou (checagem sintática individual; não é typecheck).
- O parser do TypeScript foi executado sobre os arquivos TS/TSX alterados em modo sem resolução; não reportou diagnósticos de sintaxe TS1xxx, mas a checagem semântica foi bloqueada por módulos e tipos ausentes.
- Migração/esquema SQL reproduzidos em SQLite via Python `sqlite3`: criação das tabelas/índices, backfill legado, relação/evento e cascata de exclusão: passou.
- DNS de `registry.npmjs.org`: não resolveu no momento da verificação.
- `node_modules`: ausente.
- Vitest, typecheck, build, testes de integração e chamadas reais aos seis provedores: não executados.

A validação SQLite por Python verifica o SQL e as restrições essenciais, mas não substitui a execução da migração pelo `better-sqlite3` do projeto.

## Rollback

1. Parar o servidor Capri Core.
2. Fazer cópia do arquivo SQLite atual e dos arquivos `-wal`/`-shm`, se existirem.
3. Restaurar o backup integral v3.1.1 e seu banco correspondente, mantendo o banco v3.2 separado.
4. Não remover manualmente as colunas/tabelas da migração 2 em produção; a restauração do backup é o rollback seguro e evita perda de eventos ou fatos criados após a migração.

O backup de código v3.1.1 foi criado antes das alterações em `backups/capri-core-v3.1.1-pristine-backup.zip`.

## Limitações conhecidas / próximo ciclo

- Recuperação lexical é determinística e barata, mas não entende sinônimos ou relações semânticas profundas.
- Não existe extração automática de conhecimento aprendido a partir de conversas nem sumarização automática de sessões; apenas diretivas explícitas são promovidas.
- O filtro de dados sensíveis na extração explícita é heurístico, não um classificador abrangente.
- `sensitivity='restricted'` impede injeção no prompt, mas não equivale a criptografia em repouso.
- A confirmação e histórico são endpoints protegidos por token administrativo, preservando o modelo de autorização v3.1.1.
- As gravações de memória e confirmações usam transações SQLite `IMMEDIATE`; o teste de concorrência adicionado cobre chamadas concorrentes no mesmo processo, não múltiplos processos/hosts. Migração de um arquivo de banco v3.1.1 com dados reais e rollback operacional precisam de validação com dependências instaladas e cópia de DB real.
