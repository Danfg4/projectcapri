# Capri Core v3.2.2 — ambiente de certificação automatizada

Versão do pacote: `3.2.2` (ambiente preparado para certificação automatizada; não certificada funcionalmente). Evolução incremental da v3.1.1 com Memory Engine central em SQLite. Consulte `CAPRI-CORE-v3.2-MEMORY-ENGINE-TECHNICAL.md` para modelo de dados, migração, recuperação, compatibilidade e limitações. A validação automatizada completa permanece pendente enquanto as dependências não puderem ser instaladas. Consulte `CERTIFICATION-GITHUB-ACTIONS.md` para configurar e executar a certificação pelo celular; o status atual está em `CAPRI-CORE-v3.2.2-CERTIFICATION-STATUS.md`.

Fundação de uma assistente pessoal avançada com arquitetura **Multi-LLM**, construída em **TypeScript**, **Node.js (Express)**, **React** e **SQLite** portável em arquivo único.

O projeto foi desenhado para ser exportado integralmente (ZIP ou GitHub) e executado de forma independente, sem acoplamento a serviços proprietários de hospedagem.

---

## Arquitetura Modular

- **Capri Core Orchestrator** (`src/server/core/orchestrator.ts`): Coordena todo o ciclo de vida da solicitação (classificação de intenção, carregamento de memória compartilhada, roteamento, execução com fallback limitado e auditoria).
- **Intent Classifier** (`src/server/core/intent-classifier.ts`): Classifica solicitações em `general_chat`, `complex_reasoning`, `coding`, `research`, `document_analysis`, `content_generation` e `quick_summary`, estimando complexidade (`low`, `medium`, `high`).
- **Model Registry** (`src/server/core/model-registry.ts`): Cadastra provedores e modelos no SQLite, consulta o catálogo autenticado de cada provedor, confirma o ID do modelo e combina esse resultado com credenciais e limites locais.
- **Smart Router** (`src/server/core/smart-router.ts`): Política adaptativa de 9 regras ponderando intenção, tier de capacidade, economia de recursos, saúde da cota, latência/custo e respeito estrito à escolha manual do usuário.
- **Provider Adapters** (`src/server/adapters/`): Adaptadores desacoplados para **Google Gemini** (`@google/genai`, ativo inicialmente), **Groq**, **OpenAI**, **Anthropic Claude**, **DeepSeek** e **xAI Grok**. Provedores sem chave configurada são sinalizados honestamente como não configurados — nunca simulados.
- **Memory Engine** (`memory-engine.ts`, `memory-policy.ts`, `memory-relations.ts`, `context-budget.ts` e `shared-memory.ts`): camada central única em SQLite; memória de longo prazo, de sessão e temporária; preferências e conhecimento como categorias; proveniência, confiança, confirmação, expiração, relações e trilha de eventos. O mesmo contexto é montado antes da seleção/execução do provedor.
- **Quota & Usage Controller** (`src/server/core/quota-controller.ts`): Limites locais de RPM/RPD/TPD (não são cotas oficiais), cooldown persistente após rate limit/erros de autenticação e registro de latência, tokens e custo estimado. Custo sem taxa local informada permanece desconhecido, nunca zero/free.
- **API Central Independente** (`src/server/routes/api.ts`): Endpoints REST sob `/api/v1` desacoplados da interface web.
- **Voz independente** (`src/lib/voice.ts`): leitura de respostas usando a API nativa de síntese de fala do navegador (`speechSynthesis`), sem chave, chamada ou dependência de qualquer provedor LLM. A disponibilidade de vozes/idiomas depende do navegador e do sistema operacional.

---

## Memory Engine v3.2

- `memory_facts` permanece como tabela canônica. Preferências e conhecimento são categorias, não tabelas paralelas.
- `memory_relations` armazena relações tipadas entre fatos (`related_to`, `contradicts`, `supersedes`, `derived_from`).
- `memory_events` registra criação, alteração, confirmação, conflito e substituição. A exclusão de um fato remove também sua trilha e relações associadas, atendendo à exclusão efetiva dos dados.
- Escopos: `long_term` (compartilhado entre sessões), `session` (restrito a uma sessão) e `temporary` (exige `expiresAt`). Preferências são fatos com categoria `preference`; conhecimento aprendido usa `knowledge` e campos de origem/confiança.
- A recuperação usa correspondência lexical, importância, confiança, recência, escopo, categoria e expansão limitada de relações `related_to`/`derived_from`; nunca expande conflitos ou fatos superseded. O orçamento global considera instrução, memórias, histórico, mensagem atual, reserva de saída e margem conservadora. O cálculo é estimado por caracteres, não é tokenizer exato. Não usa embeddings nem adiciona dependências externas nesta versão.
- Alterações contraditórias geram candidato `pending_confirmation`; a versão anterior continua ativa até confirmação explícita. Propostas pendentes podem ser rejeitadas de forma transacional e idempotente, sem apagar o histórico. A interface apresenta ações de confirmar e rejeitar.
- Instruções explícitas de memória são a única extração automática nesta etapa. Padrões comuns de credenciais e dados sensíveis são excluídos dessa extração; não é um classificador completo de dados sensíveis.
- O histórico de mensagens permanece por sessão. Não há sumarização automática de conversas antigas nem inferência autônoma de novos fatos nesta etapa.

---

## Requisitos

- **Node.js** `>= 22.12.0` (necessário para a linha Vite 8; ambiente alvo Node `22.x`)
- **Bun** (obrigatório para instalação reproduzível usando o `bun.lock` incluído)

---

## Instalação e Execução Local

1. **Instale as dependências com o lockfile preservado:**
   ```bash
   bun install --frozen-lockfile
   ```
   Não substitua por `npm install`: a entrega é fixada por `bun.lock` e não contém `package-lock.json`.

2. **Configure as variáveis de ambiente:**
   ```bash
   cp .env.example .env
   ```
   Edite `.env` e adicione ao menos a chave inicial do Gemini:
   ```env
   PORT=3000
   CAPRI_DB_PATH="./data/capri-core.db"
   GEMINI_API_KEY="sua-chave-gemini"

   # Opcionais — ative conforme tiver suas chaves:
   GROQ_API_KEY=""
   OPENAI_API_KEY=""
   ANTHROPIC_API_KEY=""
   DEEPSEEK_API_KEY=""
   XAI_API_KEY=""
   ```

3. **Execute em modo desenvolvimento:**
   ```bash
   bun run dev
   ```
   Acesse `http://localhost:3000`.

4. **Build e execução em produção:**
   ```bash
   bun run build
   bun run start
   ```

5. **Execute os testes automatizados:**
   ```bash
   bun run test
   ```

6. **Verificação de tipos TypeScript:**
   ```bash
   bun run typecheck
   ```

   **Observação:** o script `lint` atualmente é apenas um alias de `typecheck`; ele não executa ESLint. A configuração/dependência de ESLint não foi adicionada sem acesso verificável ao registry e sem poder atualizar o lockfile de forma reproduzível.

---

## Verificação de modelos, custos e cotas

- Um modelo recém-cadastrado começa como **não verificado**. Ele só entra no roteamento automático depois que o adaptador consulta o catálogo autenticado do provedor e encontra o ID exato.
- Os catálogos são atualizados com cache de cinco minutos; falhas de consulta deixam o modelo como **não verificado**, sem presumir disponibilidade.
- Os limites RPM/RPD/TPD cadastrados são limites operacionais locais, não cotas oficiais retornadas pelo provedor. Cooldowns são persistidos em SQLite.
- Os preços padrão ficam sem taxa configurada. Preencha taxas locais somente quando tiver fonte e data de referência; o custo apresentado é uma estimativa local, não uma fatura oficial. Valores estáticos antigos dos modelos padrão são zerados pela migração v3 para evitar estimativas históricas não verificadas.
- O fallback automático tenta no máximo um modelo por provedor e registra a razão de cada falha/troca. A seleção manual não muda de modelo sem autorização explícita de fallback. O roteador estima o tamanho do contexto por caracteres/3 com margem de segurança (heurística conservadora, não tokenizer) e elimina modelos cujo limite cadastrado seja insuficiente.

## API Central (`/api/v1`)

A API funciona independentemente do frontend React, permitindo integração com apps Android nativos, CLI, automações ou outros clientes.

### Orquestrar uma solicitação
```bash
curl -X POST http://localhost:3000/api/v1/orchestrate \
  -H "Authorization: Bearer $CAPRI_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Compare arquiteturas monolíticas modulares e microsserviços.",
    "routingMode": "auto"
  }'
```

### Segurança da API

Todas as rotas em `/api/v1`, inclusive `/health`, exigem autenticação Bearer. Configure dois segredos distintos, cada um com pelo menos 32 caracteres: `CAPRI_API_TOKEN` para operações autenticadas comuns e `CAPRI_ADMIN_TOKEN` para operações administrativas. O token comum não pode cadastrar/alterar modelos, modificar/excluir memória, criar/alterar/excluir sessões ou exportar o ZIP; essas operações exigem o token administrativo. O servidor falha fechado se os dois tokens não estiverem configurados corretamente.

O frontend solicita os tokens conforme a operação e os mantém somente em memória enquanto a página está aberta (não usa `localStorage` ou `sessionStorage`). O bind padrão é `127.0.0.1`; não exponha a API à LAN/Internet. Para integração Android futura, implemente credenciais individuais por dispositivo, TLS e política de permissões antes de alterar `CAPRI_HOST`.

### Principais Endpoints

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `GET` | `/api/v1/health` | Status do núcleo, banco SQLite e provedores configurados |
| `POST` | `/api/v1/orchestrate` | Executa o pipeline completo do Capri Core |
| `GET` | `/api/v1/models` | Lista modelos registrados com status de credencial, verificação do catálogo e limites locais |
| `POST` | `/api/v1/models` | Registra um novo modelo no Model Registry |
| `PATCH` | `/api/v1/models/:id` | Atualiza limites (RPM/RPD/TPD), prioridade ou ativação |
| `GET` | `/api/v1/memory` | Lista fatos globais persistentes da memória compartilhada |
| `POST` | `/api/v1/memory` | Cria ou atualiza um fato global compartilhado |
| `PATCH` | `/api/v1/memory/:id` | Edita um fato de memória |
| `DELETE` | `/api/v1/memory/:id` | Remove um fato de memória |
| `GET` | `/api/v1/sessions` | Lista sessões multi-modelo |
| `POST` | `/api/v1/sessions` | Cria nova sessão |
| `GET` | `/api/v1/sessions/:id` | Detalhes e mensagens da sessão |
| `PATCH` | `/api/v1/sessions/:id` | Atualiza título ou trava manual de modelo da sessão |
| `GET` | `/api/v1/usage` | Resumo agregado e logs reais de consumo |
| `GET` | `/api/v1/traces` | Histórico de traços de roteamento e fallback |

---

## Exportação e Transferência para GitHub

- O banco SQLite (`data/capri-core.db`) e arquivos `.env` já estão listados no `.gitignore`.
- Ao exportar o projeto em ZIP e subir para um repositório GitHub, basta clonar o repositório, rodar `bun install --frozen-lockfile`, configurar `.env` a partir de `.env.example` e iniciar com `bun run dev` ou `bun run build && bun run start`.


## Audit-r2 — Privacidade e contexto

- Somente fatos `normal` podem ser encaminhados aos provedores. Fatos `private` permanecem visíveis na interface protegida; `restricted` são visíveis apenas com token administrativo.
- Reduzir a classificação de sensibilidade exige endpoint administrativo dedicado e confirmação explícita (`confirmDowngrade: true`).
- A rejeição usa `POST /api/v1/memory/:id/reject`, requer token administrativo e preserva o histórico da proposta.
- A expansão relacional percorre no máximo 8 fatos adicionais e profundidade 2; relações `contradicts` e `supersedes` não são expandidas.
- O orçamento global usa estimativa conservadora de caracteres divididos por três, com margem adicional; não afirma precisão de tokenizer. A reserva de saída é enviada aos adaptadores Gemini, Anthropic e OpenAI-compatible.
- A validação funcional da audit-r2 depende de `bun install --frozen-lockfile`; não foi substituída por resolução npm.
