# Capri Core v3.2.1 — Resultado individual dos 40 testes

**Resultado: BLOQUEADO.** Foram identificados 40 testes Vitest. Nenhum foi executado; não há resultados PASS/FAIL a reportar. Todos permanecem BLOQUEADOS pela ausência do Bun e dependências, e pela falha de DNS para `bun.sh` e `registry.npmjs.org`.

01. **1. Classifica intenções corretamente e equilibra recursos entre modelos econômicos e avançados** — BLOQUEADO
02. **2. Respeita estritamente a prioridade manual do usuário sem substituir silenciosamente** — BLOQUEADO
03. **3. Controla cotas RPM/RPD antes de encaminhar e evita esgotar modelos sem limite** — BLOQUEADO
04. **4. Executa fallback automático limitado preservando memória compartilhada entre modelos** — BLOQUEADO
05. **5. Nunca simula respostas quando nenhum provedor possui chave configurada** — BLOQUEADO
06. **6. Persiste memória compartilhada e histórico de sessão entre trocas explícitas de modelo** — BLOQUEADO
07. **8. Modo manual sem modelo selecionado bloqueia em vez de cair silenciosamente no Smart Router** — BLOQUEADO
08. **9. SQLite em arquivo mantém fatos e mensagens após fechar e reabrir a conexão** — BLOQUEADO
09. **7. API REST /api/v1 valida entradas, expõe status real dos provedores e persiste memória** — BLOQUEADO
10. **10. Não trata um modelo recém-cadastrado como disponível antes de consultar o catálogo autenticado** — BLOQUEADO
11. **11. Não repete tentativas em modelos do mesmo provedor no fallback automático** — BLOQUEADO
12. **12. Preserva histórico de sessão quando o primeiro provedor falha e o fallback usa outro** — BLOQUEADO
13. **13. Seleção manual estrita não troca de modelo após erro de autenticação** — BLOQUEADO
14. **14. Modelo cadastrado com ID ausente no catálogo autenticado fica inválido e não é roteado** — BLOQUEADO
15. **15. Cooldown de provedor permanece no SQLite após recriar o controlador** — BLOQUEADO
16. **16. Migra identificadores legados do catálogo e remove preços padrão não verificados** — BLOQUEADO
17. **17. Smart Router bloqueia seleção manual incompatível com o contexto estimado** — BLOQUEADO
18. **18. Smart Router usa latência observada recente quando há telemetria disponível** — BLOQUEADO
19. **aborta a requisição HTTP quando o timeout é excedido** — BLOQUEADO
20. **recupera fatos de longo prazo em outra sessão e mantém fatos de sessão isolados** — BLOQUEADO
21. **mantém contradições pendentes até confirmação explícita e preserva histórico** — BLOQUEADO
22. **exige validade para memória temporária e não recupera registros expirados** — BLOQUEADO
23. **não permite sobrescrever diretamente fato confirmado e deduplica proposta pendente** — BLOQUEADO
24. **migra banco legado preservando sessões, mensagens e fatos, e é idempotente** — BLOQUEADO
25. **faz rollback integral da migração de memória quando uma etapa falha** — BLOQUEADO
26. **aplica a migração v2 sem remover tabelas-base e mantém esquema de memória compatível** — BLOQUEADO
27. **serializa gravações concorrentes e evita duplicar a mesma memória** — BLOQUEADO
28. **exclui memórias private e restricted do contexto enviado aos provedores** — BLOQUEADO
29. **rejeita proposta pendente de forma transacional e idempotente sem alterar o fato anterior** — BLOQUEADO
30. **expande relações relacionadas sem atravessar sessões, ciclos, duplicações ou conflitos** — BLOQUEADO
31. **aplica orçamento global conservador, reserva resposta e nunca remove a mensagem atual** — BLOQUEADO
32. **mantém MemoryEngine como instância central e envia o mesmo contexto aos seis provedores** — BLOQUEADO
33. **protege alteração de sensibilidade e exige confirmação explícita para reduzir classificação** — BLOQUEADO
34. **prioriza fatos lexicalmente relevantes e evita inserir memórias sem relação com a solicitação** — BLOQUEADO
35. **remove conteúdo private/restricted do histórico antes de reutilizá-lo em provedores externos** — BLOQUEADO
36. **roteia prompts longos pelo limite real dos modelos em vez de um orçamento preliminar fixo de 8k** — BLOQUEADO
37. **limita a expansão relacional a oito fatos adicionais** — BLOQUEADO
38. **migra a trilha de eventos v2 para v3 preservando eventos e permitindo rejeição, com idempotência** — BLOQUEADO
39. **faz rollback da migração v3 sem perder eventos v2 quando a gravação da versão falha** — BLOQUEADO
40. **herda a sensibilidade mais protetiva ao propor substituição de um fato private ou restricted** — BLOQUEADO

Não modificar os testes para fazê-los passar. Retomar a execução após restabelecer o ambiente Bun e instalar com `bun install --frozen-lockfile`.
