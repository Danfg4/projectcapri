# Validação estática do pipeline

Resultado: **VALIDAÇÃO ESTÁTICA APROVADA**
Checks: 26 aprovados; 0 reprovados.

| Verificação | Resultado | Detalhe |
|---|---|---|
| workflow path exists | PASS | .github/workflows/capri-certification.yml |
| YAML syntax | PASS | Ruby Psych parser |
| push trigger | PASS | push event present |
| pull_request trigger | PASS | pull_request event present |
| manual trigger | PASS | workflow_dispatch present |
| Bun exact version | PASS | Bun 1.4.5 pinned |
| frozen install | PASS | exact frozen install command present |
| lockfile hash guard | PASS | bun.lock SHA-256 4b938e4811b07062aa70f3fab74e4b81c9ad30ed53d11cc37bf71dae279680f7 |
| typecheck command | PASS | package script exists |
| Vitest certification command | PASS | JUnit + JSON reporters configured |
| build command | PASS | package build script exists |
| existing test count preserved | PASS | 40 legacy it() cases found; expected 40 |
| independent SQLite concurrency test prepared | PASS | four Bun child processes, independent better-sqlite3 connections, integrity and uniqueness assertions |
| real SQLite test dependency | PASS | better-sqlite3 dependency and import retained |
| no npm in workflow | PASS | workflow has no npm/npx commands |
| minimum permissions | PASS | contents: read only |
| no pull_request_target | PASS | only pull_request; no privileged PR event |
| no injected secrets | PASS | no secret references in workflow |
| provider keys blank | PASS | six provider API keys explicitly empty |
| no paid provider calls | PASS | workflow runs stubs only and supplies no credentials |
| report collector always runs | PASS | report collector and logs are retained after failures |
| coverage gate always emits gap report | PASS | static gate report exists even when earlier stage fails |
| artifact upload always runs | PASS | upload-artifact v7.0.2 release tag |
| artifact paths exist or are generated | PASS | reports, logs and dist paths configured |
| action references verified | PASS | [{"ref":"actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1","immutableSha":true},{"ref":"oven-sh/setup-bun@0c5077e51419868618aeaa5fe8019c62421857d6","immutableSha":true},{"ref":"actions/upload-artifact@v7.0.2","immutableSha":false}] |
| Bun lock format matches pinned version | PASS | lockfileVersion 2 + configVersion 1; Bun >=1.4.0 required |

## Limitações
- YAML syntax is parsed by Ruby Psych during pipeline self-validation.
- actions/upload-artifact uses the exact official v7.0.2 release tag, not a full immutable commit SHA; this is a documented supply-chain hardening residual.
- The workflow was not run on GitHub from this environment.
