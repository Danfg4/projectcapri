# Resultado individual — Vitest

Status: **NOT_RUN**
Resumo: 0 aprovados; 0 reprovados; 0 ignorados; 0 executados; 41 não executados/bloqueados.


A suíte não produziu JUnit XML; nenhum teste foi marcado como aprovado.
