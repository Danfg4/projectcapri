# Comparação: audit-r2 final → v3.2.1 candidata

- Base: ZIP audit-r2 final, SHA-256 `80c30c8066239e05ab8d16ff3fec41fea1fd40f3bf0b09a9d1aaeb2dc0f2f8e9`.
- Implementação: nenhuma alteração em arquivos de runtime nesta etapa.
- `package.json`: somente `version` 3.2.0 → 3.2.1.
- `metadata.json`: descrição atualizada para indicar candidata não certificada.
- `README.md`: título e versão do pacote atualizados.
- Adicionados `CAPRI-CORE-v3.2.1-CERTIFICATION-STATUS.md` e `CAPRI-CORE-v3.2.1-TEST-RESULTS-INDIVIDUAL.md`.
- `bun.lock` permanece byte a byte idêntico.
- Nenhuma dependência foi adicionada/atualizada.
- Nenhum teste foi removido, alterado ou desativado.
- Nenhuma base de dados real foi tocada.

O bloqueio de runtime impediu descobrir e corrigir falhas por execução. Não se declara que a implementação passou nos testes.
