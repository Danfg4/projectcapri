# Capri Core v3.2.2 — Relatório de validação do pipeline

**Resultado estático: 26 verificações aprovadas, 0 reprovadas.**

## Verificações executadas

- Parse do YAML do workflow com Ruby Psych e também PyYAML.
- Caminho `.github/workflows/capri-certification.yml` e eventos `push`, `pull_request`, `workflow_dispatch`.
- Bun `1.4.5`, lockfile v2, `bun install --frozen-lockfile` e verificação SHA-256 pré/pós-instalação configurada.
- Existência dos scripts `typecheck`, `test:certification` e `build` no `package.json`.
- 40 testes originais preservados e novo teste multiprocesso presente.
- Dependência real `better-sqlite3` mantida.
- Permissões somente `contents: read`; sem `pull_request_target`, sem `secrets.*`, sem npm/npx no workflow.
- Seis chaves de provedores explicitamente vazias.
- Coleta de relatórios e upload configurados com `if: always()`.
- Referências de actions verificadas: checkout e setup-bun fixados em SHA completo; upload-artifact na release oficial `v7.0.2` (tag mutável, residual documentado).
- Scripts JavaScript de certificação passaram em `node --check`.
- 35 arquivos TypeScript/TSX passaram pela transpilação sintática TypeScript 5.8.3, sem erro sintático. Isso não substitui typecheck semântico.
- O coletor de relatórios foi exercitado com XML JUnit de teste isolado; a mensagem de falha com token Bearer foi redigida. Esse fixture não está no pacote e não é resultado funcional da Capri.

## Não executado

- O workflow não foi enviado nem executado no GitHub.
- Bun e conectividade com registry não estavam disponíveis neste ambiente.
- Não houve `bun install --frozen-lockfile`, typecheck semântico, execução Vitest ou build.
- Nenhum dos 41 testes é marcado como aprovado. O resumo incluído no pacote registra 0 executados e 41 bloqueados.

## Residual de hardening

`actions/upload-artifact` usa a release oficial exata `v7.0.2`, mas a referência é uma tag e não um SHA completo imutável. O uso foi conferido na página oficial de releases; recomenda-se migrar para SHA completo quando o digest puder ser obtido e verificado diretamente no repositório oficial.

## Decisão

O workflow está estruturalmente preparado e passou nas verificações estáticas locais. A certificação funcional permanece **PENDENTE** até uma execução real no GitHub com instalação congelada, typecheck, 41 testes e build aprovados.
