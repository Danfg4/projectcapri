# Capri Core v3.1.1 — relatório de estabilização incremental

Data: 2026-11-26  
Base: `capri-core-project-v3.1.zip`  
Entrega: `capri-core-project-v3.1.1.zip`  
Escopo: cópia de desenvolvimento; sem publicação, deploy ou exposição pública.

## 1. Proveniência, backup e preservação

- Arquivo original recuperado da biblioteca: `capri-core-project-v3.1.zip` (121.434 bytes).
- SHA-256 do original: `b0c6219f05c2b419d02998370db753838c8e2073df3ad56450b2952fdd0dca35`.
- Backup integral criado antes de qualquer alteração: `capri-core-project-v3.1-backup.zip`.
- SHA-256 do backup: `b0c6219f05c2b419d02998370db753838c8e2073df3ad56450b2952fdd0dca35` (idêntico ao original).
- `unzip -t` do backup: PASSOU.
- A implementação foi alterada somente na cópia de trabalho v3.1.1. O arquivo original e o backup não foram sobrescritos.
- Nenhum deploy, publicação ou bind público foi realizado.

## 2. Comparação: v3.1 original versus v3.1.1

| Área | v3.1 original | v3.1.1 |
|---|---|---|
| Backup | ZIP original disponível | Backup integral independente criado e hash conferido |
| API | Rotas sem autenticação | Bearer token obrigatório em todas as rotas, inclusive health |
| Autorização | Sem distinção de privilégio | Token de usuário e token administrativo separados |
| Operações sensíveis | Sem controle de papel | Escrita de modelos/memória/sessões e exportação exigem admin |
| Segredos | Sem tokens da API | Dois segredos distintos, mínimo 32 caracteres, falha fechada |
| Rede | Bind `0.0.0.0` | Bind `127.0.0.1` por padrão; host configurável explicitamente |
| Frontend | Chamadas sem credencial | Solicita token comum/admin conforme a operação; cache somente em memória |
| Gemini timeout | `Promise.race` sem cancelar a chamada real | `AbortController` + `AbortSignal` no fetch REST; timer sempre limpo |
| Testes | 18 casos | 19 casos declarados; adicionada verificação de aborto Gemini e autorização API |
| Dependências | `package.json` e `bun.lock` originais | Nenhuma dependência/intervalo/lock alterado; versão do pacote para 3.1.1 |

## 3. Arquivos modificados

1. `server.ts`
   - Exige `CAPRI_API_TOKEN` e `CAPRI_ADMIN_TOKEN`, distintos e com no mínimo 32 caracteres.
   - Mantém `127.0.0.1` como host padrão.
   - Permite bind alternativo somente por configuração explícita `CAPRI_HOST`.

2. `src/server/routes/api.ts`
   - Autenticação Bearer com comparação de segredo usando `timingSafeEqual`.
   - Todas as rotas são protegidas, inclusive `/health`.
   - Papel administrativo exigido para cadastro/alteração de modelos, escrita/alteração/exclusão de memória, criação/alteração/exclusão de sessões e exportação ZIP.
   - Token comum recebe 403 ao tentar operação administrativa.

3. `src/server/adapters/gemini.adapter.ts`
   - Substitui timeout baseado em `Promise.race` por `AbortController`.
   - Requisição HTTP recebe `signal`; timeout aborta efetivamente o fetch.
   - Timer é limpo em `finally`.
   - Preserva tratamento de autenticação, rate limit, modelo inválido, resposta vazia e contagem de tokens.
   - A chamada é feita ao endpoint REST oficial do Gemini; não foi criado provedor simulado nem fallback falso.

4. `src/lib/api.ts`
   - Inclui Bearer token nas chamadas do frontend.
   - Solicita token administrativo nas operações protegidas.
   - Mantém tokens apenas em memória durante a página aberta; não os grava em storage persistente.

5. `.env.example`
   - Documenta os dois tokens e o bind local padrão.

6. `tests/capri-core.test.ts`
   - Atualiza o teste REST para usar tokens separados.
   - Verifica 401 sem token e 403 quando token comum tenta escrever memória.
   - Usa token administrativo para a escrita e exportação.
   - Adiciona teste do timeout Gemini verificando que o `AbortSignal` realmente dispara.

7. `README.md`
   - Atualiza versão e documenta autenticação, autorização e bind local.

8. `metadata.json`
   - Atualiza descrição para a versão 3.1.1.

9. `package.json`
   - Atualiza somente a versão do pacote para `3.1.1`; dependências e scripts permanecem inalterados.

`bun.lock` não foi modificado.

## 4. Verificações executadas

| Verificação | Resultado | Observação |
|---|---|---|
| Backup integral | PASSOU | Cópia byte a byte; SHA-256 idêntico |
| Integridade ZIP original/backup | PASSOU | `unzip -t` sem erro |
| Extração e inventário | PASSOU | 50 entradas no ZIP original |
| Transpilação sintática TS/TSX | PASSOU | 29 arquivos; zero diagnósticos sintáticos, TypeScript global 5.8.3 |
| DNS do `registry.npmjs.org` | BLOQUEADO | `EAI_AGAIN` / falha temporária de resolução |
| `npm test` | BLOQUEADO | `vitest: not found` (exit 127) |
| `npm run typecheck` | BLOQUEADO | `TS2688`: ausentes `@types/node` e `vite/client` |
| `npm run build` | BLOQUEADO | `vite: not found` (exit 127) |
| Teste automatizado de autorização | NÃO EXECUTADO | Incluído na suíte; depende de Vitest/Express instalados |
| Teste automatizado de cancelamento Gemini | NÃO EXECUTADO | Incluído na suíte; depende de Vitest/ambiente com dependências |
| Integração real com Gemini | NÃO EXECUTADA | Sem instalação validada e sem credencial real fornecida |
| Inicialização do servidor | NÃO EXECUTADA | `tsx`/dependências ausentes |

A resolução DNS foi rechecadas após as alterações e continua falhando. Não foram alteradas versões de dependências, não foi trocado o gerenciador de pacotes e não foi tentada instalação por fontes não verificadas.

A transpilação sintática não substitui typecheck semântico, testes Vitest ou build.

## 5. Estado e limitações

- A autenticação e as regras de autorização estão implementadas no código, mas os testes de integração ainda precisam ser executados quando o ambiente de dependências estiver disponível.
- A chamada Gemini agora usa `fetch` com `AbortController`; o teste que observa o sinal de aborto foi adicionado, mas não pôde ser executado neste ambiente.
- A compatibilidade exata do payload REST Gemini com o catálogo/modelo ativo precisa ser validada por teste com dependências e credencial real.
- Smart Router, fallback, SQLite, memória, concorrência, adaptadores não-Gemini e frontend não foram funcionalmente validados nesta etapa.
- Nenhum provedor foi substituído por mock em código de produção. Os mocks já existentes permanecem restritos à suíte de testes.
- A autenticação usa dois tokens compartilhados, não identidade individual por usuário/dispositivo. Antes de acesso LAN/Android, será necessário evoluir para credenciais por dispositivo, TLS, rotação/revogação e autorização granular.
- O frontend mantém o token apenas em memória enquanto a página está aberta; ainda assim, qualquer XSS ativo na origem poderia interferir em chamadas feitas pelo navegador. O bind local reduz a superfície, mas não substitui proteção contra XSS.

## 6. Próximos passos bloqueados ou pendentes

1. Restaurar resolução DNS ou disponibilizar ambiente de build com acesso ao registry e lockfile existente.
2. Instalar dependências sem atualizar versões, preferencialmente com `bun install --frozen-lockfile`.
3. Executar Vitest e confirmar os novos testes de 401/403 e abort Gemini.
4. Executar typecheck e build.
5. Testar startup local e confirmar bind efetivo em `127.0.0.1`.
6. Validar Gemini real com credencial fornecida pelo usuário; validar os demais provedores separadamente.
7. Corrigir qualquer falha e gerar uma nova revisão se necessário.

## 7. Conclusão

A cópia v3.1.1 contém as correções incrementais de segurança, bind local e cancelamento Gemini solicitadas, com backup original íntegro e dependências preservadas. A validação sintática passou. A estabilização funcional completa NÃO pode ser declarada concluída: Vitest, typecheck, build e testes de integração estão bloqueados pela ausência de dependências, e o registry permanece inacessível por DNS.

Esta entrega é uma candidata de desenvolvimento v3.1.1, não uma versão certificada para produção.
