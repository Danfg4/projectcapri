# Capri Core v3.2.0 — Relatório de entrega

## Resultado

Implementação preparada em cópia isolada da v3.1.1, sem alterar a versão original. O Memory Engine central foi conectado ao orquestrador e aos seis adaptadores por meio do contexto portátil comum. A migração SQL é aditiva e preserva `sessions`, `messages` e `memory_facts`.

## O que entrou

- Metadados de escopo, proveniência, confiança, confirmação, validade, expiração, acesso e sensibilidade em `memory_facts`.
- Tabelas `memory_relations` e `memory_events`; nenhuma tabela paralela para itens, preferências ou conflitos.
- Recuperação entre sessões com pontuação lexical/contextual, importância, confiança, recência, relações e orçamento de tokens.
- Memória de sessão isolada por FK; temporária exige expiração.
- Contradições aguardam confirmação; histórico e endpoint de confirmação incluídos.
- UI mostra confiança/estado e permite confirmar candidato pendente.
- Escritas e confirmações usam transações SQLite `IMMEDIATE`.
- Nenhuma dependência nova ou atualizada.

## Verificações

- 20 arquivos `.ts`: checagem sintática com Node `--experimental-strip-types --check` aprovada.
- SQLite via Python: esquema, backfill de legado, relações/eventos e cascata de exclusão aprovados.
- JSON de `package.json` e `metadata.json` válido; dependências idênticas à v3.1.1.
- Vitest não executado: `vitest: not found`.
- Typecheck não aprovado: definições de tipos de Node e Vite ausentes.
- Build não executado: `vite: not found`.
- Registry indisponível: `npm ping` falhou com `EAI_AGAIN registry.npmjs.org`.
- Não foram feitas chamadas reais aos seis provedores.

**Conclusão de qualidade:** versão de desenvolvimento implementada e parcialmente verificada; não certificada. Não declarar testes de integração, typecheck, build ou suíte Vitest aprovados.

## Arquivos modificados

`README.md`, `metadata.json`, `package.json`, `src/App.tsx`, `src/components/MemoryView.tsx`, `src/core/types.ts`, `src/lib/api.ts`, `src/server/core/orchestrator.ts`, `src/server/core/shared-memory.ts`, `src/server/db/database.ts`, `src/server/routes/api.ts`, `tests/capri-core.test.ts`.

## Arquivo novo

`src/server/core/memory-engine.ts`.

## Backup e rollback

Backup integral da base de código v3.1.1 criado antes das alterações. Para rollback seguro, parar o servidor e restaurar o backup de código e o banco de dados correspondente; não reverter manualmente as colunas da migração 2 em banco já utilizado.
