# Capri Core v3.2.1 — Status de certificação funcional

**Status: BLOQUEADO — candidata não certificada.**

Esta versão é uma cópia isolada da audit-r2 final com metadados do pacote atualizados para 3.2.1 e evidências da tentativa de certificação. Nenhuma dependência foi instalada, nenhum lockfile foi regenerado e nenhum teste foi alterado para contornar a ausência de runtime.

## Ambiente observado

- Node.js v22.16.0 e npm 10.9.2 disponíveis.
- Bun não instalado (`bun: command not found`).
- Download do instalador oficial bloqueado por DNS: `Could not resolve host: bun.sh`.
- Registro npm inacessível por DNS: `Could not resolve host: registry.npmjs.org`.
- Não foi encontrado cache local de Bun, Vitest ou better-sqlite3.
- `bun install --frozen-lockfile`, `bun run typecheck`, `bun run test` e `bun run build` tentados; todos bloqueados com exit 127.
- `tsc --noEmit --pretty false` direto também não pôde completar: faltam `@types/node` e `vite/client`.

## Verificações executadas

- Parsing/transpilação sintática de 31 arquivos TS/TSX: sem diagnósticos.
- Imports relativos: zero não resolvidos.
- Integridade do ZIP original e backup: SHA-256 verificado.
- Testes Vitest: 40 identificados, 0 executados.
- Migração SQLite real, persistência, transações, rollback, concorrência, autorização HTTP e adaptadores com stubs: não executados.

## Integridade de dependências

`bun.lock` foi preservado byte a byte em relação à base. Nenhuma dependência ou versão de dependência foi adicionada/alterada. O `package.json` teve somente o campo de versão alterado de 3.2.0 para 3.2.1.

## Decisão

Não classificar esta versão como funcionalmente certificada ou pronta para produção. A certificação exige restabelecer DNS/rede, instalar Bun compatível, executar a instalação congelada e concluir a suíte integral, incluindo testes reais com better-sqlite3, HTTP e seis adaptadores simulados. Não avançar para novas funcionalidades até cumprir esses critérios.
