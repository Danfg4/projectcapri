# Capri Core v3.2.0 audit-r2 — Relatório técnico

**Classificação:** versão de desenvolvimento, não certificada para produção  
**Base:** Capri Core v3.2.0 audit-r1  
**Escopo:** somente evolução do Memory Engine, privacidade, rejeição, recuperação relacional e orçamento global de contexto.

## 1. Preservação e origem

- A audit-r1 foi preservada integralmente em ZIP antes de qualquer edição.
- SHA-256 do ZIP audit-r1 e do backup pré-audit-r2: `db92e31caa7145bfe4e741765a2ff64b2efeb5046294cf6e64fe5b83b652cdc2`.
- A árvore audit-r2 foi extraída para uma cópia de desenvolvimento independente.
- A v3.1.1 original e seus backups não foram alterados.
- Nenhum banco real, `.env`, token ou credencial foi incluído ou alterado.
- Não houve deploy, publicação ou atualização de dependências.

## 2. Arquitetura consolidada

A arquitetura mantém uma única fonte persistente: SQLite, com `memory_facts` como repositório canônico, `sessions` e `messages` preservadas, e as tabelas existentes `memory_relations` e `memory_events`.

Responsabilidades na audit-r2:

- `src/server/core/memory-engine.ts`: fachada central e orquestração da recuperação/montagem de contexto; compõe as responsabilidades abaixo.
- `src/server/core/shared-memory.ts`: persistência SQLite, fatos, sessões, mensagens, eventos e operações transacionais.
- `src/server/core/memory-policy.ts`: política de privacidade, visibilidade por papel, validade e escopo de sessão.
- `src/server/core/memory-relations.ts`: expansão limitada de relações seguras.
- `src/server/core/context-budget.ts`: orçamento global, estimativa conservadora, reserva de saída e margem de segurança.

`orchestrator.memoryEngine` e `orchestrator.sharedMemory` agora apontam para a **mesma instância** de `MemoryEngine`. O objeto interno `MemoryEngine.store` é o único `SharedMemoryManager` que acessa o mesmo banco SQLite. Não existe banco ou sistema paralelo.

## 3. Política de privacidade

| Sensibilidade | Contexto enviado a provedores | API protegida comum | API administrativa |
|---|---|---|---|
| `normal` | Permitido, sujeito à relevância e orçamento | Permitido | Permitido |
| `private` | Sempre excluído | Visível para o usuário autenticado na interface protegida | Permitido |
| `restricted` | Sempre excluído | Não exposto | Permitido |

A política é centralizada em `MemoryAccessPolicy` e aplicada também durante a expansão relacional. A alteração de sensibilidade usa `PATCH /api/v1/memory/:id/sensitivity`, protegido por token administrativo. Reduzir a classificação exige `confirmDowngrade: true`. Upsert e atualização genéricos não podem reduzir a proteção; propostas de substituição herdam a classificação mais protetiva do fato anterior. Propostas que substituem fatos `private` ou `restricted` herdam a classificação mais protetiva do fato anterior, salvo elevação explícita.

A aplicação não registra o conteúdo de memórias em logs operacionais. Os eventos persistentes são mantidos na tabela de histórico necessária ao controle de alterações; eventos de rejeição e alteração de sensibilidade registram apenas o estado e a classificação, sem duplicar conteúdo nesses eventos específicos.

## 4. Rejeição de propostas

- Novo endpoint: `POST /api/v1/memory/:id/reject` (token administrativo obrigatório).
- Operação usa transação `IMMEDIATE`.
- Rejeição de proposta pendente muda `status` para `rejected` e `active` para `0`.
- A operação é idempotente: repetir rejeição retorna o estado rejeitado sem criar evento duplicado.
- O fato anterior permanece ativo.
- Uma proposta rejeitada não pode ser confirmada nem reativada por `updateFact` ou `upsertFact`.
- A trilha histórica da proposta não é excluída automaticamente.
- `MemoryView.tsx` apresenta ações de confirmar e rejeitar, além do estado “Rejeitado”.

## 5. Recuperação relacional

A recuperação inicial considera fatos válidos, ativos e confirmados ou não conforme sua confiança, mas somente de escopo global ou da sessão atual. O armazenamento consulta os fatos elegíveis por sessão; a política central confirma validade e sensibilidade.

A expansão usa busca em largura com profundidade máxima 2 e no máximo 8 fatos adicionais. Somente `related_to` e `derived_from` são percorridos. A visita é deduplicada por ID, ciclos são evitados, e cada fato expandido passa novamente por regras de sessão, validade, expiração e sensibilidade. `contradicts` e `supersedes` não são percorridos; fatos pendentes, rejeitados, expirados ou substituídos não são injetados como atuais.

A pontuação considera sobreposição lexical, importância, confiança, confirmação explícita, recência, escopo e categoria. Preferências confirmadas de alta importância podem ser incluídas mesmo sem sobreposição lexical direta.

## 6. Orçamento global de contexto

O orçamento é calculado antes da chamada ao provedor e inclui:

- instruções base e instruções adicionais;
- memórias selecionadas;
- histórico recente;
- mensagem atual;
- reserva de tokens para a resposta;
- margem de segurança.

A estimativa de fallback usa `ceil(caracteres / 3)` com margem adicional de 8%; não é apresentada como tokenizer exato. A reserva de saída é calculada a partir do limite do modelo (15%, limitada entre 512 e 4096 tokens) e enviada como `maxOutputTokens` ao Gemini, `max_tokens` ao Anthropic e aos adaptadores OpenAI-compatible (OpenAI, Groq, DeepSeek e xAI).

O orquestrador faz uma estimativa preliminar para o Smart Router e, depois de conhecer o modelo primário e a cadeia de fallback, reconstrói o contexto usando o menor `maxContextTokens` da fila. O mesmo `systemInstruction`, histórico e reserva são reutilizados em todas as tentativas de fallback. O orçamento reduz memórias de menor pontuação e histórico mais antigo; a mensagem atual nunca é removida. Quando há omissões, somente contagens e a natureza aproximada da estimativa são anexadas ao motivo do trace; nenhum conteúdo omitido é registrado.

## 7. Migração SQLite

A migração de audit-r2 é a versão 3 (`memory-engine-audit-r2-rejection-and-sensitivity-events`). Ela estende os valores permitidos em `memory_events.event_type` para `proposal_rejected` e `sensitivity_changed`.

Como SQLite não permite alterar diretamente o `CHECK` de uma tabela, a migração cria uma tabela temporária dentro da transação, copia todos os eventos existentes, substitui a tabela mantendo o nome canônico `memory_events`, recria o índice e registra a versão. A tabela temporária não permanece após a migração. A transação é `IMMEDIATE`; falha antes do registro da versão deve reverter a substituição e preservar os eventos anteriores.

**Limite da evidência:** foi executada uma simulação SQL independente com Python `sqlite3` (9 verificações aprovadas). A migração real através de `createDatabase`/`better-sqlite3` está preparada em dois testes Vitest, mas não foi executada neste ambiente.

## 8. Compatibilidade

- SQLite, `memory_facts`, `memory_relations`, `memory_events`, `sessions` e `messages` preservados.
- Smart Router, quotas, autenticação, rotas existentes e fallback mantidos.
- Os seis provedores continuam usando os adaptadores existentes: Gemini, Groq, OpenAI, Anthropic, DeepSeek e xAI.
- Groq, OpenAI, DeepSeek e xAI continuam no adaptador OpenAI-compatible.
- Nenhuma dependência foi adicionada.
- `package.json` e `bun.lock` têm SHA-256 idêntico à audit-r1.

## 9. Arquivos modificados

- `README.md`
- `metadata.json`
- `src/App.tsx`
- `src/components/MemoryView.tsx`
- `src/components/UsageApiView.tsx` (ajuste da instrução de instalação para o lockfile existente)
- `src/lib/api.ts`
- `src/server/adapters/base.ts`
- `src/server/adapters/gemini.adapter.ts`
- `src/server/adapters/anthropic.adapter.ts`
- `src/server/adapters/openai-compatible.adapter.ts`
- `src/server/core/orchestrator.ts`
- `src/server/core/shared-memory.ts`
- `src/server/core/memory-engine.ts`
- `src/server/core/memory-policy.ts` (novo)
- `src/server/core/memory-relations.ts` (novo)
- `src/server/core/context-budget.ts` (novo)
- `src/server/db/database.ts`
- `src/server/routes/api.ts`
- `tests/capri-core.test.ts`
- `audit-r2/evidence/r1/*` e `audit-r2/evidence/r2/*` (evidências e relatórios)

## 10. Dependências e validação

Ambiente observado: Node.js `v22.16.0`, npm `10.9.2`; Bun ausente. `npm ping` falhou com `EAI_AGAIN registry.npmjs.org`. O comando solicitado `bun install --frozen-lockfile` não pôde iniciar porque o executável Bun não está instalado. Não foi usado `npm install`, não houve alteração de versões e `bun.lock` permaneceu byte a byte idêntico à audit-r1.

Foi possível verificar sintaxe TypeScript/TSX por `transpileModule` em 33 arquivos e ausência de imports relativos sem destino. Isso **não é typecheck**. O `tsc --noEmit` disponível globalmente parou por ausência de `@types/node` e `vite/client`. Vitest, build, integração API, migração `better-sqlite3`, persistência após reinício, concorrência e integração real dos provedores permanecem bloqueados ou não executados.

**Conclusão:** audit-r2 é uma evolução implementada na cópia de desenvolvimento, com evidência estática e simulação SQL limitada. Não é uma versão funcionalmente validada e não deve ser declarada pronta para produção.
