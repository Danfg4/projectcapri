# Capri Core v3.2.0 — Relatório Individual dos Testes da Auditoria Final

**Data:** 26/11/2026  
**Escopo:** verificações executadas sem dependências e estado dos testes preparados no projeto.

## Resultados executados

| ID | Verificação | Resultado | Classificação |
|---|---|---|---|
| S-01 | Transpilação sintática TS/TSX via TypeScript 5.8.3 | 31 arquivos; 0 erros | APROVADO |
| S-02 | Resolução de imports relativos | 0 imports não resolvidos | APROVADO |
| S-03 | Orçamento de contexto 1.024 | Entrada + reserva + margem dentro do limite | APROVADO |
| S-04 | Orçamento de contexto 4.096 | Entrada + reserva + margem dentro do limite | APROVADO |
| S-05 | Orçamento de contexto 32.768 | Entrada + reserva + margem dentro do limite | APROVADO |
| S-06 | Orçamento de contexto 128.000 | Entrada + reserva + margem dentro do limite | APROVADO |
| S-07 | Estimador CJK/emoji | `漢字` estimado como 2; `🙂` como 1 | APROVADO |
| S-08 | Smart Router com prompt obrigatório longo | 8k bloqueado; 1M aceito | APROVADO (teste isolado) |
| S-09 | Migração v3 em SQLite Python | 9 verificações verdadeiras | APROVADO (simulação) |
| S-10 | Migração de esquema legado v1→v2→v3 em SQLite Python | 6 verificações verdadeiras | APROVADO (simulação) |
| S-11 | Integridade do backup original | Hash do backup igual ao ZIP original | APROVADO |
| S-12 | Preservação de lockfiles | package.json e bun.lock idênticos à audit-r1 | APROVADO |

### Limites da simulação SQLite

As simulações usam Python `sqlite3`: uma reproduz a reconstrução v3 (9 verificações: cópia de evento antigo, novo tipo, idempotência, rollback, marcador, tabela temporária e chaves estrangeiras); outra percorre o esquema legado v1→v2→v3 (6 verificações: fato, sessão, mensagem, valores padrão, marcadores e chaves estrangeiras). **Nenhuma executa a função TypeScript com `better-sqlite3`.**

## Testes preparados, não executados

O arquivo `tests/capri-core.test.ts` contém 40 casos `it()`. Os testes existentes cobrem roteamento, fallback, sessões, mensagens, persistência em arquivo, API, autenticação, cotas, migrações, privacidade, relações e seis adaptadores por stubs. Esta revisão adicionou/expandiu casos para:

- conteúdo private/restricted literal em histórico anterior;
- prompt obrigatório longo com modelo de janela grande;
- estimativa em contexto pequeno/médio/grande e Unicode;
- exclusão de fatos pendentes, rejeitados e substituídos da expansão relacional;
- bloqueio de reativação de fato substituído.

**Status geral da suíte Vitest:** NÃO TESTADO — Bun não instalado e `node_modules` ausente.

## Comandos bloqueados

- `bun install --frozen-lockfile`: BLOQUEADO (`bun: command not found`).
- `bun run typecheck`: BLOQUEADO (Bun ausente).
- `bun run test`: BLOQUEADO (Bun ausente).
- `bun run build`: BLOQUEADO (Bun ausente).
- `tsc --noEmit --pretty false`: BLOQUEADO por ausência de `@types/node` e `vite/client`.
- Migração/integridade/persistência real com `better-sqlite3`: BLOQUEADO por dependência ausente.

Não foi executado `npm install`, não foi alterado `bun.lock` e não foram usadas credenciais ou endpoints reais.
