# Capri Core v3.2.2 — Relatório técnico

**Classificação:** preparada para certificação automatizada; **não certificada funcionalmente**.

## Escopo

Esta atualização prepara um ambiente externo e reproduzível de certificação. Não adiciona funcionalidades ao assistente, não altera a implementação do Memory Engine e não modifica os testes originais. Foram preservados os 40 casos Vitest originais e acrescentado um teste de integração para concorrência real entre processos e conexões SQLite independentes.

## Preservação e integridade

- Base: ZIP candidato v3.2.1 original, extraído para uma cópia independente.
- Backup v3.2.1 criado antes de qualquer alteração.
- SHA-256 do ZIP original e do backup: `c105fcb0528eab1126e1264290469f5e073d928ffb390dd09b4d9c01afc1979f`.
- `bun.lock` preservado byte a byte: `4b938e4811b07062aa70f3fab74e4b81c9ad30ed53d11cc37bf71dae279680f7`.
- `src/` não foi alterado. Nenhum teste original foi removido ou modificado.
- `package.json`: versão alterada para 3.2.2 e script `test:certification` adicionado; dependências e versões de dependências mantidas.
- `audit-r1`, `audit-r2` e o pacote v3.2.1 original não foram alterados.

## Bun e lockfile

O `bun.lock` existente declara `lockfileVersion: 2` e `configVersion: 1`. O workflow fixa Bun `1.4.5`; Bun 1.4.0 introduziu o lockfile v2 e versões anteriores não leem esse formato. A versão 1.4.5 é uma release oficial publicada em 19 de novembro de 2026. A instalação é exclusivamente `bun install --frozen-lockfile`, com SHA-256 do lockfile conferido antes e depois.

## Pipeline

Arquivo: `.github/workflows/capri-certification.yml`.

- Eventos: `push`, `pull_request` e `workflow_dispatch`.
- Runner: `ubuntu-24.04`.
- Etapas: validação do próprio pipeline; validação do runtime/lock; instalação congelada; typecheck; Vitest; build; gate de cobertura; geração de relatórios e upload de artefatos.
- Comandos funcionais: `bun run typecheck`, `bun run test:certification`, `bun run build`.
- Vitest: 40 testes originais + 1 teste adicional (41 esperados no total), com reporters verbose, JUnit e JSON.
- `better-sqlite3` real é usado pelos testes de persistência/migração e pelo novo teste de concorrência.
- Sem `npm`/`npx` no workflow e sem chamadas pagas aos seis provedores.

## Teste complementar de concorrência

`tests/certification/sqlite-concurrency.test.ts` inicializa um banco de arquivo e lança quatro processos Bun independentes. Cada processo abre sua própria conexão `better-sqlite3`, grava fatos exclusivos e concorre por uma chave idempotente comum. O teste verifica a contagem de registros, a unicidade da chave compartilhada e `PRAGMA integrity_check`. O teste foi preparado, mas não executado neste ambiente; só será considerado aprovado se o JUnit do GitHub Actions o registrar como PASS.

## Segurança

- `permissions: contents: read` no workflow e no job.
- `actions/checkout` com `persist-credentials: false`.
- Evento `pull_request`, sem `pull_request_target`.
- Nenhuma referência a `secrets.*`; chaves dos provedores e tokens de serviço definidos como vazios.
- Nenhuma credencial real de provedor; os testes de API usam tokens locais de teste.
- Logs são sanitizados antes da publicação.
- `checkout` e `setup-bun` estão fixados em SHA completo. `upload-artifact` está na release oficial exata `v7.0.2`, mas como tag e não SHA imutável; isso permanece documentado como residual de hardening da cadeia de suprimentos.

## Relatórios publicados pelo workflow

- Resultados individuais JUnit/JSON e resumo PASS/FAIL/BLOCKED.
- Relatórios de typecheck e build.
- Evidências SQLite/migração/persistência/rollback.
- Relatório HTTP/autorização, privacidade e adaptadores stub.
- Evidência de concorrência multiprocesso.
- Lacunas de cobertura e logs de falhas sanitizados.
- `SHA256SUMS.txt` dos relatórios, logs e arquivos `dist/` produzidos.

O artefato GitHub Actions é mantido por 30 dias.

## Estado da execução nesta entrega

- GitHub Actions: **não executado**; não existe repositório GitHub do usuário conectado nesta tarefa.
- Bun neste ambiente: ausente (`bun: command not found`).
- Instalação congelada: não executada.
- Typecheck semântico: não executado.
- Vitest: 0/41 executados localmente; 41 bloqueados por ausência do Bun/dependências.
- Build: não executado.
- Validação sintática TypeScript: 35 arquivos, zero erros sintáticos; isso não é typecheck semântico.
- Workflow YAML e verificações estáticas: aprovados conforme relatório de validação do pipeline.

A v3.2.2 não deve ser usada como prova de certificação funcional até que uma execução real no GitHub conclua todos os gates com sucesso.
