# Capri Core v3.2.0 — Auditoria Final da audit-r2

**Data:** 26/11/2026  
**Escopo:** auditoria estática independente, verificações locais sem dependências e correções restritas à cópia de auditoria.  
**Resultado geral:** **BLOQUEADO PARA CERTIFICAÇÃO FUNCIONAL**. A arquitetura do Memory Engine é estruturalmente coerente e os defeitos identificados nesta revisão foram corrigidos na cópia final, mas os testes oficiais, a integração real com `better-sqlite3` e o build não puderam ser executados porque Bun e dependências do projeto não estão disponíveis.

## 1. Integridade e preservação

- ZIP original audit-r2 preservado sem alterações: `capri-core-project-v3.2.0-audit-r2-original-pre-final-audit.zip`.
- SHA-256 do original e do backup: `46b9edf3c31aee40dd9648dbf5f03573a3e768b520a470ca841bfec084ad97f6`.
- Auditoria e correções feitas somente em `work/audit-copy/`.
- audit-r1 e v3.1.1 não foram modificadas.
- Nenhum banco de dados real foi aberto ou alterado.
- `package.json` e `bun.lock` da audit-r2 permanecem idênticos à audit-r1; nenhuma dependência foi adicionada ou atualizada.

**Classificação:** APROVADO.

## 2. Arquitetura e responsabilidades

### MemoryEngine

O `MemoryEngine` é a fachada/orquestrador central por composição: possui um único `SharedMemoryManager` como armazenamento, uma `MemoryAccessPolicy`, um `MemoryRelationExpander` e a montagem central de contexto. O método `buildPortableContext` reúne recuperação, filtragem, expansão, ranqueamento e orçamento.

### SharedMemoryManager

Permanece responsável pelo acesso SQLite, CRUD de fatos, sessões e mensagens, relações e histórico de eventos. Não mantém uma segunda base nem uma segunda tabela de memória. A separação é funcional no código: o gestor não possui mais `buildPortableContext`.

### Instância e compatibilidade

O construtor do `CapriCoreOrchestrator` instancia `MemoryEngine` uma vez e atribui `sharedMemory = memoryEngine`. A identidade dos dois campos é explícita (`===`) no código e existe teste preparado para isso. A execução desse teste Vitest está bloqueada.

### Persistência e migração

A migração v2 adiciona metadados, relações e eventos às estruturas existentes. A migração v3 reconstrói transacionalmente `memory_events` para ampliar o `CHECK` de `event_type`, copiando os eventos antigos, recriando o índice e registrando a versão. A reconstrução é necessária porque SQLite não permite alterar diretamente o `CHECK` existente. O caminho preserva o histórico por cópia transacional e não deixa uma tabela paralela permanente.

**Classificação:** APROVADO na inspeção estrutural; BLOQUEADO para confirmação com `better-sqlite3` real.

## 3. Privacidade e caminho dos dados

- `normal`: permitido no contexto externo.
- `private` e `restricted`: filtrados antes da composição de fatos externos; a expansão relacional aplica a mesma política a cada nó.
- `restricted`: a política da API exclui esses fatos para o papel comum e permite acesso administrativo; operações de escrita, confirmação, rejeição e mudança de sensibilidade exigem token administrativo.
- `private`: permanece disponível na interface/API protegida, mas não é enviado como fato de memória aos provedores.
- A auditoria encontrou um caminho indireto: conteúdo privado/restrito poderia permanecer em mensagens antigas e voltar ao contexto do provedor como histórico, embora o fato estivesse filtrado. A cópia final agora redige correspondências literais de conteúdos private/restricted no histórico antes de enviá-lo ao provedor. Foram adicionados testes para ambos os níveis.
- A redação é literal e não semântica: não reconhece paráfrases, traduções ou fragmentos não contíguos. Ela usa os fatos private/restricted que ainda existem no banco; conteúdo que permaneça em mensagens antigas após a exclusão do fato não tem mais um registro de sensibilidade para ser reconhecido. Uma redução explícita de sensibilidade também altera a classificação atual, não reclassifica automaticamente mensagens antigas. A mensagem atual e o `customSystemPrompt` fornecidos diretamente pelo usuário não são redigidos; eles são entradas atuais explicitamente encaminhadas pelo fluxo.
- Eventos `created`/`updated` preservam snapshots de conteúdo no histórico SQLite para auditoria. Eventos de rejeição e mudança de sensibilidade não duplicam o conteúdo do fato. O histórico é servido por endpoint autenticado e sujeito à política do fato atual.
- A política de API é baseada nos tokens Bearer configurados; esta revisão não executou testes HTTP reais.

**Classificação:** APROVADO por inspeção estática após correção; BLOQUEADO para validação de integração/autorização em runtime.

## 4. Ciclo de propostas

A inspeção encontrou transações `IMMEDIATE` para confirmação e rejeição. Ambas leem o estado atual dentro da transação, o que serializa escritores SQLite e impede que uma proposta já rejeitada seja confirmada posteriormente, ou que uma já confirmada seja rejeitada como pendente. A rejeição é idempotente, preserva o fato anterior e registra `proposal_rejected`. A confirmação transforma o fato anterior em `superseded`, registra o evento e liga o novo fato ao anterior.

Também foi encontrada uma possibilidade de reativação de um fato `superseded` por `upsertFact` com ID explícito. A cópia final agora bloqueia reativação por `upsertFact` e por `updateFact(active: true)` tanto para fatos rejeitados quanto substituídos. Foi adicionada asserção ao teste relacional.

**Classificação:** APROVADO por inspeção estática; BLOQUEADO para teste concorrente real com duas conexões/processos e execução da suíte.

## 5. Recuperação relacional

A expansão consulta somente `related_to` e `derived_from`, com BFS limitado a profundidade 2 e até 8 fatos adicionais. IDs visitados e incluídos evitam ciclos e duplicações. Cada fato recuperado passa por política de sensibilidade, status/atividade, validade, expiração e escopo de sessão. `contradicts` e `supersedes` não são percorridos.

A cópia final amplia o teste para garantir que fatos pendentes, rejeitados e substituídos não retornem como contexto atual, além dos casos de sessão cruzada, privado, expirado, ciclo, duplicação e conflito.

**Classificação:** APROVADO por inspeção estática; NÃO TESTADO em runtime.

## 6. Orçamento de contexto

O orçamento contabiliza instrução-base, instrução personalizada, mensagem atual, memória selecionada, histórico, reserva de saída e margem de segurança. O prompt atual é obrigatório: se o conjunto obrigatório não cabe, a função falha explicitamente em vez de descartá-lo. A montagem final é feita com o menor limite de contexto da fila primária + fallback, para manter o mesmo contexto entre tentativas.

A auditoria identificou que o orquestrador usava um orçamento preliminar fixo de 8.192 tokens antes de consultar o registro de modelos. Isso podia bloquear um prompt longo mesmo quando havia modelo com janela muito maior. A cópia final estima primeiro o footprint obrigatório, atualiza a disponibilidade dos modelos antes do roteamento e compara o footprint com o orçamento de entrada de cada modelo após reserva de saída e margem. Memória e histórico opcionais são alocados depois, no limite da fila.

A estimativa foi reforçada para contar code points não latinos individualmente, em vez de dividir todos os caracteres por três; isso reduz subestimação em CJK e emoji. Ainda é uma heurística, não tokenizer de Gemini, OpenAI, Anthropic, Groq, DeepSeek ou xAI. O valor reportado é estimativa de aplicação; contagem real e truncamento do provedor não foram verificados.

Foram executadas verificações isoladas para limites 1.024, 4.096, 32.768 e 128.000; todas respeitaram a soma estimada de entrada + reserva + margem. Também foi executado teste isolado do Smart Router: um prompt obrigatório de cerca de 21,8 mil tokens estimados foi bloqueado para um modelo de 8k e aceito para um modelo de 1M. Isso não substitui o teste de integração do orquestrador.

**Classificação:** APROVADO para a lógica heurística de orçamento em verificações locais; BLOQUEADO para certificação de contagem real por tokenizer/provedor.

## 7. Regressões e compatibilidade com audit-r1

Comparação por hash de árvore:

- audit-r1: 45 arquivos.
- audit-r2 original: 60 arquivos.
- audit-r2: 15 arquivos adicionados, 0 removidos, 17 alterados.
- `package.json` e `bun.lock` idênticos.

A inspeção não encontrou remoção das estruturas de sessões/mensagens, Smart Router, fallback, cotas, autenticação, UI, exportação ou adaptadores. A audit-r2 usa três módulos novos para política, expansão relacional e orçamento, e adiciona a fachada `MemoryEngine`. Os seis provedores continuam mapeados: Gemini, Groq, OpenAI, Anthropic, DeepSeek e xAI; os adaptadores OpenAI-compatíveis compartilham o mesmo caminho para Groq/OpenAI/DeepSeek/xAI.

**Classificação:** APROVADO por comparação estática; BLOQUEADO para regressão executada.

## 8. Testes e ambiente

| Verificação | Resultado | Classificação |
|---|---:|---|
| Bun disponível | Não (`bun: command not found`) | BLOQUEADO |
| `bun install --frozen-lockfile` | Não executado; Bun ausente | BLOQUEADO |
| `bun run typecheck` | Não executado; Bun ausente | BLOQUEADO |
| `bun run test` | Não executado; Bun ausente | BLOQUEADO |
| `bun run build` | Não executado; Bun ausente | BLOQUEADO |
| TypeScript `transpileModule` | 31 arquivos, 0 erros de sintaxe | APROVADO (sintaxe apenas) |
| `tsc --noEmit` global | Bloqueado por ausência de `@types/node` e `vite/client` | BLOQUEADO |
| Importações relativas | 0 não resolvidas | APROVADO (estático) |
| SQLite Python — simulação v3 | 9 verificações, todas verdadeiras | APROVADO (simulação) |
| Migração Python v1→v2→v3 | 6 verificações, todas verdadeiras | APROVADO (simulação)
| Migração real `better-sqlite3` | Dependência ausente | BLOQUEADO |
| Persistência/integração API | Não executadas | NÃO TESTADO |
| Suíte Vitest (40 casos preparados) | Não executada | NÃO TESTADO |
| Adaptadores com stubs | Testes preparados; sem execução Vitest | NÃO TESTADO |
| Provedores reais/credenciais | Não chamados | NÃO TESTADO |
| Concorrência multi-conexão/processo | Inspeção de transações apenas | NÃO TESTADO |

Não foi usado `npm install`, não houve alteração do lockfile e nenhum provedor real foi chamado.

## 9. Correções desta auditoria final

As correções foram feitas exclusivamente na cópia de auditoria e acompanhadas de testes adicionados/ajustados:

1. Remoção do limite preliminar fixo de 8k antes do roteamento; cálculo obrigatório passa a preceder a alocação opcional de memória/histórico.
2. Roteador considera o orçamento de entrada disponível após reserva de saída e margem, e os motivos de bloqueio informam o limite efetivo.
3. Redação de conteúdos private/restricted encontrados literalmente no histórico reutilizado com provedores externos.
4. Bloqueio de reativação de fatos `superseded` por `upsertFact` e `updateFact`.
5. Estimador de tokens trata code points não latinos individualmente; testes incluem CJK e emoji.
6. Testes ampliados para prompts longos, histórico privado/restrito e fatos pendentes/rejeitados/substituídos na expansão.

Nenhuma dependência foi adicionada. Não houve reescrita do projeto nem novas funcionalidades de produto.

## 10. Conclusão de certificação

**O Memory Engine está bem separado estruturalmente e os caminhos principais de privacidade, relação, estado e orçamento são coerentes após as correções desta auditoria. Porém, não está certificado como núcleo central pronto para produção.**

A conclusão objetiva é **BLOQUEADO PARA CERTIFICAÇÃO FUNCIONAL** até que um ambiente com Bun e dependências instaláveis execute, no mínimo: instalação congelada, typecheck, 40 testes Vitest, build, migração real com `better-sqlite3`, persistência/reabertura, autorização HTTP, concorrência entre confirmação/rejeição e execução de stubs dos seis adaptadores. Após isso, devem ser avaliadas as limitações do estimador de tokens contra tokenizers reais e a redação literal contra cenários de privacidade mais amplos.

Nenhuma alteração de voz, wake word, Android, overlay ou novas funcionalidades foi iniciada.
