# Capri Core v3.2.0 audit-r2 — Resultados individuais

**Status geral:** NÃO CERTIFICADA. Os testes Vitest foram preparados no projeto (38 casos declarados), mas não executados porque Bun e dependências não estão disponíveis.

## Verificações executadas

| Verificação | Resultado | Evidência / limite |
|---|---|---|
| Parsing sintático TypeScript/TSX | APROVADO | 33 arquivos; zero diagnósticos de sintaxe no `transpileModule` |
| Imports relativos | APROVADO | Zero imports relativos sem destino |
| Integridade do `bun.lock` | APROVADO | Presente, lockfileVersion 2, SHA-256 igual à audit-r1 |
| Integridade do `package.json` | APROVADO | SHA-256 igual à audit-r1 |
| Simulação SQL da migração v3 | APROVADO | 9/9 verificações Python sqlite3; não executou `better-sqlite3` |
| Instalação `bun install --frozen-lockfile` | BLOQUEADO | Bun não instalado |
| TypeScript typecheck | BLOQUEADO | Ausência de `@types/node` e `vite/client` |
| Vitest | BLOQUEADO | Dependências ausentes; 38 casos preparados, 0 executados |
| Build de produção | BLOQUEADO | Vite não instalado |
| Integração backend/API | BLOQUEADO | Testes preparados, Vitest não executado |
| Migração real `better-sqlite3` | BLOQUEADO | Dependência ausente |
| Testes reais de reinício/persistência | BLOQUEADO | `better-sqlite3`/Vitest ausentes |
| Concorrência SQLite real | BLOQUEADO | Runtime não disponível |
| Integração com credenciais reais dos provedores | NÃO TESTADO | Não foram realizadas chamadas externas |
| Conectividade npm | BLOQUEADO | `EAI_AGAIN registry.npmjs.org` |

## 16 requisitos funcionais — estado dos testes preparados

| # | Requisito | Teste preparado | Resultado desta execução |
|---:|---|---|---|
| 1 | `private` fora do contexto externo | Teste Memory Engine | BLOQUEADO |
| 2 | `restricted` fora do contexto e API comum | Teste Memory Engine + API | BLOQUEADO |
| 3 | Rejeição transacional e idempotente | Teste Memory Engine + API | BLOQUEADO |
| 4 | Proposta rejeitada não pode ser confirmada | Teste Memory Engine + API | BLOQUEADO |
| 5 | Fato anterior preservado | Teste Memory Engine + API | BLOQUEADO |
| 6 | Evento de rejeição registrado | Teste de histórico | BLOQUEADO |
| 7 | Expansão `related_to`/`derived_from` | Teste de relações | BLOQUEADO |
| 8 | Bloqueio de expansão entre sessões | Teste de relações | BLOQUEADO |
| 9 | Ciclos e duplicações evitados | Teste de relações | BLOQUEADO |
| 10 | Fatos expirados excluídos | Teste de relações e validade | BLOQUEADO |
| 11 | Orçamento global respeitado | Teste `context-budget` | BLOQUEADO |
| 12 | Mensagem atual preservada | Teste `context-budget` | BLOQUEADO |
| 13 | Memórias relevantes priorizadas | Teste de relevância | BLOQUEADO |
| 14 | Fallback mantém o mesmo contexto | Teste de orquestração | BLOQUEADO |
| 15 | Uma instância central compartilhada | Teste de identidade do alias | BLOQUEADO |
| 16 | Compatibilidade dos seis adaptadores | Teste com adaptadores stub | BLOQUEADO |

## Migração v3 — testes Vitest adicionados

Dois testes foram adicionados para executar com `better-sqlite3` disponível:

1. Migrar `memory_events` v2 para v3, preservar eventos, permitir `proposal_rejected` e comprovar idempotência após reabrir o banco.
2. Injetar falha no registro da migração v3, comprovar rollback integral da tabela/eventos e executar novamente após remover o trigger de falha.

Ambos permanecem **BLOQUEADOS / NÃO EXECUTADOS** neste ambiente.

## Observação de interpretação

`APROVADO` se aplica somente às verificações efetivamente executadas e descritas. Parsing sintático não equivale a typecheck; simulação SQL não equivale a migração real; testes preparados não equivalem a testes aprovados. A audit-r2 não atende ainda aos critérios de certificação funcional ou produção.
