export type ProviderId =
  | 'gemini'
  | 'groq'
  | 'openai'
  | 'anthropic'
  | 'deepseek'
  | 'xai';

export type IntentCategory =
  | 'general_chat'
  | 'complex_reasoning'
  | 'coding'
  | 'research'
  | 'document_analysis'
  | 'content_generation'
  | 'quick_summary';

export type ComplexityLevel = 'low' | 'medium' | 'high';

export type ModelCapabilityTier =
  | 'fast_economy'
  | 'balanced'
  | 'deep_reasoning';

export type ModelAvailabilityStatus =
  | 'available'
  | 'disabled'
  | 'not_configured'
  | 'quota_exhausted'
  | 'cooldown'
  | 'unverified'
  | 'invalid_model';

export type RoutingMode = 'auto' | 'manual';

export type AdapterErrorType =
  | 'missing_key'
  | 'rate_limit'
  | 'timeout'
  | 'auth_error'
  | 'invalid_model'
  | 'upstream_error';

export interface ModelDefinition {
  id: string;
  provider: ProviderId;
  modelName: string;
  displayName: string;
  envKey: string;
  enabled: boolean;
  capabilityTier: ModelCapabilityTier;
  strengths: IntentCategory[];
  costPer1kInput: number;
  costPer1kOutput: number;
  avgLatencyMs: number;
  priority: number;
  rpmLimit: number;
  rpdLimit: number;
  tpdLimit: number;
  maxContextTokens: number;
  notes: string;
  updatedAt: string;
}

export interface ModelQuotaUsage {
  requestsLastMinute: number;
  requestsToday: number;
  tokensToday: number;
  rpmRemaining: number;
  rpdRemaining: number;
  tpdRemaining: number;
  cooldownUntil: string | null;
}

export interface ModelWithStatus extends ModelDefinition {
  envConfigured: boolean;
  availability: ModelAvailabilityStatus;
  availabilityReason: string;
  quota: ModelQuotaUsage;
}

export interface IntentClassification {
  intent: IntentCategory;
  complexity: ComplexityLevel;
  confidence: number;
  reasoning: string;
  signals: string[];
}

export interface RoutingCandidateEvaluation {
  modelId: string;
  displayName: string;
  provider: ProviderId;
  tier: ModelCapabilityTier;
  availability: ModelAvailabilityStatus;
  eligible: boolean;
  score: number;
  reason: string;
}

export interface FallbackAttempt {
  attempt: number;
  modelId: string;
  displayName: string;
  provider: ProviderId;
  status: 'success' | 'failed';
  errorType?: AdapterErrorType;
  errorMessage?: string;
  latencyMs: number;
}

export interface RoutingTrace {
  id: string;
  sessionId: string;
  requestPreview: string;
  intent: IntentCategory;
  complexity: ComplexityLevel;
  intentConfidence: number;
  intentReasoning: string;
  routingMode: RoutingMode;
  requestedModelId: string | null;
  selectedModelId: string | null;
  finalModelId: string | null;
  finalProvider: ProviderId | null;
  selectionReason: string;
  candidates: RoutingCandidateEvaluation[];
  fallbackAttempts: FallbackAttempt[];
  memoryFactsUsedCount: number;
  sessionMessagesUsedCount: number;
  finalStatus: 'completed' | 'failed' | 'blocked';
  errorMessage: string | null;
  totalLatencyMs: number;
  inputTokens: number | null;
  outputTokens: number | null;
  totalTokens: number | null;
  estimatedCostUsd: number | null;
  createdAt: string;
}

export interface MemoryFact {
  id: string;
  category: 'preference' | 'identity' | 'project' | 'constraint' | 'knowledge';
  key: string;
  content: string;
  sourceModel: string | null;
  importance: number;
  active: boolean;
  scope: 'long_term' | 'session' | 'temporary';
  sessionId: string | null;
  sourceType: 'user_explicit' | 'user_confirmed' | 'admin' | 'inferred' | 'imported' | 'legacy' | 'session_summary';
  sourceRef: string | null;
  confidence: number;
  userConfirmed: boolean;
  status: 'active' | 'pending_confirmation' | 'superseded' | 'rejected';
  validFrom: string | null;
  expiresAt: string | null;
  lastAccessedAt: string | null;
  supersededBy: string | null;
  sensitivity: 'normal' | 'private' | 'restricted';
  createdAt: string;
  updatedAt: string;
}

export interface SessionRecord {
  id: string;
  title: string;
  activeModelOverride: string | null;
  messageCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface SessionMessage {
  id: string;
  sessionId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  modelId: string | null;
  provider: ProviderId | null;
  intent: IntentCategory | null;
  traceId: string | null;
  createdAt: string;
}

export interface UsageLogEntry {
  id: string;
  traceId: string;
  sessionId: string;
  modelId: string;
  provider: ProviderId;
  status: 'success' | 'error';
  latencyMs: number;
  inputTokens: number | null;
  outputTokens: number | null;
  totalTokens: number | null;
  estimatedCostUsd: number | null;
  errorCode: string | null;
  errorMessage: string | null;
  createdAt: string;
}

export interface ProviderSummary {
  provider: ProviderId;
  label: string;
  envKey: string;
  configured: boolean;
  totalModels: number;
  availableModels: number;
  requestsToday: number;
  tokensToday: number;
}

export interface UsageSummary {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  fallbackCount: number;
  totalTokens: number;
  totalInputTokens: number;
  totalOutputTokens: number;
  totalEstimatedCostUsd: number;
  avgLatencyMs: number;
  byProvider: Array<{
    provider: ProviderId;
    requests: number;
    successes: number;
    failures: number;
    tokens: number;
    costUsd: number;
    avgLatencyMs: number;
  }>;
  byModel: Array<{
    modelId: string;
    provider: ProviderId;
    requests: number;
    tokens: number;
    avgLatencyMs: number;
  }>;
}

export interface OrchestrationRequest {
  prompt: string;
  sessionId?: string;
  routingMode?: RoutingMode;
  requestedModelId?: string;
  allowFallbackOnManual?: boolean;
  systemPrompt?: string;
  maxFallbackAttempts?: number;
  saveMemory?: boolean;
}

export interface OrchestrationResponse {
  ok: boolean;
  sessionId: string;
  answer: string | null;
  trace: RoutingTrace;
  userMessage: SessionMessage;
  assistantMessage: SessionMessage | null;
  extractedMemories: MemoryFact[];
  error?: {
    code: string;
    message: string;
    limitation: string;
  };
}

export interface HealthResponse {
  status: 'ok';
  engine: 'Capri Core';
  database: {
    connected: boolean;
    path: string;
  };
  providers: ProviderSummary[];
  timestamp: string;
}
