import { useCallback, useEffect, useState } from 'react';
import { ConsolePanel } from './components/ConsolePanel.tsx';
import { MemoryView } from './components/MemoryView.tsx';
import { ProvidersView } from './components/ProvidersView.tsx';
import { RoutingGraphPanel } from './components/RoutingGraphPanel.tsx';
import { TopBar, type AppSection, type MobileTab } from './components/TopBar.tsx';
import { UsageApiView } from './components/UsageApiView.tsx';
import type {
  IntentCategory,
  MemoryFact,
  ModelCapabilityTier,
  ModelWithStatus,
  OrchestrationResponse,
  ProviderId,
  ProviderSummary,
  RoutingMode,
  RoutingTrace,
  SessionMessage,
  SessionRecord,
  UsageLogEntry,
  UsageSummary,
} from './core/types.ts';
import { capriApi } from './lib/api.ts';

export default function App() {
  const [activeSection, setActiveSection] = useState<AppSection>('workspace');
  const [mobileTab, setMobileTab] = useState<MobileTab>('console');

  const [models, setModels] = useState<ModelWithStatus[]>([]);
  const [providers, setProviders] = useState<ProviderSummary[]>([]);
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<SessionMessage[]>([]);
  const [facts, setFacts] = useState<MemoryFact[]>([]);
  const [traces, setTraces] = useState<RoutingTrace[]>([]);
  const [activeTrace, setActiveTrace] = useState<RoutingTrace | null>(null);
  const [usageSummary, setUsageSummary] = useState<UsageSummary | null>(null);
  const [usageLogs, setUsageLogs] = useState<UsageLogEntry[]>([]);

  const [routingMode, setRoutingMode] = useState<RoutingMode>('auto');
  const [selectedModelId, setSelectedModelId] = useState<string>('gemini/gemini-3.8-flash');
  const [allowFallbackOnManual, setAllowFallbackOnManual] = useState<boolean>(false);

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [creatingSession, setCreatingSession] = useState(false);
  const [lastError, setLastError] = useState<OrchestrationResponse['error'] | null>(null);
  const [globalError, setGlobalError] = useState<string | null>(null);

  const refreshCoreData = useCallback(async (preferredSessionId?: string | null) => {
    const [modelsRes, sessionsRes, memoryRes, usageRes, tracesRes] = await Promise.all([
      capriApi.listModels(),
      capriApi.listSessions(),
      capriApi.listMemory(),
      capriApi.getUsage(50),
      capriApi.listTraces(25),
    ]);

    setModels(modelsRes.models);
    setProviders(modelsRes.providers);
    setSessions(sessionsRes.sessions);
    setFacts(memoryRes.facts);
    setUsageSummary(usageRes.summary);
    setUsageLogs(usageRes.logs);
    setTraces(tracesRes.traces);

    if (tracesRes.traces.length > 0) {
      setActiveTrace((prev) =>
        prev ? tracesRes.traces.find((t) => t.id === prev.id) ?? tracesRes.traces[0] : tracesRes.traces[0],
      );
    } else {
      setActiveTrace(null);
    }

    const targetSessionId =
      preferredSessionId ?? activeSessionId ?? sessionsRes.sessions[0]?.id ?? null;

    if (targetSessionId) {
      setActiveSessionId(targetSessionId);
      const detail = await capriApi.getSessionDetail(targetSessionId);
      setMessages(detail.messages);
    } else {
      setMessages([]);
    }
  }, [activeSessionId]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await refreshCoreData(null);
      } catch (err) {
        if (mounted) {
          setGlobalError(err instanceof Error ? err.message : 'Falha ao conectar ao Capri Core.');
        }
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [refreshCoreData]);

  async function handleSelectSession(id: string) {
    setActiveSessionId(id);
    setLastError(null);
    const detail = await capriApi.getSessionDetail(id);
    setMessages(detail.messages);
  }

  async function handleCreateSession() {
    setCreatingSession(true);
    try {
      const count = sessions.length + 1;
      const { session } = await capriApi.createSession(`Sessão #${count}`);
      await refreshCoreData(session.id);
      setActiveSection('workspace');
      setMobileTab('console');
      setLastError(null);
    } finally {
      setCreatingSession(false);
    }
  }

  async function handleDeleteSession(id: string) {
    await capriApi.deleteSession(id);
    const remaining = sessions.filter((s) => s.id !== id);
    await refreshCoreData(remaining[0]?.id ?? null);
  }

  async function handleSubmitPrompt(prompt: string, systemPrompt?: string) {
    setSubmitting(true);
    setLastError(null);
    try {
      const response = await capriApi.orchestrate({
        prompt,
        sessionId: activeSessionId ?? undefined,
        routingMode,
        requestedModelId: routingMode === 'manual' ? selectedModelId : undefined,
        allowFallbackOnManual,
        systemPrompt,
      });

      setActiveTrace(response.trace);
      if (!response.ok && response.error) {
        setLastError(response.error);
      }
      await refreshCoreData(response.sessionId);
    } catch (err) {
      setLastError({
        code: 'CLIENT_REQUEST_ERROR',
        message: err instanceof Error ? err.message : 'Erro ao enviar solicitação.',
        limitation: 'Verifique se o servidor Node.js do Capri Core está em execução.',
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggleModel(model: ModelWithStatus) {
    await capriApi.updateModel(model.id, { enabled: !model.enabled });
    await refreshCoreData(activeSessionId);
  }

  async function handleUpdateModelLimits(
    id: string,
    patch: { priority: number; rpmLimit: number; rpdLimit: number; tpdLimit: number },
  ) {
    await capriApi.updateModel(id, patch);
    await refreshCoreData(activeSessionId);
  }

  async function handleRegisterModel(payload: {
    provider: ProviderId;
    modelName: string;
    displayName: string;
    capabilityTier: ModelCapabilityTier;
    strengths: IntentCategory[];
    priority: number;
    rpmLimit: number;
    rpdLimit: number;
    tpdLimit: number;
  }) {
    await capriApi.registerModel(payload);
    await refreshCoreData(activeSessionId);
  }

  async function handleAddFact(payload: {
    category: MemoryFact['category'];
    key: string;
    content: string;
    importance: number;
  }) {
    await capriApi.upsertMemory(payload);
    await refreshCoreData(activeSessionId);
  }

  async function handleToggleFact(fact: MemoryFact) {
    await capriApi.updateMemory(fact.id, { active: !fact.active });
    await refreshCoreData(activeSessionId);
  }

  async function handleDeleteFact(id: string) {
    await capriApi.deleteMemory(id);
    await refreshCoreData(activeSessionId);
  }

  async function handleConfirmFact(id: string) {
    await capriApi.confirmMemory(id);
    await refreshCoreData(activeSessionId);
  }

  async function handleRejectFact(id: string) {
    await capriApi.rejectMemory(id);
    await refreshCoreData(activeSessionId);
  }

  function handleSelectTraceId(traceId: string) {
    const found = traces.find((t) => t.id === traceId);
    if (found) {
      setActiveTrace(found);
      setActiveSection('workspace');
      setMobileTab('graph');
    }
  }

  function handleSelectSection(section: AppSection) {
    setActiveSection(section);
    if (section === 'workspace') {
      if (mobileTab !== 'console' && mobileTab !== 'graph') {
        setMobileTab('console');
      }
    } else {
      setMobileTab(section);
    }
  }

  function handleSelectMobileTab(tab: MobileTab) {
    setMobileTab(tab);
    if (tab === 'console' || tab === 'graph') {
      setActiveSection('workspace');
    } else {
      setActiveSection(tab);
    }
  }

  const activeSession = sessions.find((s) => s.id === activeSessionId) ?? null;

  return (
    <div className="capri-ambient-canvas min-h-screen flex flex-col pb-16 lg:pb-0">
      <TopBar
        activeSection={activeSection}
        mobileTab={mobileTab}
        onSelectSection={handleSelectSection}
        onSelectMobileTab={handleSelectMobileTab}
        onCreateSession={handleCreateSession}
        creatingSession={creatingSession}
      />

      <main className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-4 sm:px-6 sm:py-5">
        {globalError && (
          <div className="mb-4 rounded-xl border border-[#F43F5E]/40 bg-[#F43F5E]/10 px-4 py-3 text-sm text-[#FECDD3]">
            {globalError}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-6 h-[560px] rounded-xl border border-white/[0.08] bg-[#111119] animate-pulse" />
            <div className="hidden lg:block lg:col-span-6 h-[560px] rounded-xl border border-white/[0.08] bg-[#111119] animate-pulse" />
          </div>
        ) : (
          <>
            {activeSection === 'workspace' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
                <div
                  className={`lg:col-span-6 ${
                    mobileTab === 'console' ? 'block' : 'hidden lg:block'
                  }`}
                >
                  <ConsolePanel
                    sessions={sessions}
                    activeSession={activeSession}
                    messages={messages}
                    models={models}
                    routingMode={routingMode}
                    selectedModelId={selectedModelId}
                    allowFallbackOnManual={allowFallbackOnManual}
                    isSubmitting={submitting}
                    lastError={lastError}
                    onSelectSession={handleSelectSession}
                    onDeleteSession={handleDeleteSession}
                    onChangeRoutingMode={setRoutingMode}
                    onChangeSelectedModel={setSelectedModelId}
                    onToggleFallbackOnManual={setAllowFallbackOnManual}
                    onSubmitPrompt={handleSubmitPrompt}
                    onSelectTraceId={handleSelectTraceId}
                  />
                </div>

                <div
                  className={`lg:col-span-6 ${
                    mobileTab === 'graph' ? 'block' : 'hidden lg:block'
                  }`}
                >
                  <RoutingGraphPanel
                    traces={traces}
                    activeTrace={activeTrace}
                    onSelectTrace={setActiveTrace}
                  />
                </div>
              </div>
            )}

            {activeSection === 'providers' && (
              <ProvidersView
                providers={providers}
                models={models}
                onToggleModel={handleToggleModel}
                onUpdateLimits={handleUpdateModelLimits}
                onRegisterModel={handleRegisterModel}
              />
            )}

            {activeSection === 'memory' && (
              <MemoryView
                facts={facts}
                sessions={sessions}
                activeSessionId={activeSessionId}
                onAddFact={handleAddFact}
                onToggleFact={handleToggleFact}
                onDeleteFact={handleDeleteFact}
                onConfirmFact={handleConfirmFact}
                onRejectFact={handleRejectFact}
                onOpenSession={async (id) => {
                  await handleSelectSession(id);
                  setActiveSection('workspace');
                  setMobileTab('console');
                }}
              />
            )}

            {activeSection === 'usage' && (
              <UsageApiView summary={usageSummary} logs={usageLogs} />
            )}
          </>
        )}
      </main>
    </div>
  );
}
