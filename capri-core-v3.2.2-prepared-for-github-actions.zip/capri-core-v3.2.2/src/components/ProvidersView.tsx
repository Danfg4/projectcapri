import { useState } from 'react';
import { Check, KeyRound, Plus, Power, Sliders } from 'lucide-react';
import type {
  IntentCategory,
  ModelCapabilityTier,
  ModelWithStatus,
  ProviderId,
  ProviderSummary,
} from '../core/types.ts';
import {
  AVAILABILITY_LABELS,
  INTENT_LABELS,
  PROVIDER_LABELS,
  TIER_LABELS,
  formatNumber,
} from '../lib/labels.ts';

interface ProvidersViewProps {
  providers: ProviderSummary[];
  models: ModelWithStatus[];
  onToggleModel: (model: ModelWithStatus) => Promise<void>;
  onUpdateLimits: (
    id: string,
    patch: { priority: number; rpmLimit: number; rpdLimit: number; tpdLimit: number },
  ) => Promise<void>;
  onRegisterModel: (payload: {
    provider: ProviderId;
    modelName: string;
    displayName: string;
    capabilityTier: ModelCapabilityTier;
    strengths: IntentCategory[];
    priority: number;
    rpmLimit: number;
    rpdLimit: number;
    tpdLimit: number;
  }) => Promise<void>;
}

const ALL_INTENTS = Object.keys(INTENT_LABELS) as IntentCategory[];

export function ProvidersView({
  providers,
  models,
  onToggleModel,
  onUpdateLimits,
  onRegisterModel,
}: ProvidersViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState({
    priority: 80,
    rpmLimit: 30,
    rpdLimit: 1000,
    tpdLimit: 500000,
  });

  const [showAddForm, setShowAddForm] = useState(false);
  const [newProvider, setNewProvider] = useState<ProviderId>('groq');
  const [newModelName, setNewModelName] = useState('');
  const [newDisplayName, setNewDisplayName] = useState('');
  const [newTier, setNewTier] = useState<ModelCapabilityTier>('balanced');
  const [newStrengths, setNewStrengths] = useState<IntentCategory[]>(['general_chat', 'coding']);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  function startEdit(model: ModelWithStatus) {
    setEditingId(model.id);
    setEditValues({
      priority: model.priority,
      rpmLimit: model.rpmLimit,
      rpdLimit: model.rpdLimit,
      tpdLimit: model.tpdLimit,
    });
  }

  async function saveEdit(id: string) {
    setSaving(true);
    try {
      await onUpdateLimits(id, editValues);
      setEditingId(null);
      setFeedback('Limites e prioridade atualizados no SQLite.');
    } finally {
      setSaving(false);
    }
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    if (!newModelName.trim() || !newDisplayName.trim()) return;
    setSaving(true);
    try {
      await onRegisterModel({
        provider: newProvider,
        modelName: newModelName.trim(),
        displayName: newDisplayName.trim(),
        capabilityTier: newTier,
        strengths: newStrengths.length > 0 ? newStrengths : ['general_chat'],
        priority: 80,
        rpmLimit: 30,
        rpdLimit: 1000,
        tpdLimit: 500000,
      });
      setNewModelName('');
      setNewDisplayName('');
      setShowAddForm(false);
      setFeedback('Modelo registrado com sucesso no Model Registry.');
    } finally {
      setSaving(false);
    }
  }

  function toggleStrength(intent: IntentCategory) {
    setNewStrengths((prev) =>
      prev.includes(intent) ? prev.filter((item) => item !== intent) : [...prev, intent],
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-xl font-semibold text-white">
            Model Registry & Adaptadores
          </h1>
          <p className="mt-1 text-sm text-[#9B99AD]">
            Estado real das variáveis de ambiente no servidor, limites de cota e prioridades do Smart
            Router
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddForm((v) => !v)}
          className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-white/[0.12] bg-[#161622] px-4 py-2 text-xs font-semibold text-white hover:border-[#EC4899]/50 transition-colors cursor-pointer whitespace-nowrap"
        >
          <Plus className="h-3.5 w-3.5 text-[#F97316]" />
          <span>{showAddForm ? 'Fechar formulário' : 'Registrar modelo'}</span>
        </button>
      </div>

      {feedback && (
        <div className="rounded-lg border border-[#34D399]/30 bg-[#34D399]/[0.07] px-4 py-2.5 text-xs text-[#A7F3D0]">
          {feedback}
        </div>
      )}

      {/* Resumo real de adaptadores por provedor */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {providers.map((p) => (
          <div
            key={p.provider}
            className="rounded-xl border border-white/[0.08] bg-[#111119] p-4 flex flex-col justify-between gap-3"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-display text-sm font-semibold text-white">{p.label}</div>
                <div className="mt-0.5 font-mono text-[11px] text-[#8D8B9F]">{p.envKey}</div>
              </div>
              <span
                className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                  p.configured ? 'text-[#34D399]' : 'text-[#FDBA74]'
                }`}
              >
                <KeyRound className="h-3.5 w-3.5" />
                <span>{p.configured ? 'Chave ativa' : 'Aguardando chave'}</span>
              </span>
            </div>

            <div className="flex items-center gap-3 text-xs text-[#9B99AD] tabular-nums border-t border-white/[0.06] pt-2.5">
              <span>
                {p.availableModels}/{p.totalModels} modelos prontos
              </span>
              <span aria-hidden="true">·</span>
              <span>{formatNumber(p.requestsToday)} req hoje</span>
              <span aria-hidden="true">·</span>
              <span>{formatNumber(p.tokensToday)} tok</span>
            </div>
          </div>
        ))}
      </div>

      {/* Formulário para registrar novo modelo */}
      {showAddForm && (
        <form
          onSubmit={handleRegister}
          className="rounded-xl border border-white/[0.1] bg-[#151521] p-5 space-y-4"
        >
          <h2 className="font-display text-sm font-semibold text-white">
            Cadastrar novo modelo no Model Registry
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs text-[#9B99AD] mb-1">Provedor</label>
              <select
                value={newProvider}
                onChange={(e) => setNewProvider(e.target.value as ProviderId)}
                className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs text-white"
              >
                {(Object.keys(PROVIDER_LABELS) as ProviderId[]).map((pid) => (
                  <option key={pid} value={pid}>
                    {PROVIDER_LABELS[pid]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#9B99AD] mb-1">ID técnico do modelo</label>
              <input
                type="text"
                required
                value={newModelName}
                onChange={(e) => setNewModelName(e.target.value)}
                placeholder="Ex.: llama-3.3-70b-specdec"
                className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-[#9B99AD] mb-1">Nome de exibição</label>
              <input
                type="text"
                required
                value={newDisplayName}
                onChange={(e) => setNewDisplayName(e.target.value)}
                placeholder="Ex.: Groq Llama 3.3 SpecDec"
                className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-[#9B99AD] mb-1">Nível de capacidade</label>
              <select
                value={newTier}
                onChange={(e) => setNewTier(e.target.value as ModelCapabilityTier)}
                className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs text-white"
              >
                <option value="fast_economy">Econômico / Rápido</option>
                <option value="balanced">Equilibrado</option>
                <option value="deep_reasoning">Raciocínio Profundo</option>
              </select>
            </div>
          </div>

          <div>
            <div className="text-xs text-[#9B99AD] mb-2">Especialidades do modelo</div>
            <div className="flex flex-wrap gap-2">
              {ALL_INTENTS.map((intent) => {
                const active = newStrengths.includes(intent);
                return (
                  <button
                    key={intent}
                    type="button"
                    onClick={() => toggleStrength(intent)}
                    className={`min-h-[34px] rounded-md border px-3 text-xs font-medium transition-colors cursor-pointer ${
                      active
                        ? 'border-[#EC4899]/60 bg-[#EC4899]/15 text-white'
                        : 'border-white/[0.08] bg-[#0B0B12] text-[#9B99AD] hover:text-white'
                    }`}
                  >
                    {INTENT_LABELS[intent]}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="capri-primary-btn min-h-[40px] rounded-lg px-5 text-xs font-semibold text-white cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Salvando...' : 'Salvar no Registry'}
            </button>
          </div>
        </form>
      )}

      {/* Tabela completa de modelos */}
      <div className="rounded-xl border border-white/[0.08] bg-[#111119] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/[0.08] bg-[#0D0D14] text-[#8D8B9F]">
                <th className="px-4 py-3 font-medium">Modelo</th>
                <th className="px-4 py-3 font-medium">Perfil</th>
                <th className="px-4 py-3 font-medium">Estado Real</th>
                <th className="px-4 py-3 font-medium text-right">Prioridade</th>
                <th className="px-4 py-3 font-medium text-right">Cota (RPM / RPD)</th>
                <th className="px-4 py-3 font-medium text-right">Uso Hoje</th>
                <th className="px-4 py-3 font-medium text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06] tabular-nums">
              {models.map((model) => {
                const isEditing = editingId === model.id;
                return (
                  <tr key={model.id} className="hover:bg-white/[0.02]">
                    <td className="px-4 py-3.5 align-top">
                      <div className="font-medium text-white">{model.displayName}</div>
                      <div className="mt-0.5 font-mono text-[11px] text-[#8D8B9F]">
                        {model.id}
                      </div>
                      <div className="mt-1 text-[11px] text-[#7D7B91]">
                        {model.strengths.map((s) => INTENT_LABELS[s]).join(' · ')}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 align-top whitespace-nowrap text-[#C7C5D6]">
                      <div>{TIER_LABELS[model.capabilityTier]}</div>
                      <div className="mt-0.5 text-[11px] text-[#8D8B9F]">
                        ~{model.avgLatencyMs}ms
                      </div>
                    </td>
                    <td className="px-4 py-3.5 align-top">
                      <div
                        className={`font-medium whitespace-nowrap ${
                          model.availability === 'available'
                            ? 'text-[#34D399]'
                            : model.availability === 'not_configured'
                              ? 'text-[#FDBA74]'
                              : 'text-[#FB7185]'
                        }`}
                      >
                        {AVAILABILITY_LABELS[model.availability]}
                      </div>
                      <div className="mt-0.5 text-[11px] text-[#8D8B9F] max-w-[230px]">
                        {model.availabilityReason}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 align-top text-right font-mono text-white">
                      {isEditing ? (
                        <input
                          type="number"
                          min={1}
                          max={100}
                          value={editValues.priority}
                          onChange={(e) =>
                            setEditValues((v) => ({ ...v, priority: Number(e.target.value) }))
                          }
                          className="w-16 rounded border border-white/20 bg-[#0B0B12] px-2 py-1 text-right text-xs text-white"
                        />
                      ) : (
                        model.priority
                      )}
                    </td>
                    <td className="px-4 py-3.5 align-top text-right font-mono text-white whitespace-nowrap">
                      {isEditing ? (
                        <div className="flex flex-col items-end gap-1">
                          <input
                            type="number"
                            min={1}
                            value={editValues.rpmLimit}
                            onChange={(e) =>
                              setEditValues((v) => ({ ...v, rpmLimit: Number(e.target.value) }))
                            }
                            aria-label="RPM"
                            className="w-20 rounded border border-white/20 bg-[#0B0B12] px-2 py-1 text-right text-xs text-white"
                          />
                          <input
                            type="number"
                            min={1}
                            value={editValues.rpdLimit}
                            onChange={(e) =>
                              setEditValues((v) => ({ ...v, rpdLimit: Number(e.target.value) }))
                            }
                            aria-label="RPD"
                            className="w-20 rounded border border-white/20 bg-[#0B0B12] px-2 py-1 text-right text-xs text-white"
                          />
                        </div>
                      ) : (
                        <div>
                          {model.rpmLimit} rpm / {formatNumber(model.rpdLimit)} dia
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3.5 align-top text-right font-mono text-[#B5B3C4] whitespace-nowrap">
                      <div>{formatNumber(model.quota.requestsToday)} req</div>
                      <div className="text-[11px] text-[#8D8B9F]">
                        {formatNumber(model.quota.tokensToday)} tok
                      </div>
                    </td>
                    <td className="px-4 py-3.5 align-top text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        {isEditing ? (
                          <button
                            type="button"
                            onClick={() => saveEdit(model.id)}
                            disabled={saving}
                            className="inline-flex min-h-[36px] items-center gap-1 rounded-md bg-[#EC4899]/20 border border-[#EC4899]/40 px-2.5 text-xs font-medium text-white cursor-pointer"
                          >
                            <Check className="h-3.5 w-3.5" />
                            <span>Salvar</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => startEdit(model)}
                            title="Ajustar limites e prioridade"
                            className="inline-flex min-h-[36px] min-w-[36px] items-center justify-center rounded-md border border-white/[0.08] bg-[#171722] text-[#B5B3C4] hover:text-white cursor-pointer"
                          >
                            <Sliders className="h-3.5 w-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onToggleModel(model)}
                          title={model.enabled ? 'Desativar modelo' : 'Ativar modelo'}
                          className={`inline-flex min-h-[36px] min-w-[36px] items-center justify-center rounded-md border transition-colors cursor-pointer ${
                            model.enabled
                              ? 'border-[#34D399]/35 bg-[#34D399]/10 text-[#34D399]'
                              : 'border-white/[0.08] bg-[#171722] text-[#8D8B9F]'
                          }`}
                        >
                          <Power className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
