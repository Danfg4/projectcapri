import { Activity, Cpu, Database, GitBranch, Plus, Terminal } from 'lucide-react';

export type AppSection = 'workspace' | 'providers' | 'memory' | 'usage';
export type MobileTab = 'console' | 'graph' | 'providers' | 'memory' | 'usage';

interface TopBarProps {
  activeSection: AppSection;
  mobileTab: MobileTab;
  onSelectSection: (section: AppSection) => void;
  onSelectMobileTab: (tab: MobileTab) => void;
  onCreateSession: () => void;
  creatingSession?: boolean;
}

const DESKTOP_NAV: Array<{ id: AppSection; label: string }> = [
  { id: 'workspace', label: 'Console & Grafo' },
  { id: 'providers', label: 'Provedores' },
  { id: 'memory', label: 'Memória' },
  { id: 'usage', label: 'Consumo & API' },
];

const MOBILE_TABS: Array<{
  id: MobileTab;
  label: string;
  icon: typeof Terminal;
}> = [
  { id: 'console', label: 'Console', icon: Terminal },
  { id: 'graph', label: 'Grafo', icon: GitBranch },
  { id: 'providers', label: 'Modelos', icon: Cpu },
  { id: 'memory', label: 'Memória', icon: Database },
  { id: 'usage', label: 'Consumo', icon: Activity },
];

export function TopBar({
  activeSection,
  mobileTab,
  onSelectSection,
  onSelectMobileTab,
  onCreateSession,
  creatingSession,
}: TopBarProps) {
  return (
    <>
      <header className="sticky top-0 z-30 border-b border-white/[0.08] bg-[#08080D]/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-[1440px] items-center justify-between gap-8 px-4 sm:px-6">
          {/* Zona 1: Wordmark único da Capri Core */}
          <button
            type="button"
            onClick={() => {
              onSelectSection('workspace');
              onSelectMobileTab('console');
            }}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#EC4899]/60 rounded-md py-1"
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              aria-hidden="true"
              className="shrink-0"
            >
              <defs>
                <linearGradient id="capriCoreMark" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#F97316" />
                  <stop offset="0.52" stopColor="#EC4899" />
                  <stop offset="1" stopColor="#A855F7" />
                </linearGradient>
              </defs>
              <circle cx="12" cy="12" r="9.5" stroke="url(#capriCoreMark)" strokeWidth="1.5" />
              <circle cx="12" cy="12" r="3" fill="url(#capriCoreMark)" />
              <path
                d="M12 2.5V6.5M12 17.5V21.5M2.5 12H6.5M17.5 12H21.5"
                stroke="url(#capriCoreMark)"
                strokeWidth="1.4"
                strokeLinecap="round"
              />
            </svg>
            <span className="font-display text-lg font-semibold tracking-tight text-white">
              Capri Core
            </span>
          </button>

          {/* Zona 2: Links de navegação concisos em linha única */}
          <nav
            aria-label="Navegação principal"
            className="hidden lg:flex items-center gap-7"
          >
            {DESKTOP_NAV.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectSection(item.id)}
                  className={`relative py-4 text-sm font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:text-white ${
                    isActive ? 'text-white' : 'text-[#9B99AD] hover:text-white'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span
                      aria-hidden="true"
                      className="absolute inset-x-0 bottom-0 h-[2px] bg-gradient-to-r from-[#F97316] via-[#EC4899] to-[#A855F7]"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zona 3: 1 ação primária */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={onCreateSession}
              disabled={creatingSession}
              className="capri-primary-btn inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{creatingSession ? 'Criando...' : 'Nova Sessão'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Navegação ergonômica Android na zona do polegar (< lg) */}
      <nav
        aria-label="Navegação móvel"
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/[0.08] bg-[#0B0B12]/95 backdrop-blur-md lg:hidden"
        style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      >
        <div className="grid grid-cols-5 h-14">
          {MOBILE_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = mobileTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onSelectMobileTab(tab.id)}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-1 transition-colors ${
                  isActive ? 'text-[#F472B6]' : 'text-[#8D8B9F] hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="text-[11px] font-medium tracking-tight whitespace-nowrap">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
