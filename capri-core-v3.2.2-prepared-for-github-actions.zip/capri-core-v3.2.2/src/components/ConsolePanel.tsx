import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  ChevronDown,
  Lock,
  Send,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { speakText, stopSpeaking, isSpeechSynthesisAvailable } from '../lib/voice.ts';
import type {
  ModelWithStatus,
  OrchestrationResponse,
  RoutingMode,
  SessionMessage,
  SessionRecord,
} from '../core/types.ts';
import {
  AVAILABILITY_LABELS,
  INTENT_LABELS,
  PROVIDER_LABELS,
  formatNumber,
  formatTimeShort,
} from '../lib/labels.ts';

interface ConsolePanelProps {
  sessions: SessionRecord[];
  activeSession: SessionRecord | null;
  messages: SessionMessage[];
  models: ModelWithStatus[];
  routingMode: RoutingMode;
  selectedModelId: string;
  allowFallbackOnManual: boolean;
  isSubmitting: boolean;
  lastError: OrchestrationResponse['error'] | null;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  onChangeRoutingMode: (mode: RoutingMode) => void;
  onChangeSelectedModel: (modelId: string) => void;
  onToggleFallbackOnManual: (value: boolean) => void;
  onSubmitPrompt: (prompt: string, systemPrompt?: string) => Promise<void>;
  onSelectTraceId: (traceId: string) => void;
}

const PROMPT_PRESETS = [
  {
    label: 'Resumo rápido',
    prompt: 'Resuma em 3 tópicos objetivos a diferença entre roteamento estático e roteamento multi-LLM por intenção.',
  },
  {
    label: 'Código TypeScript',
    prompt: 'Escreva uma função TypeScript genérica com retry exponencial e AbortController para chamadas HTTP resilientes.',
  },
  {
    label: 'Arquitetura & Trade-offs',
    prompt: 'Analise os trade-offs entre SQLite embarcado e bancos distribuídos para a memória persistente de uma assistente pessoal.',
  },
  {
    label: 'Memorizar preferência',
    prompt: 'Lembre que eu prefiro respostas técnicas diretas com exemplos em TypeScript.',
  },
];

export function ConsolePanel({
  sessions,
  activeSession,
  messages,
  models,
  routingMode,
  selectedModelId,
  allowFallbackOnManual,
  isSubmitting,
  lastError,
  onSelectSession,
  onDeleteSession,
  onChangeRoutingMode,
  onChangeSelectedModel,
  onToggleFallbackOnManual,
  onSubmitPrompt,
  onSelectTraceId,
}: ConsolePanelProps) {
  const [prompt, setPrompt] = useState('');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  const selectedModel = models.find((m) => m.id === selectedModelId) ?? null;

  useEffect(() => () => stopSpeaking(), []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = prompt.trim();
    if (!trimmed || isSubmitting) return;
    setPrompt('');
    await onSubmitPrompt(trimmed, systemPrompt.trim() || undefined);
  }

  return (
    <section className="flex flex-col rounded-xl border border-white/[0.08] bg-[#111119] overflow-hidden min-h-[560px] lg:h-[calc(100vh-120px)]">
      {/* Cabeçalho do Console */}
      <div className="border-b border-white/[0.08] px-4 py-3.5 sm:px-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-base font-semibold text-white">
              Console do Orquestrador
            </h1>
            <p className="text-xs text-[#9B99AD]">
              Envie comandos reais para testar classificação, roteamento, memória e fallback
            </p>
          </div>

          {/* Seletor de sessão */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <select
                aria-label="Selecionar sessão"
                value={activeSession?.id ?? ''}
                onChange={(e) => onSelectSession(e.target.value)}
                className="min-h-[40px] max-w-[200px] appearance-none rounded-lg border border-white/[0.1] bg-[#171722] pl-3 pr-8 text-xs font-medium text-white focus:border-[#EC4899] focus:outline-none truncate"
              >
                {sessions.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title} ({s.messageCount})
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#9B99AD]" />
            </div>

            {activeSession && sessions.length > 1 && (
              <button
                type="button"
                onClick={() => onDeleteSession(activeSession.id)}
                title="Excluir sessão atual"
                className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-white/[0.08] bg-[#171722] text-[#9B99AD] hover:text-[#FB7185] hover:border-[#FB7185]/40 transition-colors cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Controles de Modo de Roteamento */}
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <div
            role="group"
            aria-label="Modo do Smart Router"
            className="inline-flex rounded-lg border border-white/[0.08] bg-[#0B0B12] p-0.5"
          >
            <button
              type="button"
              onClick={() => onChangeRoutingMode('auto')}
              className={`min-h-[36px] rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                routingMode === 'auto'
                  ? 'bg-[#1F1F2E] text-white'
                  : 'text-[#9B99AD] hover:text-white'
              }`}
            >
              Smart Router Automático
            </button>
            <button
              type="button"
              onClick={() => onChangeRoutingMode('manual')}
              className={`min-h-[36px] rounded-md px-3 text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                routingMode === 'manual'
                  ? 'bg-[#1F1F2E] text-white'
                  : 'text-[#9B99AD] hover:text-white'
              }`}
            >
              Seleção Manual
            </button>
          </div>

          {routingMode === 'manual' && (
            <div className="flex flex-1 flex-wrap items-center gap-2 min-w-[220px]">
              <div className="relative flex-1 min-w-[190px]">
                <select
                  aria-label="Selecionar modelo manual"
                  value={selectedModelId}
                  onChange={(e) => onChangeSelectedModel(e.target.value)}
                  className="min-h-[38px] w-full appearance-none rounded-lg border border-white/[0.1] bg-[#171722] pl-3 pr-8 text-xs font-medium text-white focus:border-[#F97316] focus:outline-none"
                >
                  {models.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.displayName} — {AVAILABILITY_LABELS[m.availability]}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#9B99AD]" />
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-[#B5B3C4] cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={allowFallbackOnManual}
                  onChange={(e) => onToggleFallbackOnManual(e.target.checked)}
                  className="h-4 w-4 rounded border-white/20 bg-[#0B0B12] accent-[#EC4899]"
                />
                <span>Permitir fallback</span>
              </label>
            </div>
          )}

          <button
            type="button"
            onClick={() => setShowAdvanced((v) => !v)}
            className="ml-auto inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium text-[#9B99AD] hover:text-white transition-colors cursor-pointer"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span>Diretiva</span>
          </button>
        </div>

        {routingMode === 'manual' && selectedModel && selectedModel.availability !== 'available' && (
          <div className="mt-2.5 flex items-start gap-2 rounded-lg border border-[#F97316]/30 bg-[#F97316]/[0.07] px-3 py-2 text-xs text-[#FDBA74]">
            <Lock className="h-3.5 w-3.5 mt-0.5 shrink-0" />
            <span>
              {selectedModel.displayName}: {selectedModel.availabilityReason}
              {!allowFallbackOnManual &&
                ' A prioridade manual impedirá substituição silenciosa.'}
            </span>
          </div>
        )}

        {showAdvanced && (
          <div className="mt-3 pt-3 border-t border-white/[0.06]">
            <label className="block text-xs font-medium text-[#B5B3C4] mb-1.5">
              Instrução de sistema adicional para esta execução
            </label>
            <input
              type="text"
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              placeholder="Ex.: Responda em formato de checklist técnico conciso."
              className="w-full rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 py-2 text-xs text-white placeholder-[#69677B] focus:border-[#A855F7] focus:outline-none"
            />
          </div>
        )}
      </div>

      {/* Área de mensagens da sessão compartilhada */}
      <div className="flex-1 overflow-y-auto px-4 py-4 sm:px-5 space-y-5">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col justify-center py-6">
            <div className="max-w-md">
              <p className="font-display text-sm font-semibold text-white">
                Sessão compartilhada pronta
              </p>
              <p className="mt-1.5 text-xs leading-relaxed text-[#9B99AD]">
                Todas as mensagens e fatos memorizados ficam persistidos no SQLite local e são
                compartilhados entre qualquer modelo escolhido pelo Smart Router.
              </p>
            </div>

            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {PROMPT_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => setPrompt(preset.prompt)}
                  className="group flex flex-col items-start rounded-lg border border-white/[0.08] bg-[#161622]/70 p-3 text-left hover:border-[#EC4899]/40 hover:bg-[#191927] transition-colors cursor-pointer"
                >
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-white">
                    <Sparkles className="h-3 w-3 text-[#F97316]" />
                    {preset.label}
                  </span>
                  <span className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-[#9B99AD]">
                    {preset.prompt}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[92%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                    isUser
                      ? 'border border-[#EC4899]/25 bg-[#1B1626] text-white'
                      : 'border border-white/[0.08] bg-[#161622] text-[#ECEBF3]'
                  }`}
                >
                  <div className="whitespace-pre-wrap break-words">{msg.content}</div>
                </div>

                {/* Metadados limpos sem pílulas */}
                <div className="mt-1.5 flex flex-wrap items-center gap-2 px-1 text-[11px] text-[#8D8B9F] tabular-nums">
                  <span>{isUser ? 'Usuário' : msg.modelId ?? 'Capri Core'}</span>
                  {!isUser && (
                    <button
                      type="button"
                      disabled={!isSpeechSynthesisAvailable()}
                      onClick={() => {
                        if (speakingMessageId === msg.id) {
                          stopSpeaking();
                          setSpeakingMessageId(null);
                          return;
                        }
                        const started = speakText(msg.content, 'pt-BR', () => setSpeakingMessageId(null));
                        setSpeakingMessageId(started ? msg.id : null);
                      }}
                      title="Ouvir resposta (voz do navegador, independente do provedor)"
                      aria-label={speakingMessageId === msg.id ? 'Parar leitura' : 'Ouvir resposta'}
                      className="inline-flex items-center gap-1 text-[#A5B4FC] hover:text-white disabled:opacity-40"
                    >
                      {speakingMessageId === msg.id ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
                      <span>{speakingMessageId === msg.id ? 'Parar voz' : 'Ouvir'}</span>
                    </button>
                  )}
                  {!isUser && msg.provider && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{PROVIDER_LABELS[msg.provider]}</span>
                    </>
                  )}
                  {msg.intent && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{INTENT_LABELS[msg.intent]}</span>
                    </>
                  )}
                  <span aria-hidden="true">·</span>
                  <span>{formatTimeShort(msg.createdAt)}</span>
                  {msg.traceId && (
                    <>
                      <span aria-hidden="true">·</span>
                      <button
                        type="button"
                        onClick={() => onSelectTraceId(msg.traceId!)}
                        className="inline-flex items-center gap-0.5 text-[#F472B6] hover:text-white transition-colors cursor-pointer"
                      >
                        <span>Inspecionar rota</span>
                        <ArrowUpRight className="h-3 w-3" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })
        )}

        {lastError && (
          <div className="rounded-lg border border-[#F43F5E]/35 bg-[#F43F5E]/[0.08] px-4 py-3 text-xs text-[#FDA4AF]">
            <div className="flex items-center gap-2 font-semibold text-[#FECDD3]">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <span>Execução interrompida com integridade ({lastError.code})</span>
            </div>
            <p className="mt-1 leading-relaxed">{lastError.message}</p>
            {lastError.limitation && lastError.limitation !== lastError.message && (
              <p className="mt-1 text-[#FBB6CE]">{lastError.limitation}</p>
            )}
          </div>
        )}

        {isSubmitting && (
          <div className="rounded-lg border border-white/[0.08] bg-[#161622]/70 px-4 py-3 text-xs text-[#C7C5D6]">
            Orquestrando solicitação: classificando intenção, consultando memória compartilhada e
            executando via adaptador ativo...
          </div>
        )}
      </div>

      {/* Composer */}
      <form
        onSubmit={handleSubmit}
        className="border-t border-white/[0.08] bg-[#0C0C13] p-3.5 sm:p-4"
      >
        <div className="flex items-end gap-2.5">
          <textarea
            rows={2}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                void handleSubmit(e);
              }
            }}
            placeholder="Digite sua solicitação para o Capri Core (Enter envia, Shift+Enter quebra linha)..."
            className="flex-1 resize-none rounded-lg border border-white/[0.1] bg-[#151520] px-3.5 py-2.5 text-sm text-white placeholder-[#69677B] focus:border-[#EC4899] focus:outline-none"
          />
          <button
            type="submit"
            disabled={isSubmitting || !prompt.trim()}
            className="capri-primary-btn inline-flex min-h-[44px] min-w-[44px] items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold text-white whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
            <span className="hidden sm:inline">{isSubmitting ? 'Enviando...' : 'Executar'}</span>
          </button>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-[#7D7B91] tabular-nums">
          <span>
            Modo: {routingMode === 'auto' ? 'Smart Router Adaptativo' : `Manual (${selectedModel?.displayName ?? '—'})`}
          </span>
          <span>{formatNumber(prompt.length)} / 32.000 caracteres</span>
        </div>
      </form>
    </section>
  );
}
