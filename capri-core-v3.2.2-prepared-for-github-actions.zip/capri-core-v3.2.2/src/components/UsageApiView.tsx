import { useState } from 'react';
import { Check, Copy, Download } from 'lucide-react';
import type { UsageLogEntry, UsageSummary } from '../core/types.ts';
import { PROVIDER_LABELS, formatNumber, formatTimeShort } from '../lib/labels.ts';

interface UsageApiViewProps {
  summary: UsageSummary | null;
  logs: UsageLogEntry[];
}

export function UsageApiView({ summary, logs }: UsageApiViewProps) {
  const [copied, setCopied] = useState(false);
  const [copiedZipUrl, setCopiedZipUrl] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [exportStatus, setExportStatus] = useState<string | null>(null);

  const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';
  const zipDirectUrl = `${origin}/api/v1/export/zip?includeDist=1`;
  const curlExample = `curl -X POST ${origin}/api/v1/orchestrate \\
  -H "Content-Type: application/json" \\
  -d '{
    "prompt": "Explique como implementar retry com backoff exponencial em TypeScript.",
    "routingMode": "auto"
  }'`;

  async function copyCurl() {
    try {
      await navigator.clipboard.writeText(curlExample);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore clipboard errors in restricted frames
    }
  }

  async function copyZipLink() {
    try {
      await navigator.clipboard.writeText(zipDirectUrl);
      setCopiedZipUrl(true);
      setTimeout(() => setCopiedZipUrl(false), 1800);
    } catch {
      // ignore clipboard errors in restricted frames
    }
  }

  async function handleDownloadZip(includeDist = true) {
    setDownloadingZip(true);
    setExportStatus(null);
    try {
      const response = await fetch(`/api/v1/export/zip${includeDist ? '?includeDist=1' : ''}`);
      if (!response.ok) {
        throw new Error(`Erro HTTP ${response.status} ao gerar ZIP.`);
      }
      const fileCount = response.headers.get('X-Capri-Export-Files');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'capri-core-project.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setExportStatus(
        fileCount
          ? `Pacote capri-core-project.zip gerado (${fileCount} arquivos). Caso o iframe do navegador móvel bloqueie downloads, use "Copiar link do ZIP" e abra no Chrome.`
          : 'Pacote capri-core-project.zip baixado com sucesso.',
      );
    } catch (err) {
      setExportStatus(err instanceof Error ? err.message : 'Falha ao baixar ZIP.');
    } finally {
      setDownloadingZip(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-xl font-semibold text-white">
          Consumo, Limites e API Central
        </h1>
        <p className="mt-1 text-sm text-[#9B99AD]">
          Registro real de requisições, tokens e latência no SQLite, além dos endpoints REST
          independentes da interface
        </p>
      </div>

      {/* Exportação completa em ZIP (no topo para acesso rápido no celular) */}
      <div className="rounded-xl border border-[#EC4899]/25 bg-[#151320] p-4 sm:p-5 space-y-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-sm font-semibold text-white">
              Exportar Projeto Completo (.zip)
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-[#C7C5D6] max-w-2xl">
              Inclui frontend React (código + build compilado), backend Node.js/Express,
              adaptadores multi-LLM, testes Vitest, documentação e manifestos de dependências
              (<span className="font-mono text-white">package.json</span> e{' '}
              <span className="font-mono text-white">bun.lock</span>).
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-[#9B99AD] max-w-2xl">
              Nota técnica: a pasta <span className="font-mono">node_modules</span> (~225 MB com
              binários nativos de servidor) não é incluída no ZIP para manter o pacote leve e
              compatível com upload no GitHub pelo celular. Para instalação reproduzível, use{' '}
              <span className="font-mono">bun install --frozen-lockfile</span>; suporte do Bun no Termux Android não foi validado nesta versão.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => handleDownloadZip(true)}
              disabled={downloadingZip}
              className="capri-primary-btn inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold text-white whitespace-nowrap cursor-pointer disabled:opacity-50"
            >
              <Download className="h-4 w-4" />
              <span>{downloadingZip ? 'Empacotando...' : 'Baixar Projeto (.zip)'}</span>
            </button>

            <button
              type="button"
              onClick={copyZipLink}
              className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-lg border border-white/[0.12] bg-[#171722] px-3.5 text-xs font-medium text-white hover:border-[#EC4899]/50 whitespace-nowrap cursor-pointer"
            >
              {copiedZipUrl ? (
                <Check className="h-3.5 w-3.5 text-[#34D399]" />
              ) : (
                <Copy className="h-3.5 w-3.5" />
              )}
              <span>{copiedZipUrl ? 'Link copiado' : 'Copiar link do ZIP'}</span>
            </button>
          </div>
        </div>

        {exportStatus && <p className="text-xs text-[#34D399]">{exportStatus}</p>}
      </div>

      {/* KPIs reais */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5 tabular-nums">
        <div className="rounded-xl border border-white/[0.08] bg-[#111119] p-4">
          <div className="text-xs text-[#8D8B9F]">Requisições totais</div>
          <div className="mt-1 font-mono text-2xl font-semibold text-white">
            {formatNumber(summary?.totalRequests ?? 0)}
          </div>
          <div className="mt-1 text-[11px] text-[#9B99AD]">
            {formatNumber(summary?.successfulRequests ?? 0)} sucesso ·{' '}
            {formatNumber(summary?.failedRequests ?? 0)} falhas
          </div>
        </div>

        <div className="rounded-xl border border-white/[0.08] bg-[#111119] p-4">
          <div className="text-xs text-[#8D8B9F]">Tokens consumidos</div>
          <div className="mt-1 font-mono text-2xl font-semibold text-white">
            {formatNumber(summary?.totalTokens ?? 0)}
          </div>
          <div className="mt-1 text-[11px] text-[#9B99AD]">
            {formatNumber(summary?.totalInputTokens ?? 0)} in ·{' '}
            {formatNumber(summary?.totalOutputTokens ?? 0)} out
          </div>
        </div>

        <div className="rounded-xl border border-white/[0.08] bg-[#111119] p-4">
          <div className="text-xs text-[#8D8B9F]">Latência média</div>
          <div className="mt-1 font-mono text-2xl font-semibold text-white">
            {formatNumber(summary?.avgLatencyMs ?? 0)}ms
          </div>
          <div className="mt-1 text-[11px] text-[#9B99AD]">Medida real por chamada</div>
        </div>

        <div className="rounded-xl border border-white/[0.08] bg-[#111119] p-4">
          <div className="text-xs text-[#8D8B9F]">Fallbacks acionados</div>
          <div className="mt-1 font-mono text-2xl font-semibold text-white">
            {formatNumber(summary?.fallbackCount ?? 0)}
          </div>
          <div className="mt-1 text-[11px] text-[#9B99AD]">Recuperações entre modelos</div>
        </div>

        <div className="col-span-2 lg:col-span-1 rounded-xl border border-white/[0.08] bg-[#111119] p-4">
          <div className="text-xs text-[#8D8B9F]">Custo estimado</div>
          <div className="mt-1 font-mono text-2xl font-semibold text-white">
            ${(summary?.totalEstimatedCostUsd ?? 0).toFixed(5)}
          </div>
          <div className="mt-1 text-[11px] text-[#9B99AD]">Calculado por tabela do Registry</div>
        </div>
      </div>

      {/* API Central Independente */}
      <div className="rounded-xl border border-white/[0.08] bg-[#111119] p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-sm font-semibold text-white">
              Endpoint Central Independente (POST /api/v1/orchestrate)
            </h2>
            <p className="text-xs text-[#9B99AD]">
              Integre clientes Android nativos, CLI ou automações externas diretamente ao núcleo
            </p>
          </div>
          <button
            type="button"
            onClick={copyCurl}
            className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-white/[0.1] bg-[#171722] px-3 text-xs font-medium text-white hover:border-[#EC4899]/50 cursor-pointer"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-[#34D399]" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copiado' : 'Copiar cURL'}</span>
          </button>
        </div>

        <pre className="overflow-x-auto rounded-lg border border-white/[0.06] bg-[#09090F] p-3.5 text-xs leading-relaxed text-[#E2E0EE]">
          <code>{curlExample}</code>
        </pre>

        <div className="flex flex-wrap gap-x-5 gap-y-1.5 pt-1 text-xs text-[#9B99AD] font-mono">
          <span>GET /api/v1/health</span>
          <span>GET /api/v1/models</span>
          <span>GET /api/v1/memory</span>
          <span>GET /api/v1/sessions</span>
          <span>GET /api/v1/traces</span>
          <span>GET /api/v1/usage</span>
          <span>GET /api/v1/export/zip</span>
        </div>
      </div>

      {/* Tabela de logs reais */}
      <div className="rounded-xl border border-white/[0.08] bg-[#111119] overflow-hidden">
        <div className="border-b border-white/[0.08] px-4 py-3.5">
          <h2 className="font-display text-sm font-semibold text-white">
            Registro de Utilização
          </h2>
        </div>

        {logs.length === 0 ? (
          <div className="p-6 text-xs text-[#9B99AD]">
            Ainda não há execuções registradas. Envie uma solicitação no Console para gravar o
            consumo real no SQLite.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/[0.08] bg-[#0D0D14] text-[#8D8B9F]">
                  <th className="px-4 py-2.5 font-medium">Hora</th>
                  <th className="px-4 py-2.5 font-medium">Provedor / Modelo</th>
                  <th className="px-4 py-2.5 font-medium">Status</th>
                  <th className="px-4 py-2.5 font-medium text-right">Latência</th>
                  <th className="px-4 py-2.5 font-medium text-right">Tokens</th>
                  <th className="px-4 py-2.5 font-medium text-right">Custo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.05] tabular-nums">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/[0.02]">
                    <td className="px-4 py-2.5 font-mono text-[#9B99AD] whitespace-nowrap">
                      {formatTimeShort(log.createdAt)}
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="text-white font-medium">{log.modelId}</span>
                      <span className="ml-2 text-[#8D8B9F]">
                        · {PROVIDER_LABELS[log.provider]}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 whitespace-nowrap">
                      <span
                        className={
                          log.status === 'success' ? 'text-[#34D399]' : 'text-[#FB7185]'
                        }
                      >
                        {log.status === 'success' ? 'Sucesso' : log.errorCode ?? 'Erro'}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-white">
                      {formatNumber(log.latencyMs)}ms
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-white">
                      {formatNumber(log.totalTokens)}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-[#B5B3C4]">
                      {log.estimatedCostUsd !== null
                        ? `$${log.estimatedCostUsd.toFixed(6)}`
                        : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
