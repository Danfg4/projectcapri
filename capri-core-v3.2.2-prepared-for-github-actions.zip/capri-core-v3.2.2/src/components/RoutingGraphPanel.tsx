import { useState } from 'react';
import {
  Brain,
  CheckCircle2,
  Cpu,
  Database,
  GitBranch,
  Gauge,
  ShieldAlert,
  Zap,
} from 'lucide-react';
import type { RoutingTrace } from '../core/types.ts';
import {
  AVAILABILITY_LABELS,
  COMPLEXITY_LABELS,
  INTENT_LABELS,
  PROVIDER_LABELS,
  formatNumber,
  formatTimeShort,
} from '../lib/labels.ts';

interface RoutingGraphPanelProps {
  traces: RoutingTrace[];
  activeTrace: RoutingTrace | null;
  onSelectTrace: (trace: RoutingTrace) => void;
}

type GraphNodeId =
  | 'memory'
  | 'intent'
  | 'registry'
  | 'router'
  | 'execution'
  | 'telemetry';

export function RoutingGraphPanel({
  traces,
  activeTrace,
  onSelectTrace,
}: RoutingGraphPanelProps) {
  const [selectedNode, setSelectedNode] = useState<GraphNodeId>('router');

  const fallbackTriggered = (activeTrace?.fallbackAttempts.length ?? 0) > 1;
  const isBlocked = activeTrace?.finalStatus === 'blocked';
  const isFailed = activeTrace?.finalStatus === 'failed';

  const nodes: Array<{
    id: GraphNodeId;
    title: string;
    subtitle: string;
    icon: typeof Brain;
    accent: string;
  }> = [
    {
      id: 'memory',
      title: 'Memória Compartilhada',
      subtitle: activeTrace
        ? `${activeTrace.memoryFactsUsedCount} fatos · ${activeTrace.sessionMessagesUsedCount} turnos`
        : 'Fatos globais + sessão',
      icon: Database,
      accent: '#F97316',
    },
    {
      id: 'intent',
      title: 'Classificador de Intenção',
      subtitle: activeTrace
        ? `${INTENT_LABELS[activeTrace.intent]} · ${COMPLEXITY_LABELS[activeTrace.complexity]}`
        : '7 categorias · complexidade',
      icon: Brain,
      accent: '#FB7185',
    },
    {
      id: 'registry',
      title: 'Model Registry & Cotas',
      subtitle: activeTrace
        ? `${activeTrace.candidates.filter((c) => c.eligible).length}/${activeTrace.candidates.length} elegíveis`
        : 'Chaves reais + RPM/RPD',
      icon: Gauge,
      accent: '#EC4899',
    },
    {
      id: 'router',
      title: 'Smart Router',
      subtitle: activeTrace
        ? activeTrace.routingMode === 'manual'
          ? 'Prioridade manual'
          : 'Política adaptativa'
        : 'Seleção multicritério',
      icon: GitBranch,
      accent: '#D946EF',
    },
    {
      id: 'execution',
      title: fallbackTriggered ? 'Execução + Fallback' : 'Adaptador & Execução',
      subtitle: activeTrace
        ? activeTrace.finalModelId ?? (isBlocked ? 'Bloqueado sem simulação' : 'Falha na execução')
        : 'Gemini ativo · multi-provedor',
      icon: isBlocked || isFailed ? ShieldAlert : Cpu,
      accent: '#A855F7',
    },
    {
      id: 'telemetry',
      title: 'Telemetria Real',
      subtitle: activeTrace
        ? `${formatNumber(activeTrace.totalLatencyMs)}ms · ${formatNumber(activeTrace.totalTokens)} tok`
        : 'Latência · tokens · custo',
      icon: Zap,
      accent: '#8B5CF6',
    },
  ];

  return (
    <section className="flex flex-col rounded-xl border border-white/[0.08] bg-[#111119] overflow-hidden min-h-[560px] lg:h-[calc(100vh-120px)]">
      {/* Cabeçalho do Grafo */}
      <div className="border-b border-white/[0.08] px-4 py-3.5 sm:px-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-base font-semibold text-white">
              Grafo de Roteamento ao Vivo
            </h2>
            <p className="text-xs text-[#9B99AD]">
              Clique em qualquer estágio do pipeline para auditar decisões e candidatos
            </p>
          </div>

          {traces.length > 0 && (
            <select
              aria-label="Selecionar execução recente"
              value={activeTrace?.id ?? ''}
              onChange={(e) => {
                const found = traces.find((t) => t.id === e.target.value);
                if (found) onSelectTrace(found);
              }}
              className="min-h-[38px] max-w-[230px] rounded-lg border border-white/[0.1] bg-[#171722] px-3 text-xs text-white focus:border-[#A855F7] focus:outline-none truncate"
            >
              {traces.map((t) => (
                <option key={t.id} value={t.id}>
                  {formatTimeShort(t.createdAt)} — {t.finalModelId ?? t.finalStatus} ({t.requestPreview.slice(0, 26)})
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Corpo do Grafo + Inspetor */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
        {/* Diagrama SVG + Nós Interativos */}
        <div className="relative rounded-xl border border-white/[0.08] bg-[#0B0B12] p-4">
          {/* SVG de conexões luminosas no fundo (desktop 3x2) */}
          <svg
            aria-hidden="true"
            viewBox="0 0 600 180"
            className="hidden sm:block pointer-events-none absolute inset-0 h-full w-full opacity-55"
            preserveAspectRatio="none"
          >
            <defs>
              <linearGradient id="capriFlowLine" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#F97316" />
                <stop offset="50%" stopColor="#EC4899" />
                <stop offset="100%" stopColor="#A855F7" />
              </linearGradient>
            </defs>
            <path
              d="M 100 48 L 300 48 L 500 48 C 540 48 540 132 500 132 L 300 132 L 100 132"
              fill="none"
              stroke="url(#capriFlowLine)"
              strokeWidth="1.5"
              strokeDasharray={activeTrace ? undefined : '4 4'}
            />
          </svg>

          <div className="relative grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[nodes[0], nodes[1], nodes[2], nodes[5], nodes[4], nodes[3]].map((node) => {
              const Icon = node.icon;
              const isSelected = selectedNode === node.id;
              return (
                <button
                  key={node.id}
                  type="button"
                  onClick={() => setSelectedNode(node.id)}
                  className={`flex min-h-[74px] flex-col justify-between rounded-lg border p-3 text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#EC4899]/60 bg-[#181626]'
                      : 'border-white/[0.08] bg-[#12121B]/95 hover:border-white/[0.18]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-white truncate">
                      {node.title}
                    </span>
                    <Icon
                      className="h-4 w-4 shrink-0"
                      style={{ color: node.accent }}
                    />
                  </div>
                  <p className="mt-1.5 text-[11px] text-[#A8A6BA] truncate tabular-nums">
                    {node.subtitle}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Painel de Auditoria do Nó Selecionado */}
        {!activeTrace ? (
          <div className="rounded-xl border border-white/[0.08] bg-[#161622]/60 p-5 text-xs leading-relaxed text-[#9B99AD]">
            Nenhuma execução selecionada ainda. Envie uma solicitação pelo Console para visualizar o
            traço completo de decisão, pontuações dos modelos, consumo real e eventuais fallbacks.
          </div>
        ) : (
          <div className="rounded-xl border border-white/[0.08] bg-[#151521] p-4 sm:p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
              <div>
                <h3 className="font-display text-sm font-semibold text-white">
                  {nodes.find((n) => n.id === selectedNode)?.title}
                </h3>
                <p className="text-xs text-[#9B99AD]">
                  Traço {activeTrace.id.slice(0, 14)} · {formatTimeShort(activeTrace.createdAt)}
                </p>
              </div>
              <span
                className={`text-xs font-medium ${
                  activeTrace.finalStatus === 'completed'
                    ? 'text-[#34D399]'
                    : 'text-[#FB7185]'
                }`}
              >
                {activeTrace.finalStatus === 'completed'
                  ? 'Concluído'
                  : activeTrace.finalStatus === 'blocked'
                    ? 'Bloqueado (sem simulação)'
                    : 'Falha na execução'}
              </span>
            </div>

            {selectedNode === 'memory' && (
              <div className="space-y-2 text-xs text-[#D4D2E2]">
                <p>
                  <span className="text-[#8D8B9F]">Fatos globais injetados:</span>{' '}
                  <span className="font-mono tabular-nums text-white">
                    {activeTrace.memoryFactsUsedCount}
                  </span>
                </p>
                <p>
                  <span className="text-[#8D8B9F]">Turnos anteriores da sessão compartilhada:</span>{' '}
                  <span className="font-mono tabular-nums text-white">
                    {activeTrace.sessionMessagesUsedCount}
                  </span>
                </p>
                <p className="text-[#9B99AD] leading-relaxed">
                  O contexto portátil foi empacotado em formato agnóstico de provedor, garantindo que
                  qualquer modelo selecionado ou acionado via fallback receba as mesmas diretrizes.
                </p>
              </div>
            )}

            {selectedNode === 'intent' && (
              <div className="space-y-2 text-xs text-[#D4D2E2]">
                <div className="grid grid-cols-3 gap-3 tabular-nums">
                  <div>
                    <div className="text-[#8D8B9F]">Intenção</div>
                    <div className="mt-0.5 font-semibold text-white">
                      {INTENT_LABELS[activeTrace.intent]}
                    </div>
                  </div>
                  <div>
                    <div className="text-[#8D8B9F]">Complexidade</div>
                    <div className="mt-0.5 font-semibold text-white">
                      {COMPLEXITY_LABELS[activeTrace.complexity]}
                    </div>
                  </div>
                  <div>
                    <div className="text-[#8D8B9F]">Confiança</div>
                    <div className="mt-0.5 font-mono font-semibold text-white">
                      {Math.round(activeTrace.intentConfidence * 100)}%
                    </div>
                  </div>
                </div>
                <p className="pt-1 text-[#B5B3C4] leading-relaxed">
                  {activeTrace.intentReasoning}
                </p>
              </div>
            )}

            {selectedNode === 'registry' && (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-white/[0.08] text-[#8D8B9F]">
                      <th className="pb-2 font-medium">Modelo</th>
                      <th className="pb-2 font-medium">Estado</th>
                      <th className="pb-2 font-medium text-right">Score</th>
                      <th className="pb-2 pl-3 font-medium">Avaliação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.05] tabular-nums">
                    {activeTrace.candidates.map((cand) => (
                      <tr key={cand.modelId} className="hover:bg-white/[0.02]">
                        <td className="py-2 pr-2 font-medium text-white whitespace-nowrap">
                          {cand.displayName}
                        </td>
                        <td className="py-2 pr-2 whitespace-nowrap">
                          <span
                            className={
                              cand.eligible ? 'text-[#34D399]' : 'text-[#9B99AD]'
                            }
                          >
                            {AVAILABILITY_LABELS[cand.availability]}
                          </span>
                        </td>
                        <td className="py-2 text-right font-mono text-white">
                          {cand.eligible ? cand.score.toFixed(1) : '—'}
                        </td>
                        <td className="py-2 pl-3 text-[#9B99AD] max-w-[260px] truncate" title={cand.reason}>
                          {cand.reason}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {selectedNode === 'router' && (
              <div className="space-y-2.5 text-xs">
                <div className="flex flex-wrap gap-4 tabular-nums">
                  <div>
                    <span className="text-[#8D8B9F]">Modo:</span>{' '}
                    <span className="text-white font-medium">
                      {activeTrace.routingMode === 'manual'
                        ? 'Manual (prioridade do usuário)'
                        : 'Automático adaptativo'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#8D8B9F]">Selecionado:</span>{' '}
                    <span className="font-mono text-white">
                      {activeTrace.selectedModelId ?? 'Nenhum disponível'}
                    </span>
                  </div>
                </div>
                <p className="rounded-lg border border-white/[0.06] bg-[#0E0E16] p-3 text-[#D4D2E2] leading-relaxed">
                  {activeTrace.selectionReason}
                </p>
              </div>
            )}

            {selectedNode === 'execution' && (
              <div className="space-y-2.5 text-xs">
                {activeTrace.fallbackAttempts.length === 0 ? (
                  <p className="text-[#FDA4AF]">
                    Nenhuma chamada externa executada: {activeTrace.errorMessage}
                  </p>
                ) : (
                  <div className="space-y-2">
                    {activeTrace.fallbackAttempts.map((att) => (
                      <div
                        key={`${att.attempt}-${att.modelId}`}
                        className="flex items-start justify-between gap-3 rounded-lg border border-white/[0.06] bg-[#0E0E16] px-3 py-2.5"
                      >
                        <div className="flex items-start gap-2">
                          <CheckCircle2
                            className={`h-4 w-4 mt-0.5 shrink-0 ${
                              att.status === 'success' ? 'text-[#34D399]' : 'text-[#FB7185]'
                            }`}
                          />
                          <div>
                            <div className="font-medium text-white">
                              Tentativa {att.attempt} · {att.displayName} ({PROVIDER_LABELS[att.provider]})
                            </div>
                            {att.errorMessage && (
                              <div className="mt-0.5 text-[#FDA4AF]">{att.errorMessage}</div>
                            )}
                          </div>
                        </div>
                        <span className="font-mono tabular-nums text-[#9B99AD] shrink-0">
                          {formatNumber(att.latencyMs)}ms
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {selectedNode === 'telemetry' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs tabular-nums">
                <div className="rounded-lg border border-white/[0.06] bg-[#0E0E16] p-3">
                  <div className="text-[#8D8B9F]">Latência total</div>
                  <div className="mt-1 font-mono text-base font-semibold text-white">
                    {formatNumber(activeTrace.totalLatencyMs)}ms
                  </div>
                </div>
                <div className="rounded-lg border border-white/[0.06] bg-[#0E0E16] p-3">
                  <div className="text-[#8D8B9F]">Tokens entrada</div>
                  <div className="mt-1 font-mono text-base font-semibold text-white">
                    {formatNumber(activeTrace.inputTokens)}
                  </div>
                </div>
                <div className="rounded-lg border border-white/[0.06] bg-[#0E0E16] p-3">
                  <div className="text-[#8D8B9F]">Tokens saída</div>
                  <div className="mt-1 font-mono text-base font-semibold text-white">
                    {formatNumber(activeTrace.outputTokens)}
                  </div>
                </div>
                <div className="rounded-lg border border-white/[0.06] bg-[#0E0E16] p-3">
                  <div className="text-[#8D8B9F]">Custo estimado</div>
                  <div className="mt-1 font-mono text-base font-semibold text-white">
                    {activeTrace.estimatedCostUsd !== null
                      ? `$${activeTrace.estimatedCostUsd.toFixed(6)}`
                      : '—'}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
