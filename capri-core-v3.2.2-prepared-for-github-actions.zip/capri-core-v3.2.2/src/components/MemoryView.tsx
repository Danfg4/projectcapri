import { useState } from 'react';
import { Database, Plus, Trash2, XCircle } from 'lucide-react';
import type { MemoryFact, SessionRecord } from '../core/types.ts';
import { formatTimeShort } from '../lib/labels.ts';

interface MemoryViewProps {
  facts: MemoryFact[];
  sessions: SessionRecord[];
  activeSessionId: string | null;
  onAddFact: (payload: {
    category: MemoryFact['category'];
    key: string;
    content: string;
    importance: number;
  }) => Promise<void>;
  onToggleFact: (fact: MemoryFact) => Promise<void>;
  onDeleteFact: (id: string) => Promise<void>;
  onConfirmFact: (id: string) => Promise<void>;
  onRejectFact: (id: string) => Promise<void>;
  onOpenSession: (id: string) => void;
}

const CATEGORY_LABELS: Record<MemoryFact['category'], string> = {
  preference: 'Preferência',
  identity: 'Identidade',
  project: 'Projeto',
  constraint: 'Restrição',
  knowledge: 'Conhecimento',
};

export function MemoryView({
  facts,
  sessions,
  activeSessionId,
  onAddFact,
  onToggleFact,
  onDeleteFact,
  onConfirmFact,
  onRejectFact,
  onOpenSession,
}: MemoryViewProps) {
  const [category, setCategory] = useState<MemoryFact['category']>('preference');
  const [key, setKey] = useState('');
  const [content, setContent] = useState('');
  const [importance, setImportance] = useState(8);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!key.trim() || !content.trim()) return;
    setSaving(true);
    try {
      await onAddFact({
        category,
        key: key.trim(),
        content: content.trim(),
        importance,
      });
      setKey('');
      setContent('');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-xl font-semibold text-white">
          Memória Persistente Compartilhada
        </h1>
        <p className="mt-1 text-sm text-[#9B99AD]">
          Fatos globais e contexto unificado de sessão compartilhados entre Gemini, Groq, OpenAI,
          Claude, DeepSeek e Grok
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Coluna Esquerda: Fatos Globais */}
        <div className="lg:col-span-7 space-y-4">
          <form
            onSubmit={handleSubmit}
            className="rounded-xl border border-white/[0.08] bg-[#111119] p-4 sm:p-5 space-y-3.5"
          >
            <h2 className="font-display text-sm font-semibold text-white">
              Adicionar fato global compartilhado
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-[#9B99AD] mb-1">Categoria</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as MemoryFact['category'])}
                  className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs text-white"
                >
                  {(Object.keys(CATEGORY_LABELS) as MemoryFact['category'][]).map((cat) => (
                    <option key={cat} value={cat}>
                      {CATEGORY_LABELS[cat]}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#9B99AD] mb-1">Chave</label>
                <input
                  type="text"
                  required
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="Ex.: stack_principal"
                  className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-[#9B99AD] mb-1">Relevância (1–10)</label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={importance}
                  onChange={(e) => setImportance(Number(e.target.value))}
                  className="w-full min-h-[40px] rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 text-xs font-mono text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#9B99AD] mb-1">Conteúdo persistente</label>
              <textarea
                rows={2}
                required
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Ex.: O projeto Capri Core prioriza TypeScript estrito e arquitetura modular independente."
                className="w-full rounded-lg border border-white/[0.1] bg-[#0B0B12] px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={saving}
                className="capri-primary-btn inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-4 text-xs font-semibold text-white cursor-pointer disabled:opacity-50"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>{saving ? 'Salvando...' : 'Persistir fato'}</span>
              </button>
            </div>
          </form>

          <div className="rounded-xl border border-white/[0.08] bg-[#111119] divide-y divide-white/[0.06]">
            {facts.length === 0 ? (
              <div className="p-6 text-xs text-[#9B99AD]">
                Nenhum fato global registrado ainda. Você pode cadastrar acima ou enviar no Console
                uma instrução iniciada por &ldquo;Lembre que...&rdquo;.
              </div>
            ) : (
              facts.map((fact) => (
                <div
                  key={fact.id}
                  className="flex items-start justify-between gap-4 p-4 hover:bg-white/[0.02]"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#8D8B9F] tabular-nums">
                      <span className="font-mono text-[#F472B6]">{fact.key}</span>
                      <span aria-hidden="true">·</span>
                      <span>{CATEGORY_LABELS[fact.category]}</span>
                      <span aria-hidden="true">·</span>
                      <span>Relevância {fact.importance}/10</span>
                      <span aria-hidden="true">·</span>
                      <span className={fact.status === 'pending_confirmation' ? 'text-amber-300' : fact.status === 'rejected' ? 'text-rose-300' : fact.active ? 'text-[#34D399]' : 'text-[#8D8B9F]'}>
                        {fact.status === 'pending_confirmation' ? 'Aguardando confirmação' : fact.status === 'rejected' ? 'Rejeitado' : fact.active ? 'Ativo no contexto' : 'Pausado'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className={fact.sensitivity === 'restricted' ? 'text-rose-300' : fact.sensitivity === 'private' ? 'text-amber-200' : 'text-[#8D8B9F]'}>
                        {fact.sensitivity === 'restricted' ? 'Restrito' : fact.sensitivity === 'private' ? 'Privado' : 'Normal'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Confiança {Math.round(fact.confidence * 100)}%</span>
                      <span aria-hidden="true">·</span>
                      <span>{fact.userConfirmed ? 'Confirmado' : 'Não confirmado'}</span>
                    </div>
                    <p className="mt-1.5 text-sm text-[#ECEBF3] leading-relaxed">{fact.content}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {fact.status === 'pending_confirmation' && (
                      <>
                      <button
                        type="button"
                        onClick={() => onConfirmFact(fact.id)}
                        className="min-h-[36px] rounded-md border border-amber-400/30 bg-amber-400/10 px-2.5 text-xs text-amber-200 hover:text-white cursor-pointer"
                      >
                        Confirmar atualização
                      </button>
                      <button
                        type="button"
                        onClick={() => onRejectFact(fact.id)}
                        className="inline-flex min-h-[36px] items-center gap-1 rounded-md border border-rose-400/30 bg-rose-400/10 px-2.5 text-xs text-rose-200 hover:text-white cursor-pointer"
                      >
                        <XCircle className="h-3.5 w-3.5" /> Rejeitar
                      </button>
                      </>
                    )}
                    {fact.status !== 'rejected' && <button
                      type="button"
                      onClick={() => onToggleFact(fact)}
                      className="min-h-[36px] rounded-md border border-white/[0.08] bg-[#171722] px-2.5 text-xs text-[#D4D2E2] hover:text-white cursor-pointer"
                    >
                      {fact.active ? 'Pausar' : 'Ativar'}
                    </button>}
                    <button
                      type="button"
                      onClick={() => onDeleteFact(fact.id)}
                      title="Excluir fato"
                      className="inline-flex min-h-[36px] min-w-[36px] items-center justify-center rounded-md border border-white/[0.08] bg-[#171722] text-[#9B99AD] hover:text-[#FB7185] cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Coluna Direita: Sessões Compartilhadas */}
        <div className="lg:col-span-5 rounded-xl border border-white/[0.08] bg-[#111119] overflow-hidden">
          <div className="border-b border-white/[0.08] px-4 py-3.5">
            <h2 className="font-display text-sm font-semibold text-white">
              Sessões de Contexto Unificado
            </h2>
            <p className="text-xs text-[#9B99AD]">
              Histórico preservado mesmo quando respostas vêm de modelos diferentes
            </p>
          </div>
          <div className="divide-y divide-white/[0.06]">
            {sessions.map((session) => {
              const isCurrent = session.id === activeSessionId;
              return (
                <button
                  key={session.id}
                  type="button"
                  onClick={() => onOpenSession(session.id)}
                  className={`flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors cursor-pointer ${
                    isCurrent ? 'bg-[#181626]' : 'hover:bg-white/[0.02]'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Database className="h-3.5 w-3.5 text-[#A855F7] shrink-0" />
                      <span className="text-sm font-medium text-white truncate">
                        {session.title}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-[#8D8B9F] tabular-nums">
                      <span>{session.messageCount} mensagens</span>
                      <span aria-hidden="true">·</span>
                      <span>Atualizada {formatTimeShort(session.updatedAt)}</span>
                    </div>
                  </div>
                  <span className="text-xs font-medium text-[#F472B6] shrink-0">
                    {isCurrent ? 'Aberta' : 'Abrir'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
