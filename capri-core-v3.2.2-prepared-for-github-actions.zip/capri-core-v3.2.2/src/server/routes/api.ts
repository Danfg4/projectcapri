import express from 'express';
import { timingSafeEqual } from 'node:crypto';
import type {
  IntentCategory,
  MemoryFact,
  ModelCapabilityTier,
  OrchestrationRequest,
  ProviderId,
} from '../../core/types.ts';
import type { CapriCoreOrchestrator } from '../core/orchestrator.ts';
import { MemoryAccessPolicy } from '../core/memory-policy.ts';
import { buildProjectZipBuffer } from '../core/project-exporter.ts';

const VALID_PROVIDERS: ProviderId[] = ['gemini', 'groq', 'openai', 'anthropic', 'deepseek', 'xai'];
const VALID_TIERS: ModelCapabilityTier[] = ['fast_economy', 'balanced', 'deep_reasoning'];
const VALID_CATEGORIES: MemoryFact['category'][] = [
  'preference',
  'identity',
  'project',
  'constraint',
  'knowledge',
];

export function createApiRouter(
  orchestrator: CapriCoreOrchestrator,
  apiToken: string | undefined,
  adminToken: string | undefined,
): express.Router {
  const router = express.Router();
  const memoryAccessPolicy = new MemoryAccessPolicy();

  // Fail closed: no API route is available until a sufficiently strong token is configured.
  router.use((req, res, next) => {
    if (!apiToken || apiToken.length < 32 || !adminToken || adminToken.length < 32 || apiToken === adminToken) {
      res.status(503).json({
        error: { code: 'API_AUTH_NOT_CONFIGURED', message: 'Tokens de API e administração não configurados corretamente no servidor.' },
      });
      return;
    }

    const authorization = req.get('authorization') ?? '';
    const supplied = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
    const suppliedBuffer = Buffer.from(supplied);
    const matches = (candidate: string) => {
      const expectedBuffer = Buffer.from(candidate);
      return suppliedBuffer.length === expectedBuffer.length && timingSafeEqual(suppliedBuffer, expectedBuffer);
    };
    const isAdmin = matches(adminToken);
    const isApiUser = matches(apiToken);

    if (!isAdmin && !isApiUser) {
      res.setHeader('WWW-Authenticate', 'Bearer');
      res.status(401).json({
        error: { code: 'UNAUTHORIZED', message: 'Token de acesso ausente ou inválido.' },
      });
      return;
    }
    res.locals.capriRole = isAdmin ? 'admin' : 'user';
    next();
  });

  const requireAdmin: express.RequestHandler = (_req, res, next) => {
    if (res.locals.capriRole !== 'admin') {
      res.status(403).json({
        error: { code: 'ADMIN_REQUIRED', message: 'Esta operação exige o token administrativo do Capri Core.' },
      });
      return;
    }
    next();
  };

  router.get('/health', (_req, res) => {
    try {
      const integrity = orchestrator.db.pragma('quick_check', { simple: true }) as string;
      const connected = integrity === 'ok';
      const providers = orchestrator.modelRegistry.getProviderSummaries();
      res.status(connected ? 200 : 503).json({
        status: connected ? 'ok' : 'degraded',
        engine: 'Capri Core',
        database: {
          connected,
          integrity,
          path: orchestrator.db.name,
        },
        providers,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      res.status(503).json({
        status: 'degraded',
        engine: 'Capri Core',
        database: {
          connected: false,
          path: orchestrator.db.name,
          error: error instanceof Error ? error.message : String(error),
        },
        timestamp: new Date().toISOString(),
      });
    }
  });

  // Orquestração principal independente da interface
  router.post('/orchestrate', async (req, res) => {
    try {
      const body = req.body as Partial<OrchestrationRequest> | undefined;
      if (!body || typeof body.prompt !== 'string' || body.prompt.trim().length === 0) {
        res.status(400).json({
          ok: false,
          error: {
            code: 'INVALID_REQUEST',
            message: 'Informe "prompt" como string não vazia.',
          },
        });
        return;
      }

      if (body.prompt.length > 32000) {
        res.status(400).json({
          ok: false,
          error: {
            code: 'PROMPT_TOO_LARGE',
            message: 'O prompt excede o limite de 32.000 caracteres.',
          },
        });
        return;
      }

      const result = await orchestrator.orchestrate({
        prompt: body.prompt,
        sessionId: typeof body.sessionId === 'string' ? body.sessionId : undefined,
        routingMode: body.routingMode === 'manual' || body.routingMode === 'auto' ? body.routingMode : undefined,
        requestedModelId: typeof body.requestedModelId === 'string' ? body.requestedModelId : undefined,
        allowFallbackOnManual: Boolean(body.allowFallbackOnManual),
        systemPrompt: typeof body.systemPrompt === 'string' ? body.systemPrompt : undefined,
        maxFallbackAttempts:
          typeof body.maxFallbackAttempts === 'number' ? body.maxFallbackAttempts : undefined,
        saveMemory: body.saveMemory !== false,
      });

      res.status(result.ok ? 200 : 422).json(result);
    } catch (error) {
      res.status(500).json({
        ok: false,
        error: {
          code: 'INTERNAL_ORCHESTRATION_ERROR',
          message: error instanceof Error ? error.message : 'Erro interno no Capri Core.',
        },
      });
    }
  });

  // Model Registry & Provedores
  router.get('/models', async (_req, res) => {
    await orchestrator.modelRegistry.refreshAvailability();
    const models = orchestrator.modelRegistry.listModels();
    const providers = orchestrator.modelRegistry.getProviderSummaries();
    res.json({ models, providers });
  });

  router.post('/models', requireAdmin, (req, res) => {
    try {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const provider = String(body.provider ?? '') as ProviderId;
      const modelName = String(body.modelName ?? '').trim();
      const displayName = String(body.displayName ?? '').trim();
      const capabilityTier = String(body.capabilityTier ?? 'balanced') as ModelCapabilityTier;

      if (!VALID_PROVIDERS.includes(provider)) {
        res.status(400).json({ error: 'Provedor inválido.' });
        return;
      }
      if (!modelName || !displayName) {
        res.status(400).json({ error: 'Campos modelName e displayName são obrigatórios.' });
        return;
      }
      if (!VALID_TIERS.includes(capabilityTier)) {
        res.status(400).json({ error: 'Nível de capacidade inválido.' });
        return;
      }
      const nonNegativeNumericFields = ['costPer1kInput', 'costPer1kOutput', 'avgLatencyMs', 'priority', 'rpmLimit', 'rpdLimit', 'tpdLimit', 'maxContextTokens'];
      const invalidNumericField = nonNegativeNumericFields.find((key) => {
        const value = body[key];
        return value !== undefined && (typeof value !== 'number' || !Number.isFinite(value) || value < 0);
      });
      if (invalidNumericField) {
        res.status(400).json({ error: `Campo numérico inválido: ${invalidNumericField}. Informe um número finito não negativo.` });
        return;
      }

      const strengths = Array.isArray(body.strengths)
        ? (body.strengths.map(String) as IntentCategory[])
        : (['general_chat'] as IntentCategory[]);

      const created = orchestrator.modelRegistry.registerModel({
        id: typeof body.id === 'string' ? body.id : undefined,
        provider,
        modelName,
        displayName,
        envKey: typeof body.envKey === 'string' ? body.envKey : undefined,
        enabled: body.enabled !== false,
        capabilityTier,
        strengths,
        costPer1kInput: typeof body.costPer1kInput === 'number' ? body.costPer1kInput : 0,
        costPer1kOutput: typeof body.costPer1kOutput === 'number' ? body.costPer1kOutput : 0,
        avgLatencyMs: typeof body.avgLatencyMs === 'number' ? body.avgLatencyMs : 1200,
        priority: typeof body.priority === 'number' ? body.priority : 75,
        rpmLimit: typeof body.rpmLimit === 'number' ? body.rpmLimit : 30,
        rpdLimit: typeof body.rpdLimit === 'number' ? body.rpdLimit : 1000,
        tpdLimit: typeof body.tpdLimit === 'number' ? body.tpdLimit : 500000,
        maxContextTokens: typeof body.maxContextTokens === 'number' ? body.maxContextTokens : 128000,
        notes: typeof body.notes === 'string' ? body.notes : '',
      });

      res.status(201).json({ model: created });
    } catch (error) {
      res.status(400).json({
        error: error instanceof Error ? error.message : 'Falha ao registrar modelo.',
      });
    }
  });

  router.patch('/models/:id(*)', requireAdmin, (req, res) => {
    const modelId = req.params.id;
    const body = req.body as Record<string, unknown>;
    const updated = orchestrator.modelRegistry.updateModel(modelId, {
      enabled: typeof body.enabled === 'boolean' ? body.enabled : undefined,
      priority: typeof body.priority === 'number' ? body.priority : undefined,
      rpmLimit: typeof body.rpmLimit === 'number' ? body.rpmLimit : undefined,
      rpdLimit: typeof body.rpdLimit === 'number' ? body.rpdLimit : undefined,
      tpdLimit: typeof body.tpdLimit === 'number' ? body.tpdLimit : undefined,
      notes: typeof body.notes === 'string' ? body.notes : undefined,
    });

    if (!updated) {
      res.status(404).json({ error: 'Modelo não encontrado.' });
      return;
    }
    res.json({ model: updated });
  });

  // Memória Persistente Compartilhada
  router.get('/memory', (_req, res) => {
    const isAdmin = res.locals.capriRole === 'admin';
    const facts = orchestrator.sharedMemory.listFacts(false)
      .filter((fact) => memoryAccessPolicy.canExposeInProtectedApi(fact, isAdmin ? 'admin' : 'user'));
    res.json({ facts });
  });

  router.post('/memory', requireAdmin, (req, res) => {
    const body = req.body as Record<string, unknown>;
    const category = String(body.category ?? 'knowledge') as MemoryFact['category'];
    const key = String(body.key ?? '').trim();
    const content = String(body.content ?? '').trim();

    if (!VALID_CATEGORIES.includes(category)) {
      res.status(400).json({ error: 'Categoria de memória inválida.' });
      return;
    }
    if (!key || !content) {
      res.status(400).json({ error: 'Campos key e content são obrigatórios.' });
      return;
    }

    try {
      const fact = orchestrator.sharedMemory.upsertFact({
        category,
        key,
        content,
        importance: typeof body.importance === 'number' ? body.importance : 7,
        active: body.active !== false,
        sourceModel: typeof body.sourceModel === 'string' ? body.sourceModel : 'manual',
        scope: body.scope === 'session' || body.scope === 'temporary' ? body.scope : 'long_term',
        sessionId: typeof body.sessionId === 'string' ? body.sessionId : null,
        sourceType: body.sourceType === 'inferred' || body.sourceType === 'imported' ? body.sourceType : 'admin',
        sourceRef: typeof body.sourceRef === 'string' ? body.sourceRef : null,
        confidence: typeof body.confidence === 'number' ? body.confidence : body.userConfirmed === false ? 0.65 : 1,
        userConfirmed: body.userConfirmed !== false,
        validFrom: typeof body.validFrom === 'string' ? body.validFrom : null,
        expiresAt: typeof body.expiresAt === 'string' ? body.expiresAt : null,
        sensitivity: body.sensitivity === 'normal' || body.sensitivity === 'private' || body.sensitivity === 'restricted' ? body.sensitivity : undefined,
      });
      res.status(201).json({ fact });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Falha ao persistir memória.' });
    }
  });

  router.patch('/memory/:id', requireAdmin, (req, res) => {
    const body = req.body as Record<string, unknown>;
    try {
      const updated = orchestrator.sharedMemory.updateFact(req.params.id, {
      category:
        typeof body.category === 'string' && VALID_CATEGORIES.includes(body.category as MemoryFact['category'])
          ? (body.category as MemoryFact['category'])
          : undefined,
      key: typeof body.key === 'string' ? body.key : undefined,
      content: typeof body.content === 'string' ? body.content : undefined,
      importance: typeof body.importance === 'number' ? body.importance : undefined,
      active: typeof body.active === 'boolean' ? body.active : undefined,
      scope: body.scope === 'long_term' || body.scope === 'session' || body.scope === 'temporary' ? body.scope : undefined,
      sessionId: body.sessionId === null || typeof body.sessionId === 'string' ? body.sessionId : undefined,
      sourceType: ['user_explicit', 'user_confirmed', 'admin', 'inferred', 'imported', 'legacy', 'session_summary'].includes(String(body.sourceType)) ? body.sourceType as MemoryFact['sourceType'] : undefined,
      sourceRef: body.sourceRef === null || typeof body.sourceRef === 'string' ? body.sourceRef : undefined,
      confidence: typeof body.confidence === 'number' ? body.confidence : undefined,
      userConfirmed: typeof body.userConfirmed === 'boolean' ? body.userConfirmed : undefined,
      validFrom: body.validFrom === null || typeof body.validFrom === 'string' ? body.validFrom : undefined,
      expiresAt: body.expiresAt === null || typeof body.expiresAt === 'string' ? body.expiresAt : undefined,
      });

      if (!updated) {
        res.status(404).json({ error: 'Fato de memória não encontrado.' });
        return;
      }
      res.json({ fact: updated });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Falha ao atualizar memória.' });
    }
  });

  router.post('/memory/:id/relations', requireAdmin, (req, res) => {
    const body = req.body as Record<string, unknown>;
    const targetId = typeof body.targetId === 'string' ? body.targetId : '';
    const relationType = body.relationType;
    if (!targetId || !['related_to', 'contradicts', 'supersedes', 'derived_from'].includes(String(relationType))) {
      res.status(400).json({ error: 'targetId e relationType válidos são obrigatórios.' });
      return;
    }
    try {
      orchestrator.memoryEngine.relateFacts(req.params.id, targetId, relationType as 'related_to' | 'contradicts' | 'supersedes' | 'derived_from');
      res.status(201).json({ ok: true });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Falha ao relacionar memórias.' });
    }
  });

  router.get('/memory/:id/history', (req, res) => {
    const isAdmin = res.locals.capriRole === 'admin';
    const fact = orchestrator.sharedMemory.listFacts(false).find((item) =>
      item.id === req.params.id && memoryAccessPolicy.canExposeInProtectedApi(item, isAdmin ? 'admin' : 'user'));
    if (!fact) {
      res.status(404).json({ error: 'Memória não encontrada.' });
      return;
    }
    res.json({ history: orchestrator.memoryEngine.getFactHistory(req.params.id) });
  });

  router.post('/memory/:id/confirm', requireAdmin, (req, res) => {
    const confirmed = orchestrator.memoryEngine.confirmFact(req.params.id);
    if (!confirmed) {
      res.status(404).json({ error: 'Memória pendente de confirmação não encontrada.' });
      return;
    }
    res.json({ fact: confirmed });
  });

  router.post('/memory/:id/reject', requireAdmin, (req, res) => {
    const rejected = orchestrator.memoryEngine.rejectFact(req.params.id);
    if (!rejected) {
      res.status(404).json({ error: 'Proposta pendente não encontrada ou não pode ser rejeitada.' });
      return;
    }
    res.json({ fact: rejected });
  });

  router.patch('/memory/:id/sensitivity', requireAdmin, (req, res) => {
    const body = req.body as Record<string, unknown>;
    if (!['normal', 'private', 'restricted'].includes(String(body.sensitivity))) {
      res.status(400).json({ error: 'Classificação de sensibilidade inválida.' });
      return;
    }
    try {
      const updated = orchestrator.memoryEngine.changeSensitivity(
        req.params.id,
        body.sensitivity as MemoryFact['sensitivity'],
        body.confirmDowngrade === true,
      );
      if (!updated) {
        res.status(404).json({ error: 'Memória não encontrada.' });
        return;
      }
      res.json({ fact: updated });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Falha ao alterar sensibilidade.' });
    }
  });

  router.delete('/memory/:id', requireAdmin, (req, res) => {
    const deleted = orchestrator.sharedMemory.deleteFact(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'Fato de memória não encontrado.' });
      return;
    }
    res.json({ ok: true });
  });

  // Sessões compartilhadas entre modelos
  router.get('/sessions', (_req, res) => {
    const sessions = orchestrator.sharedMemory.listSessions();
    res.json({ sessions });
  });

  router.post('/sessions', requireAdmin, (req, res) => {
    const body = req.body as Record<string, unknown> | undefined;
    const session = orchestrator.sharedMemory.createSession(
      typeof body?.title === 'string' ? body.title : undefined,
      typeof body?.activeModelOverride === 'string' ? body.activeModelOverride : null,
    );
    res.status(201).json({ session });
  });

  router.get('/sessions/:id', (req, res) => {
    const session = orchestrator.sharedMemory.getSession(req.params.id);
    if (!session) {
      res.status(404).json({ error: 'Sessão não encontrada.' });
      return;
    }
    const messages = orchestrator.sharedMemory.getSessionMessages(session.id, 100);
    res.json({ session, messages });
  });

  router.patch('/sessions/:id', requireAdmin, (req, res) => {
    const body = req.body as Record<string, unknown>;
    const updated = orchestrator.sharedMemory.updateSession(req.params.id, {
      title: typeof body.title === 'string' ? body.title : undefined,
      activeModelOverride:
        body.activeModelOverride === null || typeof body.activeModelOverride === 'string'
          ? (body.activeModelOverride as string | null)
          : undefined,
    });
    if (!updated) {
      res.status(404).json({ error: 'Sessão não encontrada.' });
      return;
    }
    res.json({ session: updated });
  });

  router.delete('/sessions/:id', requireAdmin, (req, res) => {
    const deleted = orchestrator.sharedMemory.deleteSession(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'Sessão não encontrada.' });
      return;
    }
    res.json({ ok: true });
  });

  // Consumo, cotas e traços de roteamento
  router.get('/usage', (req, res) => {
    const limit = Math.min(200, Math.max(1, Number(req.query.limit ?? 50)));
    const summary = orchestrator.quotaController.getUsageSummary();
    const logs = orchestrator.quotaController.listRecentLogs(limit);
    res.json({ summary, logs });
  });

  router.get('/traces', (req, res) => {
    const limit = Math.min(100, Math.max(1, Number(req.query.limit ?? 30)));
    const traces = orchestrator.quotaController.listRecentTraces(limit);
    res.json({ traces });
  });

  router.get('/traces/:id', (req, res) => {
    const trace = orchestrator.quotaController.getTraceById(req.params.id);
    if (!trace) {
      res.status(404).json({ error: 'Traço de roteamento não encontrado.' });
      return;
    }
    res.json({ trace });
  });

  // Exportação integral do código-fonte e dependências declaradas em ZIP
  router.get('/export/zip', requireAdmin, async (req, res) => {
    try {
      const includeDist = req.query.includeDist === '1' || req.query.includeDist === 'true';
      const { buffer, filename, fileCount } = await buildProjectZipBuffer(process.cwd(), {
        includeDist,
      });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('X-Capri-Export-Files', String(fileCount));
      res.send(buffer);
    } catch (error) {
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Falha ao gerar arquivo ZIP.',
      });
    }
  });

  return router;
}
