import type {
  AdapterErrorType,
  ComplexityLevel,
  IntentCategory,
  ModelDefinition,
  ProviderId,
} from '../../core/types.ts';

export interface ConversationTurn {
  role: 'user' | 'assistant';
  content: string;
  modelId?: string | null;
}

export interface AdapterExecuteInput {
  model: ModelDefinition;
  prompt: string;
  systemInstruction: string;
  history: ConversationTurn[];
  intent: IntentCategory;
  complexity: ComplexityLevel;
  timeoutMs?: number;
  maxOutputTokens?: number;
}

export interface AdapterExecuteOutput {
  text: string;
  inputTokens: number | null;
  outputTokens: number | null;
  totalTokens: number | null;
  latencyMs: number;
  rawModelUsed: string;
}

export class AdapterExecutionError extends Error {
  readonly errorType: AdapterErrorType;
  readonly retryable: boolean;
  readonly statusCode?: number;
  readonly provider: ProviderId;

  constructor(params: {
    message: string;
    errorType: AdapterErrorType;
    retryable: boolean;
    provider: ProviderId;
    statusCode?: number;
  }) {
    super(params.message);
    this.name = 'AdapterExecutionError';
    this.errorType = params.errorType;
    this.retryable = params.retryable;
    this.provider = params.provider;
    this.statusCode = params.statusCode;
  }
}

export interface ProviderAdapter {
  readonly provider: ProviderId;
  isConfigured(model: ModelDefinition): boolean;
  /** Confirms that this exact model ID is exposed by the authenticated provider account. */
  listModels(envKey: string): Promise<string[]>;
  execute(input: AdapterExecuteInput): Promise<AdapterExecuteOutput>;
}

export function getEnvKey(envKey: string): string | undefined {
  const val = process.env[envKey];
  if (!val) return undefined;
  const trimmed = val.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}
