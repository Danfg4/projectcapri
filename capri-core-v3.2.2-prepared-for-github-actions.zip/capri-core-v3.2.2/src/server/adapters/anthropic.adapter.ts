import type { ModelDefinition } from '../../core/types.ts';
import {
  AdapterExecutionError,
  getEnvKey,
  type AdapterExecuteInput,
  type AdapterExecuteOutput,
  type ProviderAdapter,
} from './base.ts';

interface AnthropicMessagesResponse {
  content?: Array<{ type: string; text?: string }>;
  usage?: {
    input_tokens?: number;
    output_tokens?: number;
  };
  error?: {
    type?: string;
    message?: string;
  };
}

export class AnthropicAdapter implements ProviderAdapter {
  readonly provider = 'anthropic' as const;

  isConfigured(model: ModelDefinition): boolean {
    return Boolean(getEnvKey(model.envKey));
  }

  async listModels(envKey: string): Promise<string[]> {
    const apiKey = getEnvKey(envKey);
    if (!apiKey) return [];
    const baseUrl = (getEnvKey('ANTHROPIC_BASE_URL') ?? 'https://api.anthropic.com/v1').replace(/\/+$/, '');
    let response: Response;
    try {
      response = await fetch(`${baseUrl}/models?limit=1000`, {
        headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
        signal: AbortSignal.timeout(10000),
      });
    } catch (error) {
      throw new AdapterExecutionError({
        provider: 'anthropic', errorType: 'upstream_error', retryable: true,
        message: `Não foi possível consultar o catálogo Anthropic: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
    if (response.status === 401 || response.status === 403) {
      throw new AdapterExecutionError({ provider: 'anthropic', errorType: 'auth_error', retryable: false, statusCode: response.status, message: 'A credencial Anthropic foi rejeitada durante a verificação do catálogo.' });
    }
    if (response.status === 429) {
      throw new AdapterExecutionError({ provider: 'anthropic', errorType: 'rate_limit', retryable: true, statusCode: 429, message: 'O catálogo Anthropic aplicou rate limit.' });
    }
    if (!response.ok) {
      throw new AdapterExecutionError({ provider: 'anthropic', errorType: 'upstream_error', retryable: response.status >= 500, statusCode: response.status, message: `Falha HTTP ${response.status} ao consultar o catálogo Anthropic.` });
    }
    const payload = await response.json() as { data?: Array<{ id?: string }> };
    return Array.isArray(payload.data) ? payload.data.map((item) => String(item.id ?? '')).filter(Boolean) : [];
  }

  async execute(input: AdapterExecuteInput): Promise<AdapterExecuteOutput> {
    const apiKey = getEnvKey(input.model.envKey);
    if (!apiKey) {
      throw new AdapterExecutionError({
        provider: 'anthropic',
        errorType: 'missing_key',
        retryable: false,
        message: `Provedor Anthropic Claude aguardando configuração externa: defina ${input.model.envKey} no arquivo .env do servidor.`,
      });
    }

    const baseUrl = (getEnvKey('ANTHROPIC_BASE_URL') ?? 'https://api.anthropic.com/v1').replace(/\/+$/, '');
    const endpoint = `${baseUrl}/messages`;
    const timeoutMs = input.timeoutMs ?? 45000;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const startedAt = Date.now();

    const messages = [
      ...input.history.map((turn) => ({
        role: turn.role,
        content: turn.content,
      })),
      { role: 'user' as const, content: input.prompt },
    ];

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: input.model.modelName,
          max_tokens: input.maxOutputTokens ?? 4096,
          system: input.systemInstruction,
          messages,
        }),
        signal: controller.signal,
      });

      const latencyMs = Date.now() - startedAt;
      const payload = (await response.json().catch(() => ({}))) as AnthropicMessagesResponse;

      if (!response.ok) {
        const msg = payload?.error?.message ?? `HTTP ${response.status} em Anthropic`;
        if (response.status === 401 || response.status === 403) {
          throw new AdapterExecutionError({
            provider: 'anthropic',
            errorType: 'auth_error',
            retryable: false,
            statusCode: response.status,
            message: `Chave Anthropic inválida ou sem permissão: ${msg}`,
          });
        }
        if (response.status === 429) {
          throw new AdapterExecutionError({
            provider: 'anthropic',
            errorType: 'rate_limit',
            retryable: true,
            statusCode: 429,
            message: `Limite de taxa Anthropic atingido: ${msg}`,
          });
        }
        if (response.status === 404) {
          throw new AdapterExecutionError({
            provider: 'anthropic',
            errorType: 'invalid_model',
            retryable: true,
            statusCode: 404,
            message: `Modelo ${input.model.modelName} não encontrado ou não habilitado na conta Anthropic: ${msg}`,
          });
        }
        throw new AdapterExecutionError({
          provider: 'anthropic',
          errorType: 'upstream_error',
          retryable: response.status >= 500 || response.status === 408,
          statusCode: response.status,
          message: `Erro no adaptador Anthropic: ${msg}`,
        });
      }

      const text =
        payload.content
          ?.filter((block) => block.type === 'text' && typeof block.text === 'string')
          .map((block) => block.text)
          .join('\n')
          .trim() ?? '';

      if (!text) {
        throw new AdapterExecutionError({
          provider: 'anthropic',
          errorType: 'upstream_error',
          retryable: true,
          message: `Anthropic retornou resposta vazia para ${input.model.modelName}.`,
        });
      }

      const inputTokens = payload.usage?.input_tokens ?? null;
      const outputTokens = payload.usage?.output_tokens ?? null;
      const totalTokens =
        inputTokens !== null && outputTokens !== null ? inputTokens + outputTokens : null;

      return {
        text,
        inputTokens,
        outputTokens,
        totalTokens,
        latencyMs,
        rawModelUsed: input.model.modelName,
      };
    } catch (error) {
      if (error instanceof AdapterExecutionError) {
        throw error;
      }
      if ((error as Error)?.name === 'AbortError') {
        throw new AdapterExecutionError({
          provider: 'anthropic',
          errorType: 'timeout',
          retryable: true,
          message: `Tempo limite de ${timeoutMs}ms excedido ao consultar Anthropic.`,
        });
      }
      throw new AdapterExecutionError({
        provider: 'anthropic',
        errorType: 'upstream_error',
        retryable: true,
        message: `Falha de conexão com Anthropic: ${(error as Error).message}`,
      });
    } finally {
      clearTimeout(timer);
    }
  }
}
