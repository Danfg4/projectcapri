import type { ModelDefinition, ProviderId } from '../../core/types.ts';
import {
  AdapterExecutionError,
  getEnvKey,
  type AdapterExecuteInput,
  type AdapterExecuteOutput,
  type ProviderAdapter,
} from './base.ts';

interface OpenAICompatibleConfig {
  provider: Exclude<ProviderId, 'gemini' | 'anthropic'>;
  defaultBaseUrl: string;
  baseUrlEnvKey: string;
  displayLabel: string;
}

interface OpenAIChatCompletionResponse {
  choices?: Array<{
    message?: {
      content?: string | null;
    };
  }>;
  usage?: {
    prompt_tokens?: number;
    completion_tokens?: number;
    total_tokens?: number;
  };
  error?: {
    message?: string;
    type?: string;
    code?: string;
  };
}

export class OpenAICompatibleAdapter implements ProviderAdapter {
  readonly provider: Exclude<ProviderId, 'gemini' | 'anthropic'>;
  private readonly defaultBaseUrl: string;
  private readonly baseUrlEnvKey: string;
  private readonly displayLabel: string;

  constructor(config: OpenAICompatibleConfig) {
    this.provider = config.provider;
    this.defaultBaseUrl = config.defaultBaseUrl;
    this.baseUrlEnvKey = config.baseUrlEnvKey;
    this.displayLabel = config.displayLabel;
  }

  isConfigured(model: ModelDefinition): boolean {
    return Boolean(getEnvKey(model.envKey));
  }

  async listModels(envKey: string): Promise<string[]> {
    const apiKey = getEnvKey(envKey);
    if (!apiKey) return [];
    const baseUrl = (getEnvKey(this.baseUrlEnvKey) ?? this.defaultBaseUrl).replace(/\/+$/, '');
    let response: Response;
    try {
      response = await fetch(`${baseUrl}/models`, {
        headers: { Authorization: `Bearer ${apiKey}` },
        signal: AbortSignal.timeout(10000),
      });
    } catch (error) {
      throw new AdapterExecutionError({
        provider: this.provider,
        errorType: 'upstream_error',
        retryable: true,
        message: `Não foi possível consultar o catálogo de modelos de ${this.displayLabel}: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
    if (response.status === 401 || response.status === 403) {
      throw new AdapterExecutionError({
        provider: this.provider, errorType: 'auth_error', retryable: false,
        statusCode: response.status, message: `A credencial de ${this.displayLabel} foi rejeitada durante a verificação do catálogo.`,
      });
    }
    if (response.status === 429) {
      throw new AdapterExecutionError({
        provider: this.provider, errorType: 'rate_limit', retryable: true,
        statusCode: 429, message: `O catálogo de ${this.displayLabel} aplicou rate limit.`,
      });
    }
    if (!response.ok) {
      throw new AdapterExecutionError({
        provider: this.provider, errorType: 'upstream_error', retryable: response.status >= 500,
        statusCode: response.status, message: `Falha HTTP ${response.status} ao consultar o catálogo de ${this.displayLabel}.`,
      });
    }
    const payload = await response.json() as { data?: Array<{ id?: string }> };
    return Array.isArray(payload.data) ? payload.data.map((item) => String(item.id ?? '')).filter(Boolean) : [];
  }

  async execute(input: AdapterExecuteInput): Promise<AdapterExecuteOutput> {
    const apiKey = getEnvKey(input.model.envKey);
    if (!apiKey) {
      throw new AdapterExecutionError({
        provider: this.provider,
        errorType: 'missing_key',
        retryable: false,
        message: `Provedor ${this.displayLabel} aguardando configuração externa: defina ${input.model.envKey} no arquivo .env do servidor.`,
      });
    }

    const baseUrl = (getEnvKey(this.baseUrlEnvKey) ?? this.defaultBaseUrl).replace(/\/+$/, '');
    const endpoint = `${baseUrl}/chat/completions`;
    const timeoutMs = input.timeoutMs ?? 40000;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const startedAt = Date.now();

    const messages = [
      { role: 'system', content: input.systemInstruction },
      ...input.history.map((turn) => ({
        role: turn.role,
        content: turn.content,
      })),
      { role: 'user', content: input.prompt },
    ];

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: input.model.modelName,
          max_tokens: input.maxOutputTokens ?? 4096,
          messages,
        }),
        signal: controller.signal,
      });

      const latencyMs = Date.now() - startedAt;
      const payload = (await response.json().catch(() => ({}))) as OpenAIChatCompletionResponse;

      if (!response.ok) {
        const msg = payload?.error?.message ?? `HTTP ${response.status} em ${this.displayLabel}`;
        if (response.status === 401 || response.status === 403) {
          throw new AdapterExecutionError({
            provider: this.provider,
            errorType: 'auth_error',
            retryable: false,
            statusCode: response.status,
            message: `Chave inválida ou sem permissão em ${this.displayLabel}: ${msg}`,
          });
        }
        if (response.status === 429) {
          throw new AdapterExecutionError({
            provider: this.provider,
            errorType: 'rate_limit',
            retryable: true,
            statusCode: 429,
            message: `Limite de taxa/cota atingido em ${this.displayLabel}: ${msg}`,
          });
        }
        if (response.status === 404) {
          throw new AdapterExecutionError({
            provider: this.provider,
            errorType: 'invalid_model',
            retryable: true,
            statusCode: 404,
            message: `Modelo ${input.model.modelName} não disponível em ${this.displayLabel}: ${msg}`,
          });
        }
        throw new AdapterExecutionError({
          provider: this.provider,
          errorType: 'upstream_error',
          retryable: response.status >= 500 || response.status === 408,
          statusCode: response.status,
          message: `Erro em ${this.displayLabel}: ${msg}`,
        });
      }

      const text = payload.choices?.[0]?.message?.content?.trim() ?? '';
      if (!text) {
        throw new AdapterExecutionError({
          provider: this.provider,
          errorType: 'upstream_error',
          retryable: true,
          message: `${this.displayLabel} retornou resposta vazia para ${input.model.modelName}.`,
        });
      }

      const inputTokens = payload.usage?.prompt_tokens ?? null;
      const outputTokens = payload.usage?.completion_tokens ?? null;
      const totalTokens =
        payload.usage?.total_tokens ??
        (inputTokens !== null && outputTokens !== null ? inputTokens + outputTokens : null);

      return {
        text,
        inputTokens,
        outputTokens,
        totalTokens,
        latencyMs,
        rawModelUsed: input.model.modelName,
      };
    } catch (error) {
      if (error instanceof AdapterExecutionError) {
        throw error;
      }
      if ((error as Error)?.name === 'AbortError') {
        throw new AdapterExecutionError({
          provider: this.provider,
          errorType: 'timeout',
          retryable: true,
          message: `Tempo limite de ${timeoutMs}ms excedido ao consultar ${this.displayLabel}.`,
        });
      }
      throw new AdapterExecutionError({
        provider: this.provider,
        errorType: 'upstream_error',
        retryable: true,
        message: `Falha de conexão com ${this.displayLabel}: ${(error as Error).message}`,
      });
    } finally {
      clearTimeout(timer);
    }
  }
}
