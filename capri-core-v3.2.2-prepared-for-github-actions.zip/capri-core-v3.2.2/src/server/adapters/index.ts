import type { ProviderId } from '../../core/types.ts';
import { AnthropicAdapter } from './anthropic.adapter.ts';
import type { ProviderAdapter } from './base.ts';
import { GeminiAdapter } from './gemini.adapter.ts';
import { OpenAICompatibleAdapter } from './openai-compatible.adapter.ts';

export function createDefaultAdapters(): Record<ProviderId, ProviderAdapter> {
  return {
    gemini: new GeminiAdapter(),
    groq: new OpenAICompatibleAdapter({
      provider: 'groq',
      defaultBaseUrl: 'https://api.groq.com/openai/v1',
      baseUrlEnvKey: 'GROQ_BASE_URL',
      displayLabel: 'Groq',
    }),
    openai: new OpenAICompatibleAdapter({
      provider: 'openai',
      defaultBaseUrl: 'https://api.openai.com/v1',
      baseUrlEnvKey: 'OPENAI_BASE_URL',
      displayLabel: 'OpenAI',
    }),
    anthropic: new AnthropicAdapter(),
    deepseek: new OpenAICompatibleAdapter({
      provider: 'deepseek',
      defaultBaseUrl: 'https://api.deepseek.com',
      baseUrlEnvKey: 'DEEPSEEK_BASE_URL',
      displayLabel: 'DeepSeek',
    }),
    xai: new OpenAICompatibleAdapter({
      provider: 'xai',
      defaultBaseUrl: 'https://api.x.ai/v1',
      baseUrlEnvKey: 'XAI_BASE_URL',
      displayLabel: 'xAI Grok',
    }),
  };
}

export const PROVIDER_META: Record<ProviderId, { label: string; envKey: string }> = {
  gemini: { label: 'Google Gemini', envKey: 'GEMINI_API_KEY' },
  groq: { label: 'Groq Cloud', envKey: 'GROQ_API_KEY' },
  openai: { label: 'OpenAI', envKey: 'OPENAI_API_KEY' },
  anthropic: { label: 'Anthropic Claude', envKey: 'ANTHROPIC_API_KEY' },
  deepseek: { label: 'DeepSeek', envKey: 'DEEPSEEK_API_KEY' },
  xai: { label: 'xAI Grok', envKey: 'XAI_API_KEY' },
};
