import type { ModelDefinition } from '../../core/types.ts';
import {
  AdapterExecutionError,
  getEnvKey,
  type AdapterExecuteInput,
  type AdapterExecuteOutput,
  type ProviderAdapter,
} from './base.ts';

export class GeminiAdapter implements ProviderAdapter {
  readonly provider = 'gemini' as const;

  isConfigured(model: ModelDefinition): boolean {
    return Boolean(getEnvKey(model.envKey));
  }

  async listModels(envKey: string): Promise<string[]> {
    const apiKey = getEnvKey(envKey);
    if (!apiKey) return [];
    let response: Response;
    try {
      response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`, {
        signal: AbortSignal.timeout(10000),
      });
    } catch (error) {
      throw new AdapterExecutionError({
        provider: 'gemini', errorType: 'upstream_error', retryable: true,
        message: `Não foi possível consultar o catálogo Gemini: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
    if (response.status === 401 || response.status === 403) {
      throw new AdapterExecutionError({ provider: 'gemini', errorType: 'auth_error', retryable: false, statusCode: response.status, message: 'A credencial Gemini foi rejeitada durante a verificação do catálogo.' });
    }
    if (response.status === 429) {
      throw new AdapterExecutionError({ provider: 'gemini', errorType: 'rate_limit', retryable: true, statusCode: 429, message: 'O catálogo Gemini aplicou rate limit.' });
    }
    if (!response.ok) {
      throw new AdapterExecutionError({ provider: 'gemini', errorType: 'upstream_error', retryable: response.status >= 500, statusCode: response.status, message: `Falha HTTP ${response.status} ao consultar o catálogo Gemini.` });
    }
    const payload = await response.json() as { models?: Array<{ name?: string; supportedGenerationMethods?: string[] }> };
    return (payload.models ?? [])
      .filter((item) => item.supportedGenerationMethods?.includes('generateContent'))
      .map((item) => (item.name ?? '').replace(/^models\//, ''))
      .filter(Boolean);
  }

  async execute(input: AdapterExecuteInput): Promise<AdapterExecuteOutput> {
    const apiKey = getEnvKey(input.model.envKey);
    if (!apiKey) {
      throw new AdapterExecutionError({
        provider: 'gemini',
        errorType: 'missing_key',
        retryable: false,
        message: `Chave de ambiente ${input.model.envKey} não configurada no servidor para o provedor Gemini.`,
      });
    }

    const contents = [
      ...input.history.map((turn) => ({
        role: turn.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: turn.content }],
      })),
      { role: 'user', parts: [{ text: input.prompt }] },
    ];

    const supportsThinkingLevel = input.model.modelName.startsWith('gemini-3.8-');
    const thinkingLevel = supportsThinkingLevel
      ? input.complexity === 'high'
        ? 'HIGH'
        : input.complexity === 'medium'
          ? 'MEDIUM'
          : 'LOW'
      : undefined;

    const startedAt = Date.now();
    const timeoutMs = input.timeoutMs ?? 45000;
    const controller = new AbortController();
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      controller.abort(new Error(`Gemini request timed out after ${timeoutMs}ms`));
    }, timeoutMs);

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(input.model.modelName)}:generateContent?key=${encodeURIComponent(apiKey)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            contents,
            ...(input.systemInstruction ? { systemInstruction: { parts: [{ text: input.systemInstruction }] } } : {}),
            generationConfig: {
              maxOutputTokens: input.maxOutputTokens ?? 4096,
              ...(thinkingLevel ? { thinkingConfig: { thinkingLevel } } : {}),
            },
          }),
        },
      );

      if (response.status === 401 || response.status === 403) {
        throw new AdapterExecutionError({
          provider: 'gemini', errorType: 'auth_error', retryable: false,
          statusCode: response.status,
          message: 'A credencial Gemini foi rejeitada durante a geração.',
        });
      }
      if (response.status === 429) {
        throw new AdapterExecutionError({
          provider: 'gemini', errorType: 'rate_limit', retryable: true,
          statusCode: 429, message: 'O Gemini aplicou rate limit.',
        });
      }
      if (!response.ok) {
        const detail = await response.text().catch(() => '');
        throw new AdapterExecutionError({
          provider: 'gemini',
          errorType: response.status === 404 ? 'invalid_model' : 'upstream_error',
          retryable: response.status >= 500 || response.status === 404,
          statusCode: response.status,
          message: `Falha HTTP ${response.status} no Gemini${detail ? `: ${detail.slice(0, 500)}` : ''}.`,
        });
      }

      const payload = await response.json() as {
        candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
        usageMetadata?: {
          promptTokenCount?: number;
          candidatesTokenCount?: number;
          totalTokenCount?: number;
        };
      };
      const text = (payload.candidates?.[0]?.content?.parts ?? [])
        .map((part) => part.text ?? '')
        .join('')
        .trim();

      if (!text) {
        throw new AdapterExecutionError({
          provider: 'gemini',
          errorType: 'upstream_error',
          retryable: true,
          message: `O modelo ${input.model.modelName} retornou resposta vazia.`,
        });
      }

      const latencyMs = Date.now() - startedAt;
      const usage = payload.usageMetadata;
      const inputTokens = usage?.promptTokenCount ?? null;
      const outputTokens = usage?.candidatesTokenCount ?? null;
      const totalTokens =
        usage?.totalTokenCount ??
        (inputTokens !== null && outputTokens !== null ? inputTokens + outputTokens : null);

      return {
        text,
        inputTokens,
        outputTokens,
        totalTokens,
        latencyMs,
        rawModelUsed: input.model.modelName,
      };
    } catch (error) {
      if (timedOut) {
        throw new AdapterExecutionError({
          provider: 'gemini',
          errorType: 'timeout',
          retryable: true,
          message: `Tempo limite de ${timeoutMs}ms excedido na chamada ao modelo ${input.model.modelName}; a requisição foi abortada.`,
        });
      }
      if (error instanceof AdapterExecutionError) throw error;
      if (controller.signal.aborted) {
        throw new AdapterExecutionError({
          provider: 'gemini', errorType: 'upstream_error', retryable: true,
          message: 'A requisição Gemini foi cancelada antes de concluir.',
        });
      }
      throw normalizeGeminiError(error);
    } finally {
      clearTimeout(timeout);
    }
  }
}

function normalizeGeminiError(error: unknown): AdapterExecutionError {
  const errObj = error as { status?: number; code?: number; message?: string } | undefined;
  const rawMessage = errObj?.message ?? String(error);
  const statusCode = typeof errObj?.status === 'number' ? errObj.status : errObj?.code;
  const upper = rawMessage.toUpperCase();

  if (statusCode === 401 || statusCode === 403 || upper.includes('API_KEY_INVALID') || upper.includes('PERMISSION_DENIED')) {
    return new AdapterExecutionError({
      provider: 'gemini',
      errorType: 'auth_error',
      retryable: false,
      statusCode: statusCode ?? 403,
      message: `Falha de autenticação no provedor Gemini (${rawMessage}). Verifique GEMINI_API_KEY nas variáveis de ambiente.`,
    });
  }

  if (statusCode === 429 || upper.includes('RESOURCE_EXHAUSTED') || upper.includes('QUOTA')) {
    return new AdapterExecutionError({
      provider: 'gemini',
      errorType: 'rate_limit',
      retryable: true,
      statusCode: 429,
      message: `Limite de requisições ou cota atingida no Gemini (${rawMessage}).`,
    });
  }

  if (statusCode === 404 || upper.includes('NOT_FOUND')) {
    return new AdapterExecutionError({
      provider: 'gemini',
      errorType: 'invalid_model',
      retryable: true,
      statusCode: 404,
      message: `Modelo Gemini não encontrado ou indisponível (${rawMessage}).`,
    });
  }

  return new AdapterExecutionError({
    provider: 'gemini',
    errorType: 'upstream_error',
    retryable: true,
    statusCode,
    message: `Erro no adaptador Gemini: ${rawMessage}`,
  });
}
