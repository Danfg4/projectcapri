import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import type { ModelCapabilityTier, IntentCategory, ProviderId } from '../../core/types.ts';

interface SeedModelRow {
  id: string;
  provider: ProviderId;
  modelName: string;
  displayName: string;
  envKey: string;
  enabled: number;
  capabilityTier: ModelCapabilityTier;
  strengths: IntentCategory[];
  costPer1kInput: number;
  costPer1kOutput: number;
  avgLatencyMs: number;
  priority: number;
  rpmLimit: number;
  rpdLimit: number;
  tpdLimit: number;
  maxContextTokens: number;
  notes: string;
}

const DEFAULT_MODELS: SeedModelRow[] = [
  {
    id: 'gemini/gemini-3.1-flash-lite',
    provider: 'gemini',
    modelName: 'gemini-3.1-flash-lite',
    displayName: 'Gemini 3.1 Flash-Lite',
    envKey: 'GEMINI_API_KEY',
    enabled: 1,
    capabilityTier: 'fast_economy',
    strengths: ['general_chat', 'quick_summary', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 650,
    priority: 90,
    rpmLimit: 30,
    rpdLimit: 1500,
    tpdLimit: 1500000,
    maxContextTokens: 1000000,
    notes: 'Preço não pré-configurado: informe uma estimativa local verificada antes de estimar custos.',
  },
  {
    id: 'gemini/gemini-3.8-flash',
    provider: 'gemini',
    modelName: 'gemini-3.8-flash',
    displayName: 'Gemini 3.8 Flash',
    envKey: 'GEMINI_API_KEY',
    enabled: 1,
    capabilityTier: 'balanced',
    strengths: [
      'general_chat',
      'complex_reasoning',
      'coding',
      'research',
      'document_analysis',
      'content_generation',
      'quick_summary',
    ],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 1200,
    priority: 95,
    rpmLimit: 15,
    rpdLimit: 500,
    tpdLimit: 1000000,
    maxContextTokens: 1000000,
    notes: 'Modelo Gemini atual; preço não pré-configurado. Consulte a disponibilidade e o preço da conta.',
  },
  {
    id: 'groq/llama-3.1-8b-instant',
    provider: 'groq',
    modelName: 'llama-3.1-8b-instant',
    displayName: 'Groq Llama 3.1 8B Instant',
    envKey: 'GROQ_API_KEY',
    enabled: 1,
    capabilityTier: 'fast_economy',
    strengths: ['general_chat', 'quick_summary', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 320,
    priority: 88,
    rpmLimit: 30,
    rpdLimit: 14400,
    tpdLimit: 500000,
    maxContextTokens: 131072,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'groq/llama-3.3-70b-versatile',
    provider: 'groq',
    modelName: 'llama-3.3-70b-versatile',
    displayName: 'Groq Llama 3.3 70B Versatile',
    envKey: 'GROQ_API_KEY',
    enabled: 1,
    capabilityTier: 'balanced',
    strengths: ['coding', 'complex_reasoning', 'research', 'document_analysis', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 550,
    priority: 91,
    rpmLimit: 30,
    rpdLimit: 1000,
    tpdLimit: 100000,
    maxContextTokens: 131072,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'openai/gpt-4o-mini',
    provider: 'openai',
    modelName: 'gpt-4o-mini',
    displayName: 'OpenAI GPT-4o Mini',
    envKey: 'OPENAI_API_KEY',
    enabled: 1,
    capabilityTier: 'fast_economy',
    strengths: ['general_chat', 'quick_summary', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 800,
    priority: 82,
    rpmLimit: 60,
    rpdLimit: 2000,
    tpdLimit: 1000000,
    maxContextTokens: 128000,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'openai/gpt-4o',
    provider: 'openai',
    modelName: 'gpt-4o',
    displayName: 'OpenAI GPT-4o',
    envKey: 'OPENAI_API_KEY',
    enabled: 1,
    capabilityTier: 'deep_reasoning',
    strengths: ['complex_reasoning', 'coding', 'document_analysis', 'research'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 1700,
    priority: 87,
    rpmLimit: 30,
    rpdLimit: 500,
    tpdLimit: 500000,
    maxContextTokens: 128000,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'anthropic/claude-haiku-5-5',
    provider: 'anthropic',
    modelName: 'claude-haiku-5-5',
    displayName: 'Claude Haiku 5.5',
    envKey: 'ANTHROPIC_API_KEY',
    enabled: 1,
    capabilityTier: 'fast_economy',
    strengths: ['general_chat', 'quick_summary', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 850,
    priority: 79,
    rpmLimit: 40,
    rpdLimit: 1000,
    tpdLimit: 500000,
    maxContextTokens: 200000,
    notes: 'Adaptador Anthropic compacto e ágil. Requer ANTHROPIC_API_KEY.',
  },
  {
    id: 'anthropic/claude-opus-5-5',
    provider: 'anthropic',
    modelName: 'claude-opus-5-5',
    displayName: 'Claude Opus 5.5',
    envKey: 'ANTHROPIC_API_KEY',
    enabled: 1,
    capabilityTier: 'deep_reasoning',
    strengths: ['complex_reasoning', 'coding', 'document_analysis', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 1900,
    priority: 92,
    rpmLimit: 30,
    rpdLimit: 500,
    tpdLimit: 500000,
    maxContextTokens: 200000,
    notes: 'Adaptador Anthropic preparado para arquitetura e escrita técnica. Requer ANTHROPIC_API_KEY.',
  },
  {
    id: 'deepseek/deepseek-flash',
    provider: 'deepseek',
    modelName: 'deepseek-flash',
    displayName: 'DeepSeek Flash',
    envKey: 'DEEPSEEK_API_KEY',
    enabled: 1,
    capabilityTier: 'balanced',
    strengths: ['coding', 'general_chat', 'content_generation'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 1350,
    priority: 80,
    rpmLimit: 40,
    rpdLimit: 2000,
    tpdLimit: 1000000,
    maxContextTokens: 64000,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'deepseek/deepseek-v4-pro',
    provider: 'deepseek',
    modelName: 'deepseek-v4-pro',
    displayName: 'DeepSeek V4 Pro',
    envKey: 'DEEPSEEK_API_KEY',
    enabled: 1,
    capabilityTier: 'deep_reasoning',
    strengths: ['complex_reasoning', 'coding', 'research'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 2600,
    priority: 89,
    rpmLimit: 20,
    rpdLimit: 500,
    tpdLimit: 500000,
    maxContextTokens: 64000,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'xai/latest',
    provider: 'xai',
    modelName: 'latest',
    displayName: 'xAI Latest',
    envKey: 'XAI_API_KEY',
    enabled: 1,
    capabilityTier: 'fast_economy',
    strengths: ['general_chat', 'quick_summary', 'research'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 900,
    priority: 74,
    rpmLimit: 30,
    rpdLimit: 1000,
    tpdLimit: 500000,
    maxContextTokens: 131072,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
  {
    id: 'xai/grok-420-reasoning',
    provider: 'xai',
    modelName: 'grok-420-reasoning',
    displayName: 'xAI Grok 420 Reasoning',
    envKey: 'XAI_API_KEY',
    enabled: 1,
    capabilityTier: 'deep_reasoning',
    strengths: ['complex_reasoning', 'research', 'coding'],
    costPer1kInput: 0,
    costPer1kOutput: 0,
    avgLatencyMs: 1850,
    priority: 81,
    rpmLimit: 20,
    rpdLimit: 500,
    tpdLimit: 500000,
    maxContextTokens: 131072,
    notes: 'ID confirmado apenas após consulta ao catálogo autenticado. Preço e limites não pré-configurados.',
  },
];

export function resolveDatabasePath(customPath?: string): string {
  const configured = customPath ?? process.env.CAPRI_DB_PATH ?? './data/capri-core.db';
  if (configured === ':memory:') {
    return ':memory:';
  }
  return path.resolve(process.cwd(), configured);
}

export function createDatabase(customPath?: string): Database.Database {
  const dbPath = resolveDatabasePath(customPath);
  if (dbPath !== ':memory:') {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new Database(dbPath);
  try {
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');

    migrateSchema(db);
    migrateMemoryEngine(db);
    migrateMemoryEngineAuditR2(db);
    seedDefaultModels(db);
    migrateDefaultCatalogAndPricing(db);
    ensureDefaultSession(db);

    return db;
  } catch (error) {
    db.close();
    throw error;
  }
}

function migrateSchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS models (
      id TEXT PRIMARY KEY,
      provider TEXT NOT NULL,
      model_name TEXT NOT NULL,
      display_name TEXT NOT NULL,
      env_key TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      capability_tier TEXT NOT NULL,
      strengths_json TEXT NOT NULL,
      cost_per_1k_input REAL NOT NULL DEFAULT 0,
      cost_per_1k_output REAL NOT NULL DEFAULT 0,
      avg_latency_ms INTEGER NOT NULL DEFAULT 1000,
      priority INTEGER NOT NULL DEFAULT 50,
      rpm_limit INTEGER NOT NULL DEFAULT 30,
      rpd_limit INTEGER NOT NULL DEFAULT 1000,
      tpd_limit INTEGER NOT NULL DEFAULT 1000000,
      max_context_tokens INTEGER NOT NULL DEFAULT 128000,
      notes TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS memory_facts (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL,
      key TEXT NOT NULL,
      content TEXT NOT NULL,
      source_model TEXT,
      importance INTEGER NOT NULL DEFAULT 5,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      active_model_override TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      model_id TEXT,
      provider TEXT,
      intent TEXT,
      trace_id TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS usage_logs (
      id TEXT PRIMARY KEY,
      trace_id TEXT NOT NULL,
      session_id TEXT NOT NULL,
      model_id TEXT NOT NULL,
      provider TEXT NOT NULL,
      status TEXT NOT NULL,
      latency_ms INTEGER NOT NULL,
      input_tokens INTEGER,
      output_tokens INTEGER,
      total_tokens INTEGER,
      estimated_cost_usd REAL,
      error_code TEXT,
      error_message TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS model_cooldowns (
      model_id TEXT PRIMARY KEY,
      expires_at TEXT NOT NULL,
      reason TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS routing_traces (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      request_preview TEXT NOT NULL,
      intent TEXT NOT NULL,
      complexity TEXT NOT NULL,
      intent_confidence REAL NOT NULL,
      intent_reasoning TEXT NOT NULL,
      routing_mode TEXT NOT NULL,
      requested_model_id TEXT,
      selected_model_id TEXT,
      final_model_id TEXT,
      final_provider TEXT,
      selection_reason TEXT NOT NULL,
      candidates_json TEXT NOT NULL,
      fallback_attempts_json TEXT NOT NULL,
      memory_facts_used_count INTEGER NOT NULL DEFAULT 0,
      session_messages_used_count INTEGER NOT NULL DEFAULT 0,
      final_status TEXT NOT NULL,
      error_message TEXT,
      total_latency_ms INTEGER NOT NULL DEFAULT 0,
      input_tokens INTEGER,
      output_tokens INTEGER,
      total_tokens INTEGER,
      estimated_cost_usd REAL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_usage_model_time ON usage_logs(model_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_traces_session_time ON routing_traces(session_id, created_at);
  `);
}


/** Incremental, additive Memory Engine migration. Existing memory/session/message rows are preserved. */
function migrateMemoryEngine(db: Database.Database): void {
  const migrationVersion = 2;
  const applied = db.prepare('SELECT version FROM schema_migrations WHERE version = ?').get(migrationVersion);
  if (applied) return;

  const additions: Array<[string, string]> = [
    ['scope', "TEXT NOT NULL DEFAULT 'long_term'"],
    ['session_id', 'TEXT REFERENCES sessions(id) ON DELETE CASCADE'],
    ['source_type', "TEXT NOT NULL DEFAULT 'legacy'"],
    ['source_ref', 'TEXT'],
    ['confidence', 'REAL NOT NULL DEFAULT 0.65 CHECK (confidence >= 0 AND confidence <= 1)'],
    ['user_confirmed', 'INTEGER NOT NULL DEFAULT 0 CHECK (user_confirmed IN (0, 1))'],
    ['status', "TEXT NOT NULL DEFAULT 'active'"],
    ['valid_from', 'TEXT'],
    ['expires_at', 'TEXT'],
    ['last_accessed_at', 'TEXT'],
    ['superseded_by', 'TEXT'],
    ['sensitivity', "TEXT NOT NULL DEFAULT 'normal'"],
  ];

  const migrate = db.transaction(() => {
    // Recheck after acquiring the write lock so concurrent startups remain idempotent.
    if (db.prepare('SELECT version FROM schema_migrations WHERE version = ?').get(migrationVersion)) return;
    const columns = new Set((db.pragma('table_info(memory_facts)') as Array<{ name: string }>).map((c) => c.name));
    for (const [name, definition] of additions) {
      if (!columns.has(name)) db.exec(`ALTER TABLE memory_facts ADD COLUMN ${name} ${definition}`);
    }

    db.exec(`
      CREATE TABLE IF NOT EXISTS memory_relations (
        from_fact_id TEXT NOT NULL,
        to_fact_id TEXT NOT NULL,
        relation_type TEXT NOT NULL CHECK (relation_type IN ('related_to', 'contradicts', 'supersedes', 'derived_from')),
        created_at TEXT NOT NULL,
        PRIMARY KEY (from_fact_id, to_fact_id, relation_type),
        CHECK (from_fact_id <> to_fact_id),
        FOREIGN KEY (from_fact_id) REFERENCES memory_facts(id) ON DELETE CASCADE,
        FOREIGN KEY (to_fact_id) REFERENCES memory_facts(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS memory_events (
        id TEXT PRIMARY KEY,
        memory_fact_id TEXT NOT NULL,
        event_type TEXT NOT NULL CHECK (event_type IN ('created', 'updated', 'confirmed', 'conflict_detected', 'superseded', 'deactivated', 'reactivated')),
        old_value_json TEXT,
        new_value_json TEXT,
        actor_type TEXT NOT NULL DEFAULT 'system',
        actor_id TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (memory_fact_id) REFERENCES memory_facts(id) ON DELETE CASCADE
      );

      CREATE INDEX IF NOT EXISTS idx_memory_scope_status ON memory_facts(scope, status, active);
      CREATE INDEX IF NOT EXISTS idx_memory_session_scope ON memory_facts(session_id, scope, status);
      CREATE INDEX IF NOT EXISTS idx_memory_expiry ON memory_facts(expires_at);
      CREATE INDEX IF NOT EXISTS idx_memory_category_importance ON memory_facts(category, importance DESC, updated_at DESC);
      CREATE INDEX IF NOT EXISTS idx_memory_relations_to ON memory_relations(to_fact_id, relation_type);
      CREATE INDEX IF NOT EXISTS idx_memory_events_fact_time ON memory_events(memory_fact_id, created_at DESC);
    `);

    // Legacy facts remain available, but are explicitly marked as unverified legacy provenance.
    db.prepare(`UPDATE memory_facts
      SET scope = COALESCE(scope, 'long_term'),
          source_type = COALESCE(source_type, 'legacy'),
          confidence = COALESCE(confidence, 0.65),
          user_confirmed = COALESCE(user_confirmed, 0),
          status = COALESCE(status, 'active'),
          sensitivity = COALESCE(sensitivity, 'normal')`).run();

    db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)')
      .run(migrationVersion, 'add-central-memory-engine-metadata-relations-and-event-history', new Date().toISOString());
  });
  migrate.immediate();
}

function migrateDefaultCatalogAndPricing(db: Database.Database): void {
  const migrationVersion = 1;
  const applied = db.prepare('SELECT version FROM schema_migrations WHERE version = ?').get(migrationVersion);
  if (applied) return;

  const renameModel = db.prepare(`
    UPDATE models
    SET id = ?, model_name = ?, display_name = ?, notes = ?,
        cost_per_1k_input = 0, cost_per_1k_output = 0, updated_at = ?
    WHERE id = ?
  `);
  const now = new Date().toISOString();
  const renames: Array<[string, string, string, string, string]> = [
    ['gemini/gemini-3.8-flash', 'gemini-3.8-flash', 'Gemini 3.8 Flash', 'Modelo presente no catálogo público atual; disponibilidade da conta será verificada por API.', 'gemini/gemini-4-hydrogen'],
    ['anthropic/claude-haiku-5-5', 'claude-haiku-5-5', 'Claude Haiku 5.5', 'ID atual; disponibilidade da conta será verificada por API.', 'anthropic/claude-3-5-haiku-latest'],
    ['anthropic/claude-opus-5-5', 'claude-opus-5-5', 'Claude Opus 5.5', 'ID atual; disponibilidade da conta será verificada por API.', 'anthropic/claude-3-7-sonnet-latest'],
    ['deepseek/deepseek-flash', 'deepseek-flash', 'DeepSeek Flash', 'ID atual; disponibilidade da conta será verificada por API.', 'deepseek/deepseek-chat'],
    ['deepseek/deepseek-v4-pro', 'deepseek-v4-pro', 'DeepSeek V4 Pro', 'ID atual; disponibilidade da conta será verificada por API.', 'deepseek/deepseek-reasoner'],
    ['xai/latest', 'latest', 'xAI Latest', 'ID listado na documentação da API xAI; disponibilidade da conta será verificada por API.', 'xai/grok-3-mini'],
    ['xai/grok-420-reasoning', 'grok-420-reasoning', 'xAI Grok 420 Reasoning', 'ID listado na documentação da API xAI; disponibilidade da conta será verificada por API.', 'xai/grok-3'],
  ];

  const migrate = db.transaction(() => {
    for (const [newId, modelName, displayName, notes, oldId] of renames) {
      const existingNew = db.prepare('SELECT id FROM models WHERE id = ?').get(newId);
      const existingOld = db.prepare('SELECT id FROM models WHERE id = ?').get(oldId);
      if (!existingNew && existingOld) {
        renameModel.run(newId, modelName, displayName, notes, now, oldId);
        db.prepare('UPDATE sessions SET active_model_override = ? WHERE active_model_override = ?').run(newId, oldId);
      } else if (existingNew && existingOld) {
        db.prepare('UPDATE models SET enabled = 0, notes = ?, updated_at = ? WHERE id = ?').run(
          'ID legado substituído; desativado pela migração Capri Core v3.', now, oldId,
        );
        db.prepare('UPDATE sessions SET active_model_override = ? WHERE active_model_override = ?').run(newId, oldId);
      }
    }

    const defaultIds = DEFAULT_MODELS.map((model) => model.id);
    const placeholders = defaultIds.map(() => '?').join(',');
    db.prepare(`UPDATE models SET cost_per_1k_input = 0, cost_per_1k_output = 0 WHERE id IN (${placeholders})`).run(...defaultIds);
    db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)').run(
      migrationVersion,
      'refresh-default-model-ids-and-clear-unverified-seed-prices',
      now,
    );
  });
  migrate();
}

function seedDefaultModels(db: Database.Database): void {
  const countRow = db.prepare('SELECT COUNT(*) as count FROM models').get() as { count: number };
  if (countRow.count > 0) {
    return;
  }

  const now = new Date().toISOString();
  const insert = db.prepare(`
    INSERT INTO models (
      id, provider, model_name, display_name, env_key, enabled, capability_tier,
      strengths_json, cost_per_1k_input, cost_per_1k_output, avg_latency_ms,
      priority, rpm_limit, rpd_limit, tpd_limit, max_context_tokens, notes, updated_at
    ) VALUES (
      @id, @provider, @modelName, @displayName, @envKey, @enabled, @capabilityTier,
      @strengthsJson, @costPer1kInput, @costPer1kOutput, @avgLatencyMs,
      @priority, @rpmLimit, @rpdLimit, @tpdLimit, @maxContextTokens, @notes, @updatedAt
    )
  `);

  const insertMany = db.transaction((rows: SeedModelRow[]) => {
    for (const row of rows) {
      insert.run({
        id: row.id,
        provider: row.provider,
        modelName: row.modelName,
        displayName: row.displayName,
        envKey: row.envKey,
        enabled: row.enabled,
        capabilityTier: row.capabilityTier,
        strengthsJson: JSON.stringify(row.strengths),
        costPer1kInput: row.costPer1kInput,
        costPer1kOutput: row.costPer1kOutput,
        avgLatencyMs: row.avgLatencyMs,
        priority: row.priority,
        rpmLimit: row.rpmLimit,
        rpdLimit: row.rpdLimit,
        tpdLimit: row.tpdLimit,
        maxContextTokens: row.maxContextTokens,
        notes: row.notes,
        updatedAt: now,
      });
    }
  });

  insertMany(DEFAULT_MODELS);
}

function ensureDefaultSession(db: Database.Database): void {
  const existing = db.prepare('SELECT COUNT(*) as count FROM sessions').get() as { count: number };
  if (existing.count > 0) {
    return;
  }
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO sessions (id, title, active_model_override, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?)
  `).run('session-principal', 'Sessão Principal — Capri Core', null, now, now);
}


/** Additive audit-r2 event vocabulary migration; existing event rows are copied verbatim. */
function migrateMemoryEngineAuditR2(db: Database.Database): void {
  const migrationVersion = 3;
  if (db.prepare('SELECT version FROM schema_migrations WHERE version = ?').get(migrationVersion)) return;
  const migrate = db.transaction(() => {
    if (db.prepare('SELECT version FROM schema_migrations WHERE version = ?').get(migrationVersion)) return;
    db.exec(`
      CREATE TABLE memory_events_audit_r2 (
        id TEXT PRIMARY KEY,
        memory_fact_id TEXT NOT NULL,
        event_type TEXT NOT NULL CHECK (event_type IN (
          'created', 'updated', 'confirmed', 'conflict_detected', 'superseded',
          'deactivated', 'reactivated', 'proposal_rejected', 'sensitivity_changed'
        )),
        old_value_json TEXT,
        new_value_json TEXT,
        actor_type TEXT NOT NULL DEFAULT 'system',
        actor_id TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (memory_fact_id) REFERENCES memory_facts(id) ON DELETE CASCADE
      );
      INSERT INTO memory_events_audit_r2
        (id, memory_fact_id, event_type, old_value_json, new_value_json, actor_type, actor_id, created_at)
        SELECT id, memory_fact_id, event_type, old_value_json, new_value_json, actor_type, actor_id, created_at
        FROM memory_events;
      DROP TABLE memory_events;
      ALTER TABLE memory_events_audit_r2 RENAME TO memory_events;
      CREATE INDEX IF NOT EXISTS idx_memory_events_fact_time ON memory_events(memory_fact_id, created_at DESC);
    `);
    db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)')
      .run(migrationVersion, 'memory-engine-audit-r2-rejection-and-sensitivity-events', new Date().toISOString());
  });
  migrate.immediate();
}
