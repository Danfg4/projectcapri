import type Database from 'better-sqlite3';
import type {
  IntentCategory,
  ModelAvailabilityStatus,
  ModelCapabilityTier,
  ModelDefinition,
  ModelWithStatus,
  ProviderId,
  ProviderSummary,
} from '../../core/types.ts';
import type { ProviderAdapter } from '../adapters/base.ts';
import { PROVIDER_META } from '../adapters/index.ts';
import type { QuotaController } from './quota-controller.ts';
import { AdapterExecutionError } from '../adapters/base.ts';

interface VerificationEntry {
  status: 'available' | 'invalid_model' | 'unverified';
  reason: string;
  expiresAt: number;
}


export class ModelRegistry {
  private readonly db: Database.Database;
  private readonly adapters: Record<ProviderId, ProviderAdapter>;
  private readonly quotaController: QuotaController;
  private readonly verificationCache = new Map<string, VerificationEntry>();
  private readonly catalogRequests = new Map<string, Promise<string[]>>();
  private readonly verificationTtlMs = 5 * 60_000;

  constructor(
    db: Database.Database,
    adapters: Record<ProviderId, ProviderAdapter>,
    quotaController: QuotaController,
  ) {
    this.db = db;
    this.adapters = adapters;
    this.quotaController = quotaController;
  }

  async refreshAvailability(force = false): Promise<void> {
    const rows = this.db.prepare('SELECT * FROM models WHERE enabled = 1').all() as Array<Record<string, unknown>>;
    const groups = new Map<string, { provider: ProviderId; envKey: string; modelNames: Set<string> }>();
    const now = Date.now();

    for (const row of rows) {
      const model = this.mapRow(row);
      const adapter = this.adapters[model.provider];
      if (!adapter?.isConfigured(model)) continue;
      const cacheKey = `${model.provider}:${model.envKey}`;
      const cached = this.verificationCache.get(model.id);
      if (!force && cached && cached.expiresAt > now) continue;
      const group = groups.get(cacheKey) ?? { provider: model.provider, envKey: model.envKey, modelNames: new Set<string>() };
      group.modelNames.add(model.modelName);
      groups.set(cacheKey, group);
    }

    await Promise.all([...groups.values()].map(async (group) => {
      const adapter = this.adapters[group.provider];
      const modelRows = rows.map((row) => this.mapRow(row)).filter((model) => model.provider === group.provider && model.envKey === group.envKey && group.modelNames.has(model.modelName));
      try {
        let catalogRequest = this.catalogRequests.get(`${group.provider}:${group.envKey}`);
        if (!catalogRequest) {
          catalogRequest = adapter.listModels(group.envKey);
          this.catalogRequests.set(`${group.provider}:${group.envKey}`, catalogRequest);
        }
        let modelNames: string[];
        try {
          modelNames = await catalogRequest;
        } finally {
          if (this.catalogRequests.get(`${group.provider}:${group.envKey}`) === catalogRequest) {
            this.catalogRequests.delete(`${group.provider}:${group.envKey}`);
          }
        }
        const exposedModels = new Set(modelNames);
        for (const model of modelRows) {
          const available = exposedModels.has(model.modelName);
          this.verificationCache.set(model.id, {
            status: available ? 'available' : 'invalid_model',
            reason: available
              ? `ID confirmado no catálogo autenticado de ${model.provider}.`
              : `ID ${model.modelName} não consta no catálogo retornado pela credencial ${group.envKey}.`,
            expiresAt: now + this.verificationTtlMs,
          });
        }
      } catch (error) {
        const reason = error instanceof AdapterExecutionError
          ? error.message
          : `Não foi possível verificar o catálogo de ${group.provider}: ${error instanceof Error ? error.message : String(error)}`;
        for (const model of modelRows) {
          this.verificationCache.set(model.id, { status: 'unverified', reason, expiresAt: now + 30_000 });
        }
      }
    }));
  }

  markInvalidModel(modelId: string, reason: string): void {
    this.verificationCache.set(modelId, {
      status: 'invalid_model',
      reason,
      expiresAt: Date.now() + 10 * 60_000,
    });
  }

  listModels(): ModelWithStatus[] {
    const rows = this.db
      .prepare(`SELECT * FROM models ORDER BY priority DESC, provider ASC, display_name ASC`)
      .all() as Array<Record<string, unknown>>;

    return rows.map((row) => this.enrichModel(this.mapRow(row)));
  }

  getModelById(id: string): ModelWithStatus | null {
    const row = this.db
      .prepare(`SELECT * FROM models WHERE id = ?`)
      .get(id) as Record<string, unknown> | undefined;
    return row ? this.enrichModel(this.mapRow(row)) : null;
  }

  registerModel(input: {
    id?: string;
    provider: ProviderId;
    modelName: string;
    displayName: string;
    envKey?: string;
    enabled?: boolean;
    capabilityTier: ModelCapabilityTier;
    strengths: IntentCategory[];
    costPer1kInput?: number;
    costPer1kOutput?: number;
    avgLatencyMs?: number;
    priority?: number;
    rpmLimit?: number;
    rpdLimit?: number;
    tpdLimit?: number;
    maxContextTokens?: number;
    notes?: string;
  }): ModelWithStatus {
    const id = (input.id ?? `${input.provider}/${input.modelName}`).trim();
    const envKey = input.envKey?.trim() || PROVIDER_META[input.provider].envKey;
    const now = new Date().toISOString();

    this.db
      .prepare(
        `INSERT INTO models (
          id, provider, model_name, display_name, env_key, enabled, capability_tier,
          strengths_json, cost_per_1k_input, cost_per_1k_output, avg_latency_ms,
          priority, rpm_limit, rpd_limit, tpd_limit, max_context_tokens, notes, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        id,
        input.provider,
        input.modelName.trim(),
        input.displayName.trim(),
        envKey,
        input.enabled === false ? 0 : 1,
        input.capabilityTier,
        JSON.stringify(input.strengths),
        input.costPer1kInput ?? 0,
        input.costPer1kOutput ?? 0,
        input.avgLatencyMs ?? 1200,
        input.priority ?? 70,
        input.rpmLimit ?? 30,
        input.rpdLimit ?? 1000,
        input.tpdLimit ?? 500000,
        input.maxContextTokens ?? 128000,
        input.notes ?? '',
        now,
      );

    const created = this.getModelById(id);
    if (!created) {
      throw new Error(`Falha ao carregar modelo registrado ${id}`);
    }
    return created;
  }

  updateModel(
    id: string,
    patch: Partial<{
      enabled: boolean;
      priority: number;
      rpmLimit: number;
      rpdLimit: number;
      tpdLimit: number;
      capabilityTier: ModelCapabilityTier;
      strengths: IntentCategory[];
      notes: string;
    }>,
  ): ModelWithStatus | null {
    const existing = this.getModelById(id);
    if (!existing) return null;

    const now = new Date().toISOString();
    this.db
      .prepare(
        `UPDATE models SET
          enabled = ?,
          priority = ?,
          rpm_limit = ?,
          rpd_limit = ?,
          tpd_limit = ?,
          capability_tier = ?,
          strengths_json = ?,
          notes = ?,
          updated_at = ?
         WHERE id = ?`,
      )
      .run(
        patch.enabled === undefined ? (existing.enabled ? 1 : 0) : patch.enabled ? 1 : 0,
        patch.priority ?? existing.priority,
        patch.rpmLimit ?? existing.rpmLimit,
        patch.rpdLimit ?? existing.rpdLimit,
        patch.tpdLimit ?? existing.tpdLimit,
        patch.capabilityTier ?? existing.capabilityTier,
        JSON.stringify(patch.strengths ?? existing.strengths),
        patch.notes ?? existing.notes,
        now,
        id,
      );

    return this.getModelById(id);
  }

  getProviderSummaries(): ProviderSummary[] {
    const models = this.listModels();
    const providers = Object.keys(PROVIDER_META) as ProviderId[];

    return providers.map((provider) => {
      const meta = PROVIDER_META[provider];
      const providerModels = models.filter((m) => m.provider === provider);
      const configured = providerModels.some((m) => m.envConfigured) || Boolean(process.env[meta.envKey]?.trim());
      const availableModels = providerModels.filter((m) => m.availability === 'available').length;
      const requestsToday = providerModels.reduce((acc, m) => acc + m.quota.requestsToday, 0);
      const tokensToday = providerModels.reduce((acc, m) => acc + m.quota.tokensToday, 0);

      return {
        provider,
        label: meta.label,
        envKey: meta.envKey,
        configured,
        totalModels: providerModels.length,
        availableModels,
        requestsToday,
        tokensToday,
      };
    });
  }

  private enrichModel(model: ModelDefinition): ModelWithStatus {
    const adapter = this.adapters[model.provider];
    const envConfigured = Boolean(adapter && adapter.isConfigured(model));
    const quota = this.quotaController.getQuotaUsage(model);
    const observedLatencyMs = this.quotaController.getObservedAverageLatencyMs(model.id);

    let availability: ModelAvailabilityStatus = 'available';
    let availabilityReason = 'Pronto para roteamento e execução real.';

    const verification = this.verificationCache.get(model.id);
    if (!model.enabled) {
      availability = 'disabled';
      availabilityReason = 'Desativado manualmente no Model Registry.';
    } else if (!envConfigured) {
      availability = 'not_configured';
      availabilityReason = `Aguardando variável de ambiente ${model.envKey} no servidor.`;
    } else if (!verification || verification.expiresAt <= Date.now() || verification.status === 'unverified') {
      availability = 'unverified';
      availabilityReason = verification?.reason ?? 'Aguardando confirmação do ID no catálogo autenticado do provedor.';
    } else if (verification.status === 'invalid_model') {
      availability = 'invalid_model';
      availabilityReason = verification.reason;
    } else if (quota.cooldownUntil) {
      availability = 'cooldown';
      availabilityReason = `Em pausa temporária (${this.quotaController.getCooldownReason(model.id) ?? 'cooldown'}) até ${quota.cooldownUntil}.`;
    } else if (quota.rpmRemaining <= 0) {
      availability = 'quota_exhausted';
      availabilityReason = `Limite local configurado de ${model.rpmLimit} req/min atingido (não é cota oficial do provedor).`;
    } else if (quota.rpdRemaining <= 0) {
      availability = 'quota_exhausted';
      availabilityReason = `Limite local configurado de ${model.rpdLimit} requisições/dia atingido (não é cota oficial do provedor).`;
    } else if (quota.tpdRemaining <= 0) {
      availability = 'quota_exhausted';
      availabilityReason = `Limite local configurado de ${model.tpdLimit.toLocaleString('pt-BR')} tokens/dia atingido (não é cota oficial do provedor).`;
    }

    return {
      ...model,
      avgLatencyMs: observedLatencyMs ?? model.avgLatencyMs,
      envConfigured,
      availability,
      availabilityReason,
      quota,
    };
  }

  private mapRow(row: Record<string, unknown>): ModelDefinition {
    return {
      id: String(row.id),
      provider: row.provider as ProviderId,
      modelName: String(row.model_name),
      displayName: String(row.display_name),
      envKey: String(row.env_key),
      enabled: Number(row.enabled) === 1,
      capabilityTier: row.capability_tier as ModelCapabilityTier,
      strengths: JSON.parse(String(row.strengths_json)) as IntentCategory[],
      costPer1kInput: Number(row.cost_per_1k_input),
      costPer1kOutput: Number(row.cost_per_1k_output),
      avgLatencyMs: Number(row.avg_latency_ms),
      priority: Number(row.priority),
      rpmLimit: Number(row.rpm_limit),
      rpdLimit: Number(row.rpd_limit),
      tpdLimit: Number(row.tpd_limit),
      maxContextTokens: Number(row.max_context_tokens),
      notes: String(row.notes ?? ''),
      updatedAt: String(row.updated_at),
    };
  }
}
