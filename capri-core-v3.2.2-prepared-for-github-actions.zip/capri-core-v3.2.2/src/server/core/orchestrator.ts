import type Database from 'better-sqlite3';
import crypto from 'node:crypto';
import type {
  FallbackAttempt,
  ModelWithStatus,
  OrchestrationRequest,
  OrchestrationResponse,
  RoutingMode,
  RoutingTrace,
} from '../../core/types.ts';
import { AdapterExecutionError, type ProviderAdapter } from '../adapters/base.ts';
import type { ProviderId } from '../../core/types.ts';
import { IntentClassifier } from './intent-classifier.ts';
import { ModelRegistry } from './model-registry.ts';
import { QuotaController } from './quota-controller.ts';
import { MemoryEngine } from './memory-engine.ts';
import { SmartRouter } from './smart-router.ts';

export class CapriCoreOrchestrator {
  readonly db: Database.Database;
  readonly adapters: Record<ProviderId, ProviderAdapter>;
  readonly intentClassifier: IntentClassifier;
  readonly quotaController: QuotaController;
  readonly modelRegistry: ModelRegistry;
  readonly memoryEngine: MemoryEngine;
  /** Backward-compatible alias retained for existing API consumers. */
  readonly sharedMemory: MemoryEngine;
  readonly smartRouter: SmartRouter;

  constructor(params: {
    db: Database.Database;
    adapters: Record<ProviderId, ProviderAdapter>;
  }) {
    this.db = params.db;
    this.adapters = params.adapters;
    this.intentClassifier = new IntentClassifier();
    this.quotaController = new QuotaController(params.db);
    this.modelRegistry = new ModelRegistry(params.db, params.adapters, this.quotaController);
    this.memoryEngine = new MemoryEngine(params.db);
    this.sharedMemory = this.memoryEngine;
    this.smartRouter = new SmartRouter();
  }

  async orchestrate(request: OrchestrationRequest): Promise<OrchestrationResponse> {
    const cleanPrompt = request.prompt?.trim();
    if (!cleanPrompt) {
      throw new Error('O campo "prompt" não pode estar vazio.');
    }

    const session = this.sharedMemory.ensureSession(request.sessionId);
    const traceId = `trc_${crypto.randomUUID()}`;
    const createdAt = new Date().toISOString();

    // 1. Classificação de intenção pré-roteamento
    const classification = this.intentClassifier.classify(cleanPrompt);

    // 2. Extração explícita de memória compartilhada se solicitada pelo usuário
    const extractedMemories =
      request.saveMemory === false
        ? []
        : this.sharedMemory.extractExplicitMemoryDirectives(cleanPrompt, null);

    // Refresh the registry before budgeting: the router must not be constrained by a fixed 8k pre-budget.
    await this.modelRegistry.refreshAvailability();
    const allModels = this.modelRegistry.listModels();
    const estimatedContextTokens = this.memoryEngine.estimateMandatoryContextTokens(request.systemPrompt, cleanPrompt);

    // 5. Determinar modo de roteamento respeitando preferência manual do usuário
    const effectiveRequestedModelId =
      request.requestedModelId?.trim() || session.activeModelOverride || null;
    const routingMode: RoutingMode =
      request.routingMode === 'manual' || (effectiveRequestedModelId && request.routingMode !== 'auto')
        ? 'manual'
        : 'auto';

    // 6. Consultar estado real dos modelos no Model Registry e decidir rota
    const decision = this.smartRouter.route({
      classification,
      models: allModels,
      routingMode,
      requestedModelId: effectiveRequestedModelId,
      allowFallbackOnManual: request.allowFallbackOnManual,
      maxFallbackAttempts: request.maxFallbackAttempts,
      estimatedContextTokens,
    });

    if (!decision.ok || !decision.primaryModel) {
      const availableCandidates = decision.candidates.filter((candidate) => candidate.availability === 'available');
      const blockedForContext = availableCandidates.length > 0 && availableCandidates.every((candidate) => !candidate.eligible);
      const blockedOmissionNote = blockedForContext
        ? ' Contexto não montado: nenhum modelo disponível comporta a instrução de sistema e a mensagem atual dentro da reserva de resposta.'
        : '';
      const userMessage = this.sharedMemory.addMessage({
        sessionId: session.id, role: 'user', content: cleanPrompt, intent: classification.intent, traceId,
      });
      const blockedTrace: RoutingTrace = {
        id: traceId,
        sessionId: session.id,
        requestPreview: cleanPrompt.slice(0, 140),
        intent: classification.intent,
        complexity: classification.complexity,
        intentConfidence: classification.confidence,
        intentReasoning: classification.reasoning,
        routingMode,
        requestedModelId: effectiveRequestedModelId,
        selectedModelId: null,
        finalModelId: null,
        finalProvider: null,
        selectionReason: `${decision.selectionReason}${blockedOmissionNote}`,
        candidates: decision.candidates,
        fallbackAttempts: [],
        memoryFactsUsedCount: 0,
        sessionMessagesUsedCount: 0,
        finalStatus: 'blocked',
        errorMessage: decision.blockedMessage ?? decision.selectionReason,
        totalLatencyMs: 0,
        inputTokens: null,
        outputTokens: null,
        totalTokens: null,
        estimatedCostUsd: null,
        createdAt,
      };

      this.quotaController.saveTrace(blockedTrace);

      return {
        ok: false,
        sessionId: session.id,
        answer: null,
        trace: blockedTrace,
        userMessage,
        assistantMessage: null,
        extractedMemories,
        error: {
          code: 'NO_COMPATIBLE_MODEL_AVAILABLE',
          message: decision.blockedMessage ?? decision.selectionReason,
          limitation: decision.selectionReason,
        },
      };
    }

    // 7. Executar com fallback controlado usando um único contexto compatível com toda a fila.
    const executionQueue: ModelWithStatus[] = [decision.primaryModel, ...decision.fallbackChain];
    const fallbackSafeContextLimit = Math.min(...executionQueue.map((model) => model.maxContextTokens));
    const portableContext = this.memoryEngine.buildPortableContext(
      session.id, request.systemPrompt, cleanPrompt, { maxContextTokens: fallbackSafeContextLimit },
    );
    const contextOmissionNote = portableContext.omittedMemoryCount || portableContext.omittedHistoryCount
      ? ` Contexto reduzido por orçamento: ${portableContext.omittedMemoryCount} memórias e ${portableContext.omittedHistoryCount} mensagens omitidas; estimativa conservadora, não tokenizer exato.`
      : '';
    const userMessage = this.sharedMemory.addMessage({
      sessionId: session.id, role: 'user', content: cleanPrompt, intent: classification.intent, traceId,
    });
    const attempts: FallbackAttempt[] = [];
    const totalStart = Date.now();

    for (let index = 0; index < executionQueue.length; index++) {
      const candidateModel = executionQueue[index];
      const adapter = this.adapters[candidateModel.provider];

      if (!adapter) {
        attempts.push({
          attempt: index + 1,
          modelId: candidateModel.id,
          displayName: candidateModel.displayName,
          provider: candidateModel.provider,
          status: 'failed',
          errorType: 'upstream_error',
          errorMessage: `Adaptador não encontrado para ${candidateModel.provider}.`,
          latencyMs: 0,
        });
        continue;
      }

      const attemptStart = Date.now();
      try {
        const result = await adapter.execute({
          model: candidateModel,
          prompt: cleanPrompt,
          systemInstruction: portableContext.systemInstruction,
          history: portableContext.history,
          intent: classification.intent,
          complexity: classification.complexity,
          maxOutputTokens: portableContext.reservedOutputTokens,
        });

        const latencyMs = result.latencyMs || Date.now() - attemptStart;
        attempts.push({
          attempt: index + 1,
          modelId: candidateModel.id,
          displayName: candidateModel.displayName,
          provider: candidateModel.provider,
          status: 'success',
          latencyMs,
        });

        const usageEntry = this.quotaController.recordUsage({
          traceId,
          sessionId: session.id,
          model: candidateModel,
          status: 'success',
          latencyMs,
          inputTokens: result.inputTokens,
          outputTokens: result.outputTokens,
          totalTokens: result.totalTokens,
        });

        const assistantMessage = this.sharedMemory.addMessage({
          sessionId: session.id,
          role: 'assistant',
          content: result.text,
          modelId: candidateModel.id,
          provider: candidateModel.provider,
          intent: classification.intent,
          traceId,
        });

        const fallbackUsed = index > 0;
        const previousFailures = attempts
          .filter((attempt) => attempt.status === 'failed')
          .map((attempt) => `${attempt.provider}/${attempt.modelId}: ${attempt.errorType ?? 'erro'} (${attempt.errorMessage ?? 'sem detalhe'})`)
          .join('; ');
        const finalSelectionReason = fallbackUsed
          ? `${decision.selectionReason} Fallback entre provedores acionado após ${previousFailures}; atendido com o mesmo contexto por ${candidateModel.displayName}.${contextOmissionNote}`
          : `${decision.selectionReason}${contextOmissionNote}`;

        const completedTrace: RoutingTrace = {
          id: traceId,
          sessionId: session.id,
          requestPreview: cleanPrompt.slice(0, 140),
          intent: classification.intent,
          complexity: classification.complexity,
          intentConfidence: classification.confidence,
          intentReasoning: classification.reasoning,
          routingMode,
          requestedModelId: effectiveRequestedModelId,
          selectedModelId: decision.primaryModel.id,
          finalModelId: candidateModel.id,
          finalProvider: candidateModel.provider,
          selectionReason: finalSelectionReason,
          candidates: decision.candidates,
          fallbackAttempts: attempts,
          memoryFactsUsedCount: portableContext.factsCount,
          sessionMessagesUsedCount: portableContext.messagesCount,
          finalStatus: 'completed',
          errorMessage: null,
          totalLatencyMs: Date.now() - totalStart,
          inputTokens: result.inputTokens,
          outputTokens: result.outputTokens,
          totalTokens: result.totalTokens,
          estimatedCostUsd: usageEntry.estimatedCostUsd,
          createdAt,
        };

        this.quotaController.saveTrace(completedTrace);

        return {
          ok: true,
          sessionId: session.id,
          answer: result.text,
          trace: completedTrace,
          userMessage,
          assistantMessage,
          extractedMemories,
        };
      } catch (err) {
        const latencyMs = Date.now() - attemptStart;
        const normalized =
          err instanceof AdapterExecutionError
            ? err
            : new AdapterExecutionError({
                provider: candidateModel.provider,
                errorType: 'upstream_error',
                retryable: true,
                message: err instanceof Error ? err.message : String(err),
              });

        attempts.push({
          attempt: index + 1,
          modelId: candidateModel.id,
          displayName: candidateModel.displayName,
          provider: candidateModel.provider,
          status: 'failed',
          errorType: normalized.errorType,
          errorMessage: normalized.message,
          latencyMs,
        });

        this.quotaController.recordUsage({
          traceId,
          sessionId: session.id,
          model: candidateModel,
          status: 'error',
          latencyMs,
          inputTokens: null,
          outputTokens: null,
          totalTokens: null,
          errorCode: normalized.errorType,
          errorMessage: normalized.message,
        });

        if (normalized.errorType === 'rate_limit') {
          this.quotaController.setCooldown(candidateModel.id, 60_000, 'rate_limit');
        } else if (normalized.errorType === 'auth_error') {
          this.quotaController.setCooldown(candidateModel.id, 5 * 60_000, 'auth_error');
        } else if (normalized.errorType === 'invalid_model') {
          this.modelRegistry.markInvalidModel(candidateModel.id, normalized.message);
        }

        // Não contorna erros não-retentáveis de autenticação ou chave ausente se for seleção manual estrita
        if (!normalized.retryable && routingMode === 'manual' && !request.allowFallbackOnManual) {
          break;
        }
      }
    }

    const lastFailure = attempts[attempts.length - 1];
    const errorMsg =
      lastFailure?.errorMessage ??
      'Todos os modelos compatíveis falharam durante a execução.';

    const failedTrace: RoutingTrace = {
      id: traceId,
      sessionId: session.id,
      requestPreview: cleanPrompt.slice(0, 140),
      intent: classification.intent,
      complexity: classification.complexity,
      intentConfidence: classification.confidence,
      intentReasoning: classification.reasoning,
      routingMode,
      requestedModelId: effectiveRequestedModelId,
      selectedModelId: decision.primaryModel.id,
      finalModelId: null,
      finalProvider: null,
      selectionReason: attempts.reduce((reason, attempt) => {
        if (attempt.status !== 'failed') return reason;
        return `${reason} Tentativa ${attempt.attempt} em ${attempt.provider}/${attempt.modelId} falhou (${attempt.errorType ?? 'erro'}): ${attempt.errorMessage ?? 'sem detalhe'}.`;
      }, decision.selectionReason),
      candidates: decision.candidates,
      fallbackAttempts: attempts,
      memoryFactsUsedCount: portableContext.factsCount,
      sessionMessagesUsedCount: portableContext.messagesCount,
      finalStatus: 'failed',
      errorMessage: errorMsg,
      totalLatencyMs: Date.now() - totalStart,
      inputTokens: null,
      outputTokens: null,
      totalTokens: null,
      estimatedCostUsd: null,
      createdAt,
    };

    this.quotaController.saveTrace(failedTrace);

    return {
      ok: false,
      sessionId: session.id,
      answer: null,
      trace: failedTrace,
      userMessage,
      assistantMessage: null,
      extractedMemories,
      error: {
        code: lastFailure?.errorType?.toUpperCase() ?? 'ORCHESTRATION_FAILED',
        message: errorMsg,
        limitation: `Tentativas esgotadas (${attempts.length}/${executionQueue.length}) sem mascarar erro upstream.`,
      },
    };
  }
}
