import type Database from 'better-sqlite3';
import crypto from 'node:crypto';
import type {
  ModelDefinition,
  ModelQuotaUsage,
  ProviderId,
  RoutingTrace,
  UsageLogEntry,
  UsageSummary,
} from '../../core/types.ts';

export class QuotaController {
  private readonly db: Database.Database;

  constructor(db: Database.Database) {
    this.db = db;
  }

  setCooldown(modelId: string, durationMs = 60_000, reason = 'rate_limit'): void {
    const now = new Date().toISOString();
    const expiresAt = new Date(Date.now() + Math.max(0, durationMs)).toISOString();
    this.db.prepare(`
      INSERT INTO model_cooldowns (model_id, expires_at, reason, updated_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(model_id) DO UPDATE SET
        expires_at = excluded.expires_at,
        reason = excluded.reason,
        updated_at = excluded.updated_at
    `).run(modelId, expiresAt, reason, now);
  }

  clearCooldown(modelId: string): void {
    this.db.prepare('DELETE FROM model_cooldowns WHERE model_id = ?').run(modelId);
  }

  getCooldownReason(modelId: string): string | null {
    const row = this.db.prepare('SELECT reason FROM model_cooldowns WHERE model_id = ?').get(modelId) as { reason: string } | undefined;
    return row?.reason ?? null;
  }

  getCooldownUntil(modelId: string): string | null {
    const row = this.db.prepare('SELECT expires_at FROM model_cooldowns WHERE model_id = ?').get(modelId) as { expires_at: string } | undefined;
    if (!row) return null;
    if (Date.parse(row.expires_at) <= Date.now()) {
      this.clearCooldown(modelId);
      return null;
    }
    return row.expires_at;
  }

  getQuotaUsage(model: ModelDefinition): ModelQuotaUsage {
    const now = Date.now();
    const oneMinuteAgo = new Date(now - 60_000).toISOString();
    const startOfDay = new Date();
    startOfDay.setUTCHours(0, 0, 0, 0);
    const startOfDayIso = startOfDay.toISOString();

    const rpmRow = this.db
      .prepare(
        `SELECT COUNT(*) as cnt FROM usage_logs WHERE model_id = ? AND created_at >= ?`,
      )
      .get(model.id, oneMinuteAgo) as { cnt: number };

    const dailyRow = this.db
      .prepare(
        `SELECT COUNT(*) as reqs, COALESCE(SUM(total_tokens), 0) as toks
         FROM usage_logs
         WHERE model_id = ? AND created_at >= ?`,
      )
      .get(model.id, startOfDayIso) as { reqs: number; toks: number };

    const requestsLastMinute = rpmRow?.cnt ?? 0;
    const requestsToday = dailyRow?.reqs ?? 0;
    const tokensToday = dailyRow?.toks ?? 0;

    return {
      requestsLastMinute,
      requestsToday,
      tokensToday,
      rpmRemaining: Math.max(0, model.rpmLimit - requestsLastMinute),
      rpdRemaining: Math.max(0, model.rpdLimit - requestsToday),
      tpdRemaining: Math.max(0, model.tpdLimit - tokensToday),
      cooldownUntil: this.getCooldownUntil(model.id),
    };
  }

  getObservedAverageLatencyMs(modelId: string): number | null {
    const row = this.db.prepare(`
      SELECT AVG(latency_ms) AS average_latency
      FROM (
        SELECT latency_ms
        FROM usage_logs
        WHERE model_id = ? AND status = 'success'
        ORDER BY created_at DESC
        LIMIT 20
      )
    `).get(modelId) as { average_latency: number | null };
    return row?.average_latency === null || row?.average_latency === undefined
      ? null
      : Math.round(row.average_latency);
  }

  estimateCostUsd(
    model: ModelDefinition,
    inputTokens: number | null,
    outputTokens: number | null,
  ): number | null {
    if (inputTokens === null && outputTokens === null) {
      return null;
    }
    if (model.costPer1kInput === 0 && model.costPer1kOutput === 0) {
      return null;
    }
    const inCost = ((inputTokens ?? 0) / 1000) * model.costPer1kInput;
    const outCost = ((outputTokens ?? 0) / 1000) * model.costPer1kOutput;
    return Number((inCost + outCost).toFixed(6));
  }

  recordUsage(entry: {
    traceId: string;
    sessionId: string;
    model: ModelDefinition;
    status: 'success' | 'error';
    latencyMs: number;
    inputTokens: number | null;
    outputTokens: number | null;
    totalTokens: number | null;
    errorCode?: string | null;
    errorMessage?: string | null;
  }): UsageLogEntry {
    const id = `usg_${crypto.randomUUID()}`;
    const createdAt = new Date().toISOString();
    const estimatedCostUsd =
      entry.status === 'success'
        ? this.estimateCostUsd(entry.model, entry.inputTokens, entry.outputTokens)
        : 0;

    this.db
      .prepare(
        `INSERT INTO usage_logs (
          id, trace_id, session_id, model_id, provider, status, latency_ms,
          input_tokens, output_tokens, total_tokens, estimated_cost_usd,
          error_code, error_message, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        id,
        entry.traceId,
        entry.sessionId,
        entry.model.id,
        entry.model.provider,
        entry.status,
        entry.latencyMs,
        entry.inputTokens,
        entry.outputTokens,
        entry.totalTokens,
        estimatedCostUsd,
        entry.errorCode ?? null,
        entry.errorMessage ?? null,
        createdAt,
      );

    return {
      id,
      traceId: entry.traceId,
      sessionId: entry.sessionId,
      modelId: entry.model.id,
      provider: entry.model.provider,
      status: entry.status,
      latencyMs: entry.latencyMs,
      inputTokens: entry.inputTokens,
      outputTokens: entry.outputTokens,
      totalTokens: entry.totalTokens,
      estimatedCostUsd,
      errorCode: entry.errorCode ?? null,
      errorMessage: entry.errorMessage ?? null,
      createdAt,
    };
  }

  saveTrace(trace: RoutingTrace): void {
    this.db
      .prepare(
        `INSERT INTO routing_traces (
          id, session_id, request_preview, intent, complexity, intent_confidence,
          intent_reasoning, routing_mode, requested_model_id, selected_model_id,
          final_model_id, final_provider, selection_reason, candidates_json,
          fallback_attempts_json, memory_facts_used_count, session_messages_used_count,
          final_status, error_message, total_latency_ms, input_tokens, output_tokens,
          total_tokens, estimated_cost_usd, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        trace.id,
        trace.sessionId,
        trace.requestPreview,
        trace.intent,
        trace.complexity,
        trace.intentConfidence,
        trace.intentReasoning,
        trace.routingMode,
        trace.requestedModelId,
        trace.selectedModelId,
        trace.finalModelId,
        trace.finalProvider,
        trace.selectionReason,
        JSON.stringify(trace.candidates),
        JSON.stringify(trace.fallbackAttempts),
        trace.memoryFactsUsedCount,
        trace.sessionMessagesUsedCount,
        trace.finalStatus,
        trace.errorMessage,
        trace.totalLatencyMs,
        trace.inputTokens,
        trace.outputTokens,
        trace.totalTokens,
        trace.estimatedCostUsd,
        trace.createdAt,
      );
  }

  listRecentLogs(limit = 50): UsageLogEntry[] {
    const rows = this.db
      .prepare(
        `SELECT * FROM usage_logs ORDER BY created_at DESC LIMIT ?`,
      )
      .all(limit) as Array<Record<string, unknown>>;

    return rows.map((row) => ({
      id: String(row.id),
      traceId: String(row.trace_id),
      sessionId: String(row.session_id),
      modelId: String(row.model_id),
      provider: row.provider as ProviderId,
      status: row.status as 'success' | 'error',
      latencyMs: Number(row.latency_ms),
      inputTokens: row.input_tokens === null ? null : Number(row.input_tokens),
      outputTokens: row.output_tokens === null ? null : Number(row.output_tokens),
      totalTokens: row.total_tokens === null ? null : Number(row.total_tokens),
      estimatedCostUsd: row.estimated_cost_usd === null ? null : Number(row.estimated_cost_usd),
      errorCode: row.error_code === null ? null : String(row.error_code),
      errorMessage: row.error_message === null ? null : String(row.error_message),
      createdAt: String(row.created_at),
    }));
  }

  listRecentTraces(limit = 30): RoutingTrace[] {
    const rows = this.db
      .prepare(`SELECT * FROM routing_traces ORDER BY created_at DESC LIMIT ?`)
      .all(limit) as Array<Record<string, unknown>>;

    return rows.map((row) => this.mapTraceRow(row));
  }

  getTraceById(id: string): RoutingTrace | null {
    const row = this.db
      .prepare(`SELECT * FROM routing_traces WHERE id = ?`)
      .get(id) as Record<string, unknown> | undefined;
    return row ? this.mapTraceRow(row) : null;
  }

  getUsageSummary(): UsageSummary {
    const totals = this.db
      .prepare(
        `SELECT
          COUNT(*) as totalRequests,
          SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successfulRequests,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failedRequests,
          COALESCE(SUM(total_tokens), 0) as totalTokens,
          COALESCE(SUM(input_tokens), 0) as totalInputTokens,
          COALESCE(SUM(output_tokens), 0) as totalOutputTokens,
          COALESCE(SUM(estimated_cost_usd), 0) as totalEstimatedCostUsd,
          COALESCE(AVG(CASE WHEN status = 'success' THEN latency_ms END), 0) as avgLatencyMs
         FROM usage_logs`,
      )
      .get() as Record<string, number | null>;

    const traceRows = this.db
      .prepare(`SELECT fallback_attempts_json FROM routing_traces`)
      .all() as Array<{ fallback_attempts_json: string }>;

    let fallbackCount = 0;
    for (const row of traceRows) {
      try {
        const attempts = JSON.parse(row.fallback_attempts_json) as Array<unknown>;
        if (attempts.length > 1) {
          fallbackCount += attempts.length - 1;
        }
      } catch {
        // ignore malformed row
      }
    }

    const byProviderRows = this.db
      .prepare(
        `SELECT
          provider,
          COUNT(*) as requests,
          SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successes,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failures,
          COALESCE(SUM(total_tokens), 0) as tokens,
          COALESCE(SUM(estimated_cost_usd), 0) as costUsd,
          COALESCE(AVG(latency_ms), 0) as avgLatencyMs
         FROM usage_logs
         GROUP BY provider
         ORDER BY requests DESC`,
      )
      .all() as Array<Record<string, unknown>>;

    const byModelRows = this.db
      .prepare(
        `SELECT
          model_id as modelId,
          provider,
          COUNT(*) as requests,
          COALESCE(SUM(total_tokens), 0) as tokens,
          COALESCE(AVG(latency_ms), 0) as avgLatencyMs
         FROM usage_logs
         GROUP BY model_id, provider
         ORDER BY requests DESC`,
      )
      .all() as Array<Record<string, unknown>>;

    return {
      totalRequests: Number(totals.totalRequests ?? 0),
      successfulRequests: Number(totals.successfulRequests ?? 0),
      failedRequests: Number(totals.failedRequests ?? 0),
      fallbackCount,
      totalTokens: Number(totals.totalTokens ?? 0),
      totalInputTokens: Number(totals.totalInputTokens ?? 0),
      totalOutputTokens: Number(totals.totalOutputTokens ?? 0),
      totalEstimatedCostUsd: Number(Number(totals.totalEstimatedCostUsd ?? 0).toFixed(6)),
      avgLatencyMs: Math.round(Number(totals.avgLatencyMs ?? 0)),
      byProvider: byProviderRows.map((row) => ({
        provider: row.provider as ProviderId,
        requests: Number(row.requests),
        successes: Number(row.successes),
        failures: Number(row.failures),
        tokens: Number(row.tokens),
        costUsd: Number(Number(row.costUsd).toFixed(6)),
        avgLatencyMs: Math.round(Number(row.avgLatencyMs)),
      })),
      byModel: byModelRows.map((row) => ({
        modelId: String(row.modelId),
        provider: row.provider as ProviderId,
        requests: Number(row.requests),
        tokens: Number(row.tokens),
        avgLatencyMs: Math.round(Number(row.avgLatencyMs)),
      })),
    };
  }

  private mapTraceRow(row: Record<string, unknown>): RoutingTrace {
    return {
      id: String(row.id),
      sessionId: String(row.session_id),
      requestPreview: String(row.request_preview),
      intent: row.intent as RoutingTrace['intent'],
      complexity: row.complexity as RoutingTrace['complexity'],
      intentConfidence: Number(row.intent_confidence),
      intentReasoning: String(row.intent_reasoning),
      routingMode: row.routing_mode as RoutingTrace['routingMode'],
      requestedModelId: row.requested_model_id ? String(row.requested_model_id) : null,
      selectedModelId: row.selected_model_id ? String(row.selected_model_id) : null,
      finalModelId: row.final_model_id ? String(row.final_model_id) : null,
      finalProvider: row.final_provider ? (String(row.final_provider) as ProviderId) : null,
      selectionReason: String(row.selection_reason),
      candidates: JSON.parse(String(row.candidates_json)),
      fallbackAttempts: JSON.parse(String(row.fallback_attempts_json)),
      memoryFactsUsedCount: Number(row.memory_facts_used_count),
      sessionMessagesUsedCount: Number(row.session_messages_used_count),
      finalStatus: row.final_status as RoutingTrace['finalStatus'],
      errorMessage: row.error_message ? String(row.error_message) : null,
      totalLatencyMs: Number(row.total_latency_ms),
      inputTokens: row.input_tokens === null ? null : Number(row.input_tokens),
      outputTokens: row.output_tokens === null ? null : Number(row.output_tokens),
      totalTokens: row.total_tokens === null ? null : Number(row.total_tokens),
      estimatedCostUsd: row.estimated_cost_usd === null ? null : Number(row.estimated_cost_usd),
      createdAt: String(row.created_at),
    };
  }
}
