import JSZip from 'jszip';
import fs from 'node:fs';
import path from 'node:path';

const ALLOWED_ROOT_FILES = [
  'package.json',
  'bun.lock',
  'package-lock.json',
  'tsconfig.json',
  'vite.config.ts',
  'server.ts',
  'index.html',
  'metadata.json',
  '.env.example',
  '.gitignore',
  'README.md',
  'AUDIT-REPORT.md',
];

const ALLOWED_DIRECTORIES = ['src', 'tests'];

const BLOCKED_NAMES = new Set([
  'node_modules',
  'dist',
  'build',
  'data',
  '.git',
  '.aistudio',
  'coverage',
]);

function isBlockedFile(name: string): boolean {
  if (BLOCKED_NAMES.has(name)) return true;
  if (name.startsWith('.env') && name !== '.env.example') return true;
  if (name.endsWith('.db') || name.endsWith('.db-wal') || name.endsWith('.db-shm') || name.endsWith('.log')) {
    return true;
  }
  return false;
}

function addDirectoryRecursive(
  zip: JSZip,
  rootDir: string,
  currentDir: string,
  zipPrefix: string,
): void {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    if (isBlockedFile(entry.name)) continue;
    if (entry.isSymbolicLink()) continue;

    const fullPath = path.resolve(currentDir, entry.name);
    if (!fullPath.startsWith(rootDir + path.sep)) continue;

    const relativeZipPath = `${zipPrefix}/${entry.name}`;
    if (entry.isDirectory()) {
      addDirectoryRecursive(zip, rootDir, fullPath, relativeZipPath);
    } else if (entry.isFile()) {
      const content = fs.readFileSync(fullPath);
      zip.file(relativeZipPath, content);
    }
  }
}

export async function buildProjectZipBuffer(
  projectRoot = process.cwd(),
  options: { includeDist?: boolean } = {},
): Promise<{
  buffer: Buffer;
  fileCount: number;
  filename: string;
}> {
  const resolvedRoot = path.resolve(projectRoot);
  const zip = new JSZip();
  const rootFolder = 'capri-core';

  for (const filename of ALLOWED_ROOT_FILES) {
    if (isBlockedFile(filename)) continue;
    const fullPath = path.resolve(resolvedRoot, filename);
    if (!fullPath.startsWith(resolvedRoot + path.sep)) continue;
    if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
      zip.file(`${rootFolder}/${filename}`, fs.readFileSync(fullPath));
    }
  }

  const dirsToInclude = options.includeDist
    ? [...ALLOWED_DIRECTORIES, 'dist']
    : ALLOWED_DIRECTORIES;

  for (const dirName of dirsToInclude) {
    const dirPath = path.resolve(resolvedRoot, dirName);
    if (!dirPath.startsWith(resolvedRoot + path.sep)) continue;
    if (fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory()) {
      addDirectoryRecursive(zip, resolvedRoot, dirPath, `${rootFolder}/${dirName}`);
    }
  }

  const fileCount = Object.keys(zip.files).filter((k) => !zip.files[k].dir).length;
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  return {
    buffer,
    fileCount,
    filename: 'capri-core-project.zip',
  };
}
