import type { MemoryFact } from '../../core/types.ts';

export type MemoryAccessRole = 'user' | 'admin';

/** Explicit outbound and UI access rules; sensitivity is never auto-downgraded here. */
export class MemoryAccessPolicy {
  canSendToExternalProvider(fact: Pick<MemoryFact, 'sensitivity'>): boolean {
    return fact.sensitivity === 'normal';
  }

  canExposeInProtectedApi(fact: Pick<MemoryFact, 'sensitivity'>, role: MemoryAccessRole): boolean {
    return role === 'admin' || fact.sensitivity !== 'restricted';
  }

  isValidAt(fact: Pick<MemoryFact, 'validFrom' | 'expiresAt'>, at: string): boolean {
    const timestamp = Date.parse(at);
    return (!fact.validFrom || Date.parse(fact.validFrom) <= timestamp)
      && (!fact.expiresAt || Date.parse(fact.expiresAt) > timestamp);
  }

  isRecoverableInSession(fact: Pick<MemoryFact, 'active' | 'status' | 'scope' | 'sessionId' | 'validFrom' | 'expiresAt'>,
    sessionId: string, at: string): boolean {
    return fact.active && fact.status === 'active' && this.isValidAt(fact, at)
      && (fact.scope === 'long_term' || fact.sessionId === sessionId);
  }
}
