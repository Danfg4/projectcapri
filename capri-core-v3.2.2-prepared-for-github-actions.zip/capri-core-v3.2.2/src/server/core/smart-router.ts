import type {
  IntentClassification,
  ModelWithStatus,
  RoutingCandidateEvaluation,
  RoutingMode,
} from '../../core/types.ts';

export interface SmartRouterInput {
  classification: IntentClassification;
  models: ModelWithStatus[];
  routingMode: RoutingMode;
  requestedModelId?: string | null;
  allowFallbackOnManual?: boolean;
  maxFallbackAttempts?: number;
  estimatedContextTokens?: number;
}

export interface SmartRoutingDecision {
  ok: boolean;
  primaryModel: ModelWithStatus | null;
  fallbackChain: ModelWithStatus[];
  selectionReason: string;
  blockedMessage: string | null;
  candidates: RoutingCandidateEvaluation[];
}

export class SmartRouter {
  route(input: SmartRouterInput): SmartRoutingDecision {
    const requestedFallbacks = Number.isFinite(input.maxFallbackAttempts)
      ? Math.floor(input.maxFallbackAttempts ?? 2)
      : 2;
    const maxFallbacks = Math.min(3, Math.max(0, requestedFallbacks));
    const effectiveManualId = input.requestedModelId?.trim() || null;

    if (input.routingMode === 'manual') {
      if (!effectiveManualId) {
        const message = 'O modo manual exige um modelo selecionado. Nenhum roteamento automático foi executado.';
        return {
          ok: false,
          primaryModel: null,
          fallbackChain: [],
          selectionReason: message,
          blockedMessage: message,
          candidates: input.models.map((model) => ({
            modelId: model.id,
            displayName: model.displayName,
            provider: model.provider,
            tier: model.capabilityTier,
            availability: model.availability,
            eligible: false,
            score: 0,
            reason: 'Aguardando seleção explícita de modelo no modo manual.',
          })),
        };
      }
      return this.routeManual({
        ...input,
        requestedModelId: effectiveManualId,
        maxFallbacks,
      });
    }

    return this.routeAuto(input.classification, input.models, maxFallbacks, input.estimatedContextTokens);
  }

  private routeManual(
    input: SmartRouterInput & { requestedModelId: string; maxFallbacks: number },
  ): SmartRoutingDecision {
    const target = input.models.find((m) => m.id === input.requestedModelId);

    const evaluations: RoutingCandidateEvaluation[] = input.models.map((m) => {
      const isTarget = m.id === input.requestedModelId;
      const contextFits = this.contextFits(m, input.estimatedContextTokens);
      const eligible = m.availability === 'available' && contextFits;
      return {
        modelId: m.id,
        displayName: m.displayName,
        provider: m.provider,
        tier: m.capabilityTier,
        availability: m.availability,
        eligible,
        score: isTarget ? 100 : eligible ? this.scoreModel(m, input.classification) : 0,
        reason: isTarget
          ? m.availability !== 'available'
            ? `Modelo selecionado manualmente indisponível: ${m.availabilityReason}`
            : !contextFits
              ? `Modelo selecionado manualmente não comporta o contexto estimado obrigatório (${input.estimatedContextTokens} > orçamento de entrada ${this.availableInputTokens(m)}; limite total ${m.maxContextTokens}).`
              : 'Modelo selecionado manualmente pelo usuário (prioridade absoluta).'
          : eligible
            ? 'Candidato compatível em standby.'
            : m.availability !== 'available'
              ? m.availabilityReason
              : `Contexto estimado obrigatório excede o orçamento de entrada ${this.availableInputTokens(m)} tokens, após reserva de resposta e margem de segurança (limite total ${m.maxContextTokens}).`,
      };
    });

    if (!target) {
      return {
        ok: false,
        primaryModel: null,
        fallbackChain: [],
        selectionReason: `Modelo manual "${input.requestedModelId}" não encontrado no Model Registry.`,
        blockedMessage: `O modelo selecionado manualmente (${input.requestedModelId}) não existe no registro.`,
        candidates: evaluations,
      };
    }

    const targetContextFits = this.contextFits(target, input.estimatedContextTokens);
    if (target.availability !== 'available' || !targetContextFits) {
      const targetUnavailableReason = target.availability !== 'available'
        ? target.availabilityReason
        : `contexto estimado obrigatório (${input.estimatedContextTokens} tokens) excede o orçamento de entrada ${this.availableInputTokens(target)} tokens, após reserva de resposta e margem de segurança (limite total ${target.maxContextTokens})`;
      if (!input.allowFallbackOnManual) {
        return {
          ok: false,
          primaryModel: null,
          fallbackChain: [],
          selectionReason: `Prioridade manual respeitada: ${target.displayName} não é compatível (${targetUnavailableReason}) e fallback automático para seleção manual está desativado.`,
          blockedMessage: `Não foi possível executar com ${target.displayName}: ${targetUnavailableReason}`,
          candidates: evaluations,
        };
      }

      const rankedFallbacks = this.rankAvailableModels(
        input.models.filter((m) => m.id !== target.id && m.provider !== target.provider && m.availability === 'available' && this.contextFits(m, input.estimatedContextTokens)),
        input.classification,
      );

      if (rankedFallbacks.length === 0 || input.maxFallbacks === 0) {
        return {
          ok: false,
          primaryModel: null,
          fallbackChain: [],
          selectionReason: `Modelo manual ${target.displayName} incompatível (${targetUnavailableReason}) e nenhum modelo compatível disponível para fallback.`,
          blockedMessage: `Modelo manual incompatível (${targetUnavailableReason}) e não há outro provedor verificado e compatível para fallback.`,
          candidates: evaluations,
        };
      }

      const [firstFallback, ...rest] = rankedFallbacks;
      return {
        ok: true,
        primaryModel: firstFallback.model,
        fallbackChain: this.uniqueProviderFallbacks(rest, firstFallback.model.provider, Math.max(0, input.maxFallbacks - 1)),
        selectionReason: `Modelo manual ${target.displayName} incompatível (${targetUnavailableReason}); fallback autorizado pelo usuário direcionou para ${firstFallback.model.displayName}.`,
        blockedMessage: null,
        candidates: evaluations,
      };
    }

    const fallbackChain = input.allowFallbackOnManual
      ? this.uniqueProviderFallbacks(
          this.rankAvailableModels(
            input.models.filter((m) => m.id !== target.id && m.provider !== target.provider && m.availability === 'available' && this.contextFits(m, input.estimatedContextTokens)),
            input.classification,
          ),
          target.provider,
          input.maxFallbacks,
        )
      : [];

    return {
      ok: true,
      primaryModel: target,
      fallbackChain,
      selectionReason: `Prioridade manual do usuário respeitada: executando diretamente com ${target.displayName} (${target.provider}).`,
      blockedMessage: null,
      candidates: evaluations,
    };
  }

  private routeAuto(
    classification: IntentClassification,
    models: ModelWithStatus[],
    maxFallbacks: number,
    estimatedContextTokens?: number,
  ): SmartRoutingDecision {
    const rankedAvailable: Array<{ model: ModelWithStatus; score: number; reason: string }> = [];
    const candidates: RoutingCandidateEvaluation[] = [];

    for (const model of models) {
      if (model.availability !== 'available' || !this.contextFits(model, estimatedContextTokens)) {
        candidates.push({
          modelId: model.id,
          displayName: model.displayName,
          provider: model.provider,
          tier: model.capabilityTier,
          availability: model.availability,
          eligible: false,
          score: 0,
          reason: model.availability !== 'available'
            ? model.availabilityReason
            : `Contexto estimado obrigatório (${estimatedContextTokens} tokens) excede o orçamento de entrada ${this.availableInputTokens(model)} tokens, após reserva de resposta e margem de segurança (limite total ${model.maxContextTokens}).`,
        });
        continue;
      }

      const { score, breakdown } = this.scoreModelDetailed(model, classification);
      rankedAvailable.push({ model, score, reason: breakdown });
      candidates.push({
        modelId: model.id,
        displayName: model.displayName,
        provider: model.provider,
        tier: model.capabilityTier,
        availability: model.availability,
        eligible: true,
        score,
        reason: breakdown,
      });
    }

    rankedAvailable.sort((a, b) => this.compareRanked(a, b));
    candidates.sort((a, b) => Number(b.eligible) - Number(a.eligible) || b.score - a.score);

    if (rankedAvailable.length === 0) {
      const missingKeys = Array.from(
        new Set(models.filter((m) => m.availability === 'not_configured').map((m) => m.envKey)),
      );
      const exhausted = models.filter((m) => m.availability === 'quota_exhausted').map((m) => m.displayName);

      const limitationParts: string[] = [];
      if (exhausted.length > 0) {
        limitationParts.push(`Cota esgotada em: ${exhausted.join(', ')}.`);
      }
      if (missingKeys.length > 0) {
        limitationParts.push(`Provedores sem chave configurada: ${missingKeys.join(', ')}.`);
      }

      const blockedMessage =
        limitationParts.length > 0
          ? `Nenhum modelo compatível disponível no momento. ${limitationParts.join(' ')}`
          : 'Nenhum modelo habilitado e disponível no Model Registry.';

      return {
        ok: false,
        primaryModel: null,
        fallbackChain: [],
        selectionReason: blockedMessage,
        blockedMessage,
        candidates,
      };
    }

    const primary = rankedAvailable[0];
    const fallbackChain = this.uniqueProviderFallbacks(rankedAvailable.slice(1), primary.model.provider, maxFallbacks);

    return {
      ok: true,
      primaryModel: primary.model,
      fallbackChain,
      selectionReason: `Selecionado ${primary.model.displayName} (score ${primary.score.toFixed(1)}) para tarefa "${classification.intent}" [${classification.complexity}], contexto estimado ~${estimatedContextTokens ?? 'desconhecido'} tokens: ${primary.reason}`, 
      blockedMessage: null,
      candidates,
    };
  }

  private uniqueProviderFallbacks(
    ranked: Array<{ model: ModelWithStatus; score: number }>,
    primaryProvider: ModelWithStatus['provider'],
    limit: number,
  ): ModelWithStatus[] {
    if (limit <= 0) return [];
    const usedProviders = new Set<ModelWithStatus['provider']>([primaryProvider]);
    const fallbacks: ModelWithStatus[] = [];
    for (const candidate of ranked) {
      if (usedProviders.has(candidate.model.provider)) continue;
      usedProviders.add(candidate.model.provider);
      fallbacks.push(candidate.model);
      if (fallbacks.length >= limit) break;
    }
    return fallbacks;
  }

  private availableInputTokens(model: ModelWithStatus): number {
    const maxContextTokens = Math.max(1, Math.floor(model.maxContextTokens));
    const reservedOutputTokens = Math.min(4096, Math.max(512, Math.ceil(maxContextTokens * 0.15)));
    const safetyMarginTokens = Math.ceil(maxContextTokens * 0.10);
    return maxContextTokens - reservedOutputTokens - safetyMarginTokens;
  }

  private contextFits(model: ModelWithStatus, estimatedContextTokens?: number): boolean {
    if (!estimatedContextTokens) return true;
    const availableInputTokens = this.availableInputTokens(model);
    return availableInputTokens > 0 && estimatedContextTokens <= availableInputTokens;
  }

  private compareRanked(
    a: { model: ModelWithStatus; score: number },
    b: { model: ModelWithStatus; score: number },
  ): number {
    const aKnownCost = a.model.costPer1kInput + a.model.costPer1kOutput;
    const bKnownCost = b.model.costPer1kInput + b.model.costPer1kOutput;
    return b.score - a.score
      || a.model.avgLatencyMs - b.model.avgLatencyMs
      || (aKnownCost > 0 && bKnownCost > 0 ? aKnownCost - bKnownCost : 0)
      || a.model.id.localeCompare(b.model.id);
  }

  private rankAvailableModels(
    models: ModelWithStatus[],
    classification: IntentClassification,
  ): Array<{ model: ModelWithStatus; score: number }> {
    return models
      .map((model) => ({
        model,
        score: this.scoreModel(model, classification),
      }))
      .sort((a, b) => this.compareRanked(a, b));
  }

  private scoreModel(model: ModelWithStatus, classification: IntentClassification): number {
    return this.scoreModelDetailed(model, classification).score;
  }

  private scoreModelDetailed(
    model: ModelWithStatus,
    classification: IntentClassification,
  ): { score: number; breakdown: string } {
    const reasons: string[] = [];
    let score = 0;

    // 1. Aderência à intenção
    const matchesIntent = model.strengths.includes(classification.intent);
    if (matchesIntent) {
      score += 40;
      reasons.push(`especialista em ${classification.intent}`);
    } else {
      score += 10;
    }

    // 2. Equilíbrio de recursos (econômico para tarefas simples; robusto para complexas)
    const isSimpleTask =
      classification.complexity === 'low' ||
      classification.intent === 'general_chat' ||
      classification.intent === 'quick_summary';
    const isHeavyTask =
      classification.complexity === 'high' ||
      classification.intent === 'complex_reasoning' ||
      classification.intent === 'coding' ||
      classification.intent === 'document_analysis';

    if (isSimpleTask && !isHeavyTask) {
      if (model.capabilityTier === 'fast_economy') {
        score += 34;
        reasons.push('econômico e veloz para tarefa simples');
      } else if (model.capabilityTier === 'balanced') {
        score += 16;
      } else {
        score -= 10;
        reasons.push('preservando cota de raciocínio avançado');
      }
    } else if (isHeavyTask) {
      if (model.capabilityTier === 'deep_reasoning') {
        score += 34;
        reasons.push('alta capacidade de raciocínio');
      } else if (model.capabilityTier === 'balanced') {
        score += 28;
        reasons.push('equilíbrio sólido para tarefa técnica');
      } else {
        score -= 12;
      }
    } else {
      if (model.capabilityTier === 'balanced') {
        score += 28;
        reasons.push('nível equilibrado');
      } else if (model.capabilityTier === 'fast_economy') {
        score += 20;
      } else {
        score += 22;
      }
    }

    // 3. Saúde da cota restante (evita saturar modelos próximos do limite)
    const rpmRatio = model.rpmLimit > 0 ? model.quota.rpmRemaining / model.rpmLimit : 1;
    const rpdRatio = model.rpdLimit > 0 ? model.quota.rpdRemaining / model.rpdLimit : 1;
    const tpdRatio = model.tpdLimit > 0 ? model.quota.tpdRemaining / model.tpdLimit : 1;
    const quotaHealth = Math.min(rpmRatio, rpdRatio, tpdRatio);
    score += Number((quotaHealth * 15).toFixed(1));

    // 4. Latência & custo relativo
    const latencyBonus = model.avgLatencyMs > 0 ? Math.max(0, 10 - model.avgLatencyMs / 500) : 0;
    const totalPer1k = model.costPer1kInput + model.costPer1kOutput;
    // Cost fields are local estimates, not provider billing guarantees. Unknown (zero) values receive no bonus.
    const costBonus = totalPer1k > 0 ? Math.max(0, 8 - Math.log10(totalPer1k * 1000 + 1) * 3) : 0;
    score += Number((latencyBonus + costBonus).toFixed(1));
    reasons.push(`latência de referência ${model.avgLatencyMs > 0 ? `${model.avgLatencyMs}ms` : 'não informada'}`);
    reasons.push(totalPer1k > 0 ? 'custo local estimado considerado' : 'custo sem estimativa verificada');

    return {
      score: Number(score.toFixed(1)),
      breakdown: reasons.length > 0 ? reasons.join(', ') : 'seleção multicritério balanceada',
    };
  }
}
