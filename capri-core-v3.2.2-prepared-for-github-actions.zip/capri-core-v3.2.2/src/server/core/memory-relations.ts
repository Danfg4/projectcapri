import type { MemoryFact } from '../../core/types.ts';
import type { SharedMemoryManager } from './shared-memory.ts';
import { MemoryAccessPolicy } from './memory-policy.ts';

/** Bounded graph traversal for safe related_to / derived_from context expansion. */
export class MemoryRelationExpander {
  constructor(private readonly store: SharedMemoryManager, private readonly policy: MemoryAccessPolicy) {}

  expand(roots: Array<{ fact: MemoryFact; score: number }>, sessionId: string, at: string,
    scoreFact: (fact: MemoryFact, expanded: boolean) => number,
    maxFacts = 8, maxDepth = 2): Array<{ fact: MemoryFact; score: number }> {
    const visited = new Set<string>();
    const included = new Set(roots.map(({ fact }) => fact.id));
    const expanded: Array<{ fact: MemoryFact; score: number }> = [];
    const queue = roots.slice(0, 12).map(({ fact }) => ({ id: fact.id, depth: 0 }));
    while (queue.length && expanded.length < maxFacts) {
      const current = queue.shift()!;
      if (visited.has(current.id) || current.depth >= maxDepth) continue;
      visited.add(current.id);
      for (const relatedId of this.store.getRelatedFactIds(current.id)) {
        if (visited.has(relatedId) || included.has(relatedId)) continue;
        const fact = this.store.getFactById(relatedId);
        if (!fact || !this.policy.canSendToExternalProvider(fact)
          || !this.policy.isRecoverableInSession(fact, sessionId, at)) continue;
        const score = scoreFact(fact, true);
        if (score < 0.12) continue;
        included.add(fact.id);
        expanded.push({ fact, score });
        queue.push({ id: fact.id, depth: current.depth + 1 });
        if (expanded.length >= maxFacts) break;
      }
    }
    return expanded;
  }
}
