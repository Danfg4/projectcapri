import type Database from 'better-sqlite3';
import crypto from 'node:crypto';
import type {
  IntentCategory,
  MemoryFact,
  ProviderId,
  SessionMessage,
  SessionRecord,
} from '../../core/types.ts';

const SENSITIVE_MEMORY_PATTERN = /\b(senha|password|passwd|api[ _-]?key|access[ _-]?token|refresh[ _-]?token|secret|chave privada|cpf|cnpj|cart[aã]o de cr[eé]dito|conta banc[aá]ria|diagn[oó]stico|medica[cç][aã]o)\b/i;

const MEMORY_DIRECTIVE_PATTERNS = [
  /^(?:por favor,?\s*)?(?:lembre(?:-se)?(?:\s+de)?\s+que|memorize(?:\s+que)?|guarde\s+na\s+mem[oó]ria(?:\s+que)?|anote\s+que)\s+(.+)/i,
  /^(?:please\s+)?remember\s+that\s+(.+)/i,
];

export class SharedMemoryManager {
  private readonly db: Database.Database;

  constructor(db: Database.Database) {
    this.db = db;
  }

  private sensitivityRank(value: MemoryFact['sensitivity']): number {
    return value === 'restricted' ? 2 : value === 'private' ? 1 : 0;
  }

  listFacts(activeOnly = false): MemoryFact[] {
    const query = activeOnly
      ? `SELECT * FROM memory_facts WHERE active = 1 AND status = 'active'
         AND (valid_from IS NULL OR valid_from <= ?)
         AND (expires_at IS NULL OR expires_at > ?)
         ORDER BY importance DESC, updated_at DESC`
      : `SELECT * FROM memory_facts ORDER BY active DESC, importance DESC, updated_at DESC`;
    const now = new Date().toISOString();
    const rows = (activeOnly ? this.db.prepare(query).all(now, now) : this.db.prepare(query).all()) as Array<Record<string, unknown>>;
    return rows.map((r) => this.mapFactRow(r));
  }

  listRecoverableFacts(sessionId: string, at: string): MemoryFact[] {
    const rows = this.db.prepare(`SELECT * FROM memory_facts
      WHERE active = 1 AND status = 'active'
        AND (valid_from IS NULL OR valid_from <= ?)
        AND (expires_at IS NULL OR expires_at > ?)
        AND (scope = 'long_term' OR (scope IN ('session', 'temporary') AND session_id = ?))
      ORDER BY importance DESC, updated_at DESC`).all(at, at, sessionId) as Array<Record<string, unknown>>;
    return rows.map((row) => this.mapFactRow(row));
  }

  listSensitiveFactContents(): string[] {
    return (this.db.prepare(`SELECT content FROM memory_facts WHERE COALESCE(sensitivity, 'normal') <> 'normal'`)
      .all() as Array<{ content: string }>).map((row) => String(row.content ?? '')).filter((content) => content.trim().length >= 4);
  }

  upsertFact(input: {
    id?: string;
    category: MemoryFact['category'];
    key: string;
    content: string;
    sourceModel?: string | null;
    importance?: number;
    active?: boolean;
    scope?: MemoryFact['scope'];
    sessionId?: string | null;
    sourceType?: MemoryFact['sourceType'];
    sourceRef?: string | null;
    confidence?: number;
    userConfirmed?: boolean;
    validFrom?: string | null;
    expiresAt?: string | null;
    sensitivity?: MemoryFact['sensitivity'];
  }): MemoryFact {
    const persist = this.db.transaction((): MemoryFact => {
    const now = new Date().toISOString();
    const cleanKey = input.key.trim().slice(0, 80);
    const cleanContent = input.content.trim();
    if (!cleanKey || !cleanContent) throw new Error('Chave e conteúdo da memória são obrigatórios.');
    if (SENSITIVE_MEMORY_PATTERN.test(cleanContent) && input.sensitivity !== 'restricted') {
      throw new Error('Conteúdo potencialmente sensível não será armazenado como memória comum.');
    }
    const scope = input.scope ?? 'long_term';
    if ((scope === 'session' || scope === 'temporary') && !input.sessionId) {
      throw new Error('Memória de sessão ou temporária exige sessionId.');
    }
    const sessionId = scope === 'session' || scope === 'temporary' ? input.sessionId ?? null : null;
    if (scope === 'temporary' && !input.expiresAt) throw new Error('Memória temporária exige expiresAt.');
    const validFrom = input.validFrom ? this.normalizeTimestamp(input.validFrom, 'validFrom') : now;
    const expiresAt = input.expiresAt ? this.normalizeTimestamp(input.expiresAt, 'expiresAt') : null;
    if (expiresAt && Date.parse(expiresAt) <= Date.parse(validFrom)) {
      throw new Error('expiresAt precisa ser posterior a validFrom.');
    }
    const confidence = Math.min(1, Math.max(0, input.confidence ?? (input.userConfirmed ? 1 : 0.65)));
    const importance = Math.min(10, Math.max(1, Math.round(input.importance ?? 7)));
    const userConfirmed = Boolean(input.userConfirmed);
    const sourceType = input.sourceType ?? (userConfirmed ? 'user_explicit' : 'legacy');

    const pendingDuplicate = this.db.prepare(`SELECT * FROM memory_facts
      WHERE key = ? AND category = ? AND scope = ? AND COALESCE(session_id, '') = COALESCE(?, '')
        AND content = ? AND status = 'pending_confirmation'
      ORDER BY updated_at DESC LIMIT 1`).get(cleanKey, input.category, scope, sessionId, cleanContent) as Record<string, unknown> | undefined;
    if (pendingDuplicate) return this.mapFactRow(pendingDuplicate);

    const existingByKey = this.db.prepare(
      `SELECT * FROM memory_facts WHERE key = ? AND category = ? AND scope = ?
       AND COALESCE(session_id, '') = COALESCE(?, '') AND status = 'active'
       ORDER BY updated_at DESC LIMIT 1`,
    ).get(cleanKey, input.category, scope, sessionId) as Record<string, unknown> | undefined
      ?? this.db.prepare(`SELECT * FROM memory_facts WHERE LOWER(TRIM(content)) = LOWER(TRIM(?))
        AND category = ? AND scope = ? AND COALESCE(session_id, '') = COALESCE(?, '')
        AND status = 'active' ORDER BY updated_at DESC LIMIT 1`)
        .get(cleanContent, input.category, scope, sessionId) as Record<string, unknown> | undefined;

    if (existingByKey && String(existingByKey.content) !== cleanContent) {
      const existingSensitivity = String(existingByKey.sensitivity ?? 'normal') as MemoryFact['sensitivity'];
      const proposalSensitivity = input.sensitivity ?? existingSensitivity;
      if (this.sensitivityRank(proposalSensitivity) < this.sensitivityRank(existingSensitivity)) {
        throw new Error('Uma proposta não pode reduzir a sensibilidade do fato substituído. Use a operação explícita de alteração com confirmação administrativa.');
      }
      const candidateId = `mem_${crypto.randomUUID()}`;
      this.db.prepare(`INSERT INTO memory_facts (
        id, category, key, content, source_model, importance, active, created_at, updated_at,
        scope, session_id, source_type, source_ref, confidence, user_confirmed, status,
        valid_from, expires_at, sensitivity
      ) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, 0, 'pending_confirmation', ?, ?, ?)`)
        .run(candidateId, input.category, cleanKey, cleanContent, input.sourceModel ?? null,
          importance, now, now, scope, sessionId, sourceType, input.sourceRef ?? null,
          confidence, validFrom, expiresAt, proposalSensitivity);
      this.db.prepare(`INSERT OR IGNORE INTO memory_relations (from_fact_id, to_fact_id, relation_type, created_at)
        VALUES (?, ?, 'contradicts', ?)`).run(candidateId, String(existingByKey.id), now);
      this.recordEvent(candidateId, 'conflict_detected', null, { content: cleanContent, conflictsWith: String(existingByKey.id) }, sourceType);
      const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(candidateId) as Record<string, unknown>;
      return this.mapFactRow(row);
    }

    const targetId = input.id ?? (existingByKey ? String(existingByKey.id) : `mem_${crypto.randomUUID()}`);
    const existing = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(targetId) as Record<string, unknown> | undefined;
    if (existing) {
      if (String(existing.status) === 'rejected') {
        throw new Error('Propostas rejeitadas não podem ser reativadas por upsert.');
      }
      if (String(existing.status) === 'superseded') {
        throw new Error('Fatos substituídos não podem ser reativados por upsert; crie uma nova proposta.');
      }
      const currentSensitivity = String(existing.sensitivity ?? 'normal') as MemoryFact['sensitivity'];
      const requestedSensitivity = input.sensitivity ?? currentSensitivity;
      if (this.sensitivityRank(requestedSensitivity) < this.sensitivityRank(currentSensitivity)) {
        throw new Error('A classificação de sensibilidade não pode ser reduzida por upsert; use a operação explícita de alteração com confirmação administrativa.');
      }
      const effectiveConfirmed = userConfirmed || Number(existing.user_confirmed) === 1;
      const effectiveConfidence = Math.max(confidence, Number(existing.confidence ?? 0));
      const effectiveSourceType = Number(existing.user_confirmed) === 1 && !userConfirmed
        ? String(existing.source_type) : sourceType;
      const oldValue = this.factSnapshot(existing);
      this.db.prepare(`UPDATE memory_facts SET category = ?, key = ?, content = ?, source_model = ?,
        importance = ?, active = ?, updated_at = ?, scope = ?, session_id = ?, source_type = ?,
        source_ref = ?, confidence = ?, user_confirmed = ?, status = 'active', valid_from = ?, expires_at = ?, sensitivity = ?
        WHERE id = ?`).run(input.category, cleanKey, cleanContent, input.sourceModel ?? null,
          importance, input.active === false ? 0 : 1, now, scope, sessionId,
          effectiveSourceType, input.sourceRef ?? null, effectiveConfidence, effectiveConfirmed ? 1 : 0,
          input.validFrom ? validFrom : String(existing.valid_from ?? validFrom),
          input.expiresAt === undefined ? (existing.expires_at ? String(existing.expires_at) : null) : expiresAt,
          input.sensitivity ?? String(existing.sensitivity ?? 'normal'), targetId);
      const updated = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(targetId) as Record<string, unknown>;
      this.recordEvent(targetId, 'updated', oldValue, this.factSnapshot(updated), effectiveConfirmed ? 'user' : sourceType);
      return this.mapFactRow(updated);
    }

    this.db.prepare(`INSERT INTO memory_facts (
      id, category, key, content, source_model, importance, active, created_at, updated_at,
      scope, session_id, source_type, source_ref, confidence, user_confirmed, status,
      valid_from, expires_at, sensitivity
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?)`)
      .run(targetId, input.category, cleanKey, cleanContent, input.sourceModel ?? null,
        importance, input.active === false ? 0 : 1, now, now, scope, sessionId,
        sourceType, input.sourceRef ?? null, confidence, userConfirmed ? 1 : 0,
        validFrom, expiresAt, input.sensitivity ?? 'normal');
    const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(targetId) as Record<string, unknown>;
    this.recordEvent(targetId, 'created', null, this.factSnapshot(row), sourceType);
    return this.mapFactRow(row);
      });
    return persist.immediate();
  }

  getFactById(id: string): MemoryFact | null {
    const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    return row ? this.mapFactRow(row) : null;
  }

  /** Rejects a pending proposal without deleting its history or the previous active fact. */
  rejectFact(id: string): MemoryFact | null {
    const transaction = this.db.transaction((): MemoryFact | null => {
      const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown> | undefined;
      if (!row) return null;
      if (String(row.status) === 'rejected') return this.mapFactRow(row);
      if (String(row.status) !== 'pending_confirmation') return null;
      const now = new Date().toISOString();
      this.db.prepare(`UPDATE memory_facts SET status = 'rejected', active = 0, updated_at = ? WHERE id = ?`)
        .run(now, id);
      const rejected = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown>;
      this.recordEvent(id, 'proposal_rejected',
        { status: 'pending_confirmation', active: true, sensitivity: row.sensitivity },
        { status: 'rejected', active: false, sensitivity: rejected.sensitivity }, 'admin');
      return this.mapFactRow(rejected);
    });
    return transaction.immediate();
  }

  /** Sensitivity changes are explicit; lowering protection requires an explicit second confirmation. */
  changeSensitivity(id: string, sensitivity: MemoryFact['sensitivity'], confirmDowngrade = false): MemoryFact | null {
    const rank: Record<MemoryFact['sensitivity'], number> = { normal: 0, private: 1, restricted: 2 };
    const transaction = this.db.transaction((): MemoryFact | null => {
      const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown> | undefined;
      if (!row) return null;
      const current = String(row.sensitivity ?? 'normal') as MemoryFact['sensitivity'];
      if (current === sensitivity) return this.mapFactRow(row);
      if (rank[sensitivity] < rank[current] && !confirmDowngrade) {
        throw new Error('Reduzir a proteção exige confirmação explícita do administrador.');
      }
      const now = new Date().toISOString();
      this.db.prepare('UPDATE memory_facts SET sensitivity = ?, updated_at = ? WHERE id = ?').run(sensitivity, now, id);
      const updated = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown>;
      this.recordEvent(id, 'sensitivity_changed', { sensitivity: current }, { sensitivity }, 'admin');
      return this.mapFactRow(updated);
    });
    return transaction.immediate();
  }

  /** Explicitly accepts a pending replacement and keeps the prior value in the event history. */
  confirmFact(id: string): MemoryFact | null {
    const transaction = this.db.transaction((): boolean => {
      const candidate = this.db.prepare(`SELECT * FROM memory_facts WHERE id = ? AND status = 'pending_confirmation'`).get(id) as Record<string, unknown> | undefined;
      if (!candidate) return false;
      const now = new Date().toISOString();
      const conflicts = this.db.prepare(`SELECT to_fact_id FROM memory_relations WHERE from_fact_id = ? AND relation_type = 'contradicts'`).all(id) as Array<{ to_fact_id: string }>;
      for (const conflict of conflicts) {
        const old = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(conflict.to_fact_id) as Record<string, unknown> | undefined;
        if (old) {
          this.db.prepare(`UPDATE memory_facts SET active = 0, status = 'superseded', superseded_by = ?, updated_at = ? WHERE id = ?`).run(id, now, conflict.to_fact_id);
          this.recordEvent(conflict.to_fact_id, 'superseded', this.factSnapshot(old), { supersededBy: id }, 'user');
        }
        this.db.prepare(`INSERT OR IGNORE INTO memory_relations (from_fact_id, to_fact_id, relation_type, created_at) VALUES (?, ?, 'supersedes', ?)`).run(id, conflict.to_fact_id, now);
      }
      this.db.prepare(`UPDATE memory_facts SET status = 'active', active = 1, user_confirmed = 1,
        source_type = 'user_confirmed', confidence = 1, updated_at = ? WHERE id = ?`).run(now, id);
      this.recordEvent(id, 'confirmed', this.factSnapshot(candidate), { confirmed: true }, 'user');
      return true;
    });
    if (!transaction.immediate()) return null;
    const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown>;
    return this.mapFactRow(row);
  }

  private normalizeTimestamp(value: string, field: string): string {
    const parsed = Date.parse(value);
    if (!Number.isFinite(parsed)) throw new Error(`${field} inválido.`);
    return new Date(parsed).toISOString();
  }

  private factSnapshot(row: Record<string, unknown>): Record<string, unknown> {
    return { category: row.category, key: row.key, content: row.content, importance: row.importance,
      scope: row.scope, confidence: row.confidence, userConfirmed: row.user_confirmed, status: row.status, sensitivity: row.sensitivity };
  }

  private recordEvent(id: string, type: string, oldValue: unknown, newValue: unknown, actor: string): void {
    this.db.prepare(`INSERT INTO memory_events (id, memory_fact_id, event_type, old_value_json,
      new_value_json, actor_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`)
      .run(`mev_${crypto.randomUUID()}`, id, type, oldValue == null ? null : JSON.stringify(oldValue),
        newValue == null ? null : JSON.stringify(newValue), actor, new Date().toISOString());
  }

  updateFact(
    id: string,
    patch: Partial<{
      category: MemoryFact['category'];
      key: string;
      content: string;
      importance: number;
      active: boolean;
      scope: MemoryFact['scope'];
      sessionId: string | null;
      sourceType: MemoryFact['sourceType'];
      sourceRef: string | null;
      confidence: number;
      userConfirmed: boolean;
      validFrom: string | null;
      expiresAt: string | null;
      sensitivity: MemoryFact['sensitivity'];
    }>,
  ): MemoryFact | null {
    const transaction = this.db.transaction((): MemoryFact | null => {
      const row = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown> | undefined;
      if (!row) return null;
      const existing = this.mapFactRow(row);
      const nextKey = patch.key === undefined ? existing.key : patch.key.trim().slice(0, 80);
      const nextContent = patch.content === undefined ? existing.content : patch.content.trim();
      const nextCategory = patch.category ?? existing.category;
      if (!nextKey || !nextContent) throw new Error('Chave e conteúdo da memória são obrigatórios.');

      if ((existing.status === 'rejected' || existing.status === 'superseded') && patch.active === true) {
        throw new Error('Fatos rejeitados ou substituídos não podem ser reativados.');
      }
      const oldValue = this.factSnapshot(row);
      const scope = patch.scope ?? existing.scope;
      const sessionId = scope === 'session' || scope === 'temporary'
        ? (patch.sessionId !== undefined ? patch.sessionId : existing.sessionId)
        : null;
      const validFrom = patch.validFrom !== undefined
        ? (patch.validFrom ? this.normalizeTimestamp(patch.validFrom, 'validFrom') : null)
        : existing.validFrom;
      const expiresAt = patch.expiresAt !== undefined
        ? (patch.expiresAt ? this.normalizeTimestamp(patch.expiresAt, 'expiresAt') : null)
        : existing.expiresAt;
      if ((scope === 'session' || scope === 'temporary') && !sessionId) {
        throw new Error('Memória de sessão ou temporária exige sessionId.');
      }
      if (scope === 'temporary' && !expiresAt) throw new Error('Memória temporária exige expiresAt.');
      if (validFrom && expiresAt && Date.parse(expiresAt) <= Date.parse(validFrom)) {
        throw new Error('expiresAt precisa ser posterior a validFrom.');
      }
      const nextSensitivity = patch.sensitivity ?? existing.sensitivity;
      if (this.sensitivityRank(nextSensitivity) < this.sensitivityRank(existing.sensitivity)) {
        throw new Error('A classificação de sensibilidade não pode ser reduzida por atualização genérica; use a operação explícita de alteração.');
      }
      if (SENSITIVE_MEMORY_PATTERN.test(nextContent) && nextSensitivity !== 'restricted') {
        throw new Error('Conteúdo potencialmente sensível não será armazenado como memória comum.');
      }
      const now = new Date().toISOString();
      const importance = patch.importance === undefined
        ? existing.importance : Math.min(10, Math.max(1, Math.round(patch.importance)));
      const confidence = patch.confidence === undefined
        ? existing.confidence : Math.min(1, Math.max(0, patch.confidence));
      const sourceType = patch.sourceType ?? existing.sourceType;
      const sourceRef = patch.sourceRef !== undefined ? patch.sourceRef : existing.sourceRef;
      const contentChanged = nextKey !== existing.key || nextContent !== existing.content || nextCategory !== existing.category;

      if (contentChanged && existing.status === 'active') {
        const duplicate = this.db.prepare(`SELECT * FROM memory_facts WHERE category = ? AND key = ?
          AND content = ? AND scope = ? AND COALESCE(session_id, '') = COALESCE(?, '')
          AND status = 'pending_confirmation' ORDER BY updated_at DESC LIMIT 1`)
          .get(nextCategory, nextKey, nextContent, scope, sessionId) as Record<string, unknown> | undefined;
        if (duplicate) return this.mapFactRow(duplicate);
        if (patch.userConfirmed === true && !existing.userConfirmed) {
          throw new Error('Uma alteração de conteúdo precisa ser confirmada pelo endpoint de confirmação após a criação da proposta.');
        }
        const candidateId = `mem_${crypto.randomUUID()}`;
        this.db.prepare(`INSERT INTO memory_facts (
          id, category, key, content, source_model, importance, active, created_at, updated_at,
          scope, session_id, source_type, source_ref, confidence, user_confirmed, status,
          valid_from, expires_at, sensitivity
        ) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, 0, 'pending_confirmation', ?, ?, ?)`)
          .run(candidateId, nextCategory, nextKey, nextContent, existing.sourceModel, importance,
            now, now, scope, sessionId, sourceType, sourceRef, confidence, validFrom, expiresAt, nextSensitivity);
        this.db.prepare(`INSERT OR IGNORE INTO memory_relations (from_fact_id, to_fact_id, relation_type, created_at)
          VALUES (?, ?, 'contradicts', ?)`).run(candidateId, id, now);
        this.recordEvent(candidateId, 'conflict_detected', null,
          { content: nextContent, replaces: id }, sourceType);
        const candidate = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(candidateId) as Record<string, unknown>;
        return this.mapFactRow(candidate);
      }

      if (contentChanged && existing.status === 'pending_confirmation') {
        if (patch.userConfirmed === true) {
          throw new Error('Use o endpoint de confirmação para aprovar uma proposta pendente.');
        }
        this.db.prepare(`UPDATE memory_facts SET category = ?, key = ?, content = ?, importance = ?, updated_at = ?,
          scope = ?, session_id = ?, source_type = ?, source_ref = ?, confidence = ?, valid_from = ?, expires_at = ?,
          sensitivity = ? WHERE id = ?`).run(nextCategory, nextKey, nextContent, importance, now,
            scope, sessionId, sourceType, sourceRef, confidence, validFrom, expiresAt, nextSensitivity, id);
        const revisedCandidate = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown>;
        this.recordEvent(id, 'updated', oldValue, this.factSnapshot(revisedCandidate), 'admin');
        return this.mapFactRow(revisedCandidate);
      }

      if (contentChanged) {
        throw new Error('Memórias substituídas ou rejeitadas não podem ser editadas; crie uma nova memória.');
      }
      if (patch.userConfirmed === true && !existing.userConfirmed) {
        throw new Error('Use o endpoint de confirmação para aprovar uma proposta pendente.');
      }

      this.db.prepare(`UPDATE memory_facts SET
        importance = ?, active = ?, updated_at = ?, scope = ?, session_id = ?, source_type = ?, source_ref = ?,
        confidence = ?, user_confirmed = ?, valid_from = ?, expires_at = ?, sensitivity = ? WHERE id = ?`).run(
          importance,
          patch.active === undefined ? (existing.active ? 1 : 0) : patch.active ? 1 : 0,
          now, scope, sessionId, sourceType, sourceRef, confidence,
          patch.userConfirmed === undefined ? (existing.userConfirmed ? 1 : 0) : patch.userConfirmed ? 1 : 0,
          validFrom, expiresAt, nextSensitivity, id,
        );
      const updated = this.db.prepare('SELECT * FROM memory_facts WHERE id = ?').get(id) as Record<string, unknown>;
      this.recordEvent(id, 'updated', oldValue, this.factSnapshot(updated), 'admin');
      return this.mapFactRow(updated);
    });
    return transaction.immediate();
  }

  deleteFact(id: string): boolean {
    const result = this.db.prepare(`DELETE FROM memory_facts WHERE id = ?`).run(id);
    return result.changes > 0;
  }

  extractExplicitMemoryDirectives(
    prompt: string,
    sourceModel: string | null,
  ): MemoryFact[] {
    const extracted: MemoryFact[] = [];
    const lines = prompt
      .split(/\n+/)
      .map((l) => l.trim())
      .filter(Boolean);

    for (const line of lines) {
      for (const pattern of MEMORY_DIRECTIVE_PATTERNS) {
        const match = line.match(pattern);
        if (match && match[1]) {
          const statement = match[1].replace(/[.]+$/, '').trim();
          if (statement.length >= 4 && !SENSITIVE_MEMORY_PATTERN.test(statement)) {
            const slug = statement
              .toLowerCase()
              .replace(/[^a-z0-9\u00c0-\u017f]+/g, '_')
              .replace(/^_+|_+$/g, '')
              .slice(0, 42);
            const fact = this.upsertFact({
              category: 'preference',
              key: `diretriz_${slug || Date.now()}`,
              content: statement,
              sourceModel,
              importance: 8,
              active: true,
              scope: 'long_term',
              sourceType: 'user_explicit',
              confidence: 1,
              userConfirmed: true,
            });
            extracted.push(fact);
          }
          break;
        }
      }
    }

    return extracted;
  }

  listSessions(): SessionRecord[] {
    const rows = this.db
      .prepare(
        `SELECT s.*, COUNT(m.id) as message_count
         FROM sessions s
         LEFT JOIN messages m ON m.session_id = s.id
         GROUP BY s.id
         ORDER BY s.updated_at DESC`,
      )
      .all() as Array<Record<string, unknown>>;

    return rows.map((r) => this.mapSessionRow(r));
  }

  getSession(id: string): SessionRecord | null {
    const row = this.db
      .prepare(
        `SELECT s.*, COUNT(m.id) as message_count
         FROM sessions s
         LEFT JOIN messages m ON m.session_id = s.id
         WHERE s.id = ?
         GROUP BY s.id`,
      )
      .get(id) as Record<string, unknown> | undefined;

    return row ? this.mapSessionRow(row) : null;
  }

  createSession(title?: string, activeModelOverride?: string | null): SessionRecord {
    const id = `ses_${crypto.randomUUID()}`;
    const now = new Date().toISOString();
    const cleanTitle = (title?.trim() || 'Nova Sessão Capri').slice(0, 120);

    this.db
      .prepare(
        `INSERT INTO sessions (id, title, active_model_override, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?)`,
      )
      .run(id, cleanTitle, activeModelOverride ?? null, now, now);

    return this.getSession(id)!;
  }

  ensureSession(sessionId?: string): SessionRecord {
    if (sessionId) {
      const existing = this.getSession(sessionId);
      if (existing) return existing;
    }
    const existingList = this.listSessions();
    if (existingList.length > 0 && !sessionId) {
      return existingList[0];
    }
    return this.createSession(sessionId ? `Sessão ${sessionId.slice(0, 16)}` : 'Sessão Principal — Capri Core');
  }

  updateSession(
    id: string,
    patch: Partial<{ title: string; activeModelOverride: string | null }>,
  ): SessionRecord | null {
    const existing = this.getSession(id);
    if (!existing) return null;
    const now = new Date().toISOString();

    this.db
      .prepare(
        `UPDATE sessions SET title = ?, active_model_override = ?, updated_at = ? WHERE id = ?`,
      )
      .run(
        patch.title !== undefined ? patch.title.trim().slice(0, 120) : existing.title,
        patch.activeModelOverride !== undefined
          ? patch.activeModelOverride
          : existing.activeModelOverride,
        now,
        id,
      );

    return this.getSession(id);
  }

  deleteSession(id: string): boolean {
    const res = this.db.prepare(`DELETE FROM sessions WHERE id = ?`).run(id);
    return res.changes > 0;
  }

  getSessionMessages(sessionId: string, limit = 40): SessionMessage[] {
    const rows = this.db
      .prepare(
        `SELECT * FROM (
           SELECT * FROM messages WHERE session_id = ? ORDER BY created_at DESC LIMIT ?
         ) ORDER BY created_at ASC`,
      )
      .all(sessionId, limit) as Array<Record<string, unknown>>;

    return rows.map((r) => this.mapMessageRow(r));
  }

  addMessage(input: {
    sessionId: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    modelId?: string | null;
    provider?: ProviderId | null;
    intent?: IntentCategory | null;
    traceId?: string | null;
  }): SessionMessage {
    const id = `msg_${crypto.randomUUID()}`;
    const now = new Date().toISOString();

    this.db
      .prepare(
        `INSERT INTO messages (
          id, session_id, role, content, model_id, provider, intent, trace_id, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        id,
        input.sessionId,
        input.role,
        input.content,
        input.modelId ?? null,
        input.provider ?? null,
        input.intent ?? null,
        input.traceId ?? null,
        now,
      );

    this.db
      .prepare(`UPDATE sessions SET updated_at = ? WHERE id = ?`)
      .run(now, input.sessionId);

    const row = this.db
      .prepare(`SELECT * FROM messages WHERE id = ?`)
      .get(id) as Record<string, unknown>;
    return this.mapMessageRow(row);
  }

  getRelatedFactIds(id: string): string[] {
    return (this.db.prepare(`SELECT CASE WHEN from_fact_id = ? THEN to_fact_id ELSE from_fact_id END AS related_id
      FROM memory_relations WHERE (from_fact_id = ? OR to_fact_id = ?)
        AND relation_type IN ('related_to', 'derived_from')`).all(id, id, id) as Array<{ related_id: string }>)
      .map((row) => row.related_id);
  }

  markFactsAccessed(ids: string[], at: string): void {
    if (!ids.length) return;
    const update = this.db.prepare('UPDATE memory_facts SET last_accessed_at = ? WHERE id = ?');
    const transaction = this.db.transaction(() => { for (const id of ids) update.run(at, id); });
    transaction();
  }

  relateFacts(fromFactId: string, toFactId: string, relationType: 'related_to' | 'contradicts' | 'supersedes' | 'derived_from'): void {
    if (fromFactId === toFactId) throw new Error('Uma memória não pode se relacionar consigo mesma.');
    const exists = this.db.prepare('SELECT COUNT(*) AS n FROM memory_facts WHERE id IN (?, ?)').get(fromFactId, toFactId) as { n: number };
    if (exists.n !== 2) throw new Error('As duas memórias precisam existir para criar uma relação.');
    this.db.prepare(`INSERT OR IGNORE INTO memory_relations (from_fact_id, to_fact_id, relation_type, created_at)
      VALUES (?, ?, ?, ?)`).run(fromFactId, toFactId, relationType, new Date().toISOString());
  }

  getFactHistory(id: string): Array<{ eventType: string; oldValue: string | null; newValue: string | null; actorType: string; createdAt: string }> {
    return (this.db.prepare(`SELECT event_type, old_value_json, new_value_json, actor_type, created_at
      FROM memory_events WHERE memory_fact_id = ? ORDER BY created_at DESC`).all(id) as Array<Record<string, unknown>>)
      .map((row) => ({ eventType: String(row.event_type), oldValue: row.old_value_json ? String(row.old_value_json) : null,
        newValue: row.new_value_json ? String(row.new_value_json) : null, actorType: String(row.actor_type), createdAt: String(row.created_at) }));
  }

  private mapFactRow(row: Record<string, unknown>): MemoryFact {
    return {
      id: String(row.id),
      category: row.category as MemoryFact['category'],
      key: String(row.key),
      content: String(row.content),
      sourceModel: row.source_model ? String(row.source_model) : null,
      importance: Number(row.importance),
      active: Number(row.active) === 1,
      scope: String(row.scope ?? 'long_term') as MemoryFact['scope'],
      sessionId: row.session_id ? String(row.session_id) : null,
      sourceType: String(row.source_type ?? 'legacy') as MemoryFact['sourceType'],
      sourceRef: row.source_ref ? String(row.source_ref) : null,
      confidence: Number(row.confidence ?? 0.65),
      userConfirmed: Number(row.user_confirmed ?? 0) === 1,
      status: String(row.status ?? 'active') as MemoryFact['status'],
      validFrom: row.valid_from ? String(row.valid_from) : null,
      expiresAt: row.expires_at ? String(row.expires_at) : null,
      lastAccessedAt: row.last_accessed_at ? String(row.last_accessed_at) : null,
      supersededBy: row.superseded_by ? String(row.superseded_by) : null,
      sensitivity: String(row.sensitivity ?? 'normal') as MemoryFact['sensitivity'],
      createdAt: String(row.created_at),
      updatedAt: String(row.updated_at),
    };
  }

  private mapSessionRow(row: Record<string, unknown>): SessionRecord {
    return {
      id: String(row.id),
      title: String(row.title),
      activeModelOverride: row.active_model_override ? String(row.active_model_override) : null,
      messageCount: Number(row.message_count ?? 0),
      createdAt: String(row.created_at),
      updatedAt: String(row.updated_at),
    };
  }

  private mapMessageRow(row: Record<string, unknown>): SessionMessage {
    return {
      id: String(row.id),
      sessionId: String(row.session_id),
      role: row.role as SessionMessage['role'],
      content: String(row.content),
      modelId: row.model_id ? String(row.model_id) : null,
      provider: row.provider ? (String(row.provider) as ProviderId) : null,
      intent: row.intent ? (String(row.intent) as IntentCategory) : null,
      traceId: row.trace_id ? String(row.trace_id) : null,
      createdAt: String(row.created_at),
    };
  }
}
