import type { ConversationTurn } from '../adapters/base.ts';

export interface ContextBudgetResult {
  history: ConversationTurn[];
  selectedMemory: Array<{ id: string; line: string; score: number }>;
  estimatedInputTokens: number;
  reservedOutputTokens: number;
  safetyMarginTokens: number;
  omittedMemoryCount: number;
  omittedHistoryCount: number;
  currentPromptPreserved: true;
  estimationMethod: 'conservative_chars_div_3';
}

/** Heuristic only: Latin text is grouped at 3 code points/token; non-Latin code points count individually. Not a provider tokenizer. */
export function estimateConservativeTokens(value: string): number {
  let latinLikeCodePoints = 0;
  let denseCodePoints = 0;
  for (const character of value) {
    const codePoint = character.codePointAt(0) ?? 0;
    if (codePoint <= 0x024f || (codePoint >= 0x0300 && codePoint <= 0x036f)) latinLikeCodePoints++;
    else denseCodePoints++;
  }
  return Math.ceil(latinLikeCodePoints / 3 + denseCodePoints);
}

export function applyGlobalContextBudget(input: {
  maxContextTokens: number;
  systemBase: string;
  customSystemPrompt?: string;
  currentPrompt: string;
  memoryCandidates: Array<{ id: string; line: string; score: number }>;
  recentHistory: ConversationTurn[];
}): ContextBudgetResult {
  const maxContextTokens = Math.max(1024, Math.floor(input.maxContextTokens));
  const reservedOutputTokens = Math.min(4096, Math.max(512, Math.ceil(maxContextTokens * 0.15)));
  const safetyMarginTokens = Math.ceil(maxContextTokens * 0.10);
  const inputLimit = maxContextTokens - reservedOutputTokens - safetyMarginTokens;
  const mandatory = [input.systemBase, input.customSystemPrompt?.trim() ?? ''].filter(Boolean).join('\n\n');
  const mandatoryTokens = estimateConservativeTokens(mandatory) + estimateConservativeTokens(input.currentPrompt);
  if (mandatoryTokens > inputLimit) {
    throw new Error(`A instrução obrigatória e a mensagem atual excedem o orçamento estimado do modelo (${mandatoryTokens}/${inputLimit} tokens). A mensagem atual foi preservada; reduza o texto ou selecione um modelo com contexto maior.`);
  }

  let remaining = inputLimit - mandatoryTokens;
  const memoryAllocation = Math.floor(remaining * 0.42);
  const selectedMemory: ContextBudgetResult['selectedMemory'] = [];
  let memoryUsed = 0;
  for (const item of input.memoryCandidates) {
    const cost = estimateConservativeTokens(item.line);
    if (memoryUsed + cost <= memoryAllocation) {
      selectedMemory.push(item);
      memoryUsed += cost;
    }
  }

  const historyAllowance = remaining - memoryUsed;
  const history: ConversationTurn[] = [];
  let historyUsed = 0;
  for (const turn of [...input.recentHistory].reverse()) {
    const cost = estimateConservativeTokens(turn.content) + 4;
    if (historyUsed + cost <= historyAllowance) {
      history.unshift(turn);
      historyUsed += cost;
    } else {
      break;
    }
  }
  remaining -= memoryUsed + historyUsed;
  if (remaining > 0) {
    for (const item of input.memoryCandidates) {
      if (selectedMemory.some((selected) => selected.id === item.id)) continue;
      const cost = estimateConservativeTokens(item.line);
      if (cost <= remaining) {
        selectedMemory.push(item);
        memoryUsed += cost;
        remaining -= cost;
      }
    }
  }

  const composeSystem = () => [mandatory,
    selectedMemory.length ? `Memória relevante compartilhada:\n${selectedMemory.map((item) => item.line).join('\n')}` : '',
  ].filter(Boolean).join('\n\n');
  const estimate = () => Math.ceil((estimateConservativeTokens(composeSystem())
    + estimateConservativeTokens(input.currentPrompt)
    + history.reduce((total, turn) => total + estimateConservativeTokens(turn.content) + 4, 0)) * 1.08);

  let estimatedInputTokens = estimate();
  // Trim low-ranked memory first, then oldest history. The current prompt is immutable.
  while (estimatedInputTokens > inputLimit && selectedMemory.length) {
    selectedMemory.pop();
    estimatedInputTokens = estimate();
  }
  while (estimatedInputTokens > inputLimit && history.length) {
    history.shift();
    estimatedInputTokens = estimate();
  }
  if (estimatedInputTokens > inputLimit) {
    throw new Error('Não foi possível ajustar o contexto sem remover a mensagem atual.');
  }

  return {
    history,
    selectedMemory,
    estimatedInputTokens,
    reservedOutputTokens,
    safetyMarginTokens,
    omittedMemoryCount: input.memoryCandidates.length - selectedMemory.length,
    omittedHistoryCount: input.recentHistory.length - history.length,
    currentPromptPreserved: true,
    estimationMethod: 'conservative_chars_div_3',
  };
}
