import type { ComplexityLevel, IntentCategory, IntentClassification } from '../../core/types.ts';

interface IntentRule {
  intent: IntentCategory;
  patterns: RegExp[];
  baseWeight: number;
}

const INTENT_RULES: IntentRule[] = [
  {
    intent: 'coding',
    baseWeight: 3,
    patterns: [
      /\b(c[oó]digo|programar|programa[cç][aã]o|fun[cç][aã]o|classe|algoritmo|debug|refator|typescript|javascript|python|java|rust|go|sql|sqlite|react|node\.?js|express|api|endpoint|regex|docker|git|teste unit[aá]rio|bug|erro de compila[cç][aã]o|stack\s*trace)\b/i,
      /```[\s\S]*```/,
      /\b(const|let|function|import|export|async|await|SELECT\s+.+\s+FROM)\b/,
    ],
  },
  {
    intent: 'complex_reasoning',
    baseWeight: 3,
    patterns: [
      /\b(arquitetura|trade-?off|estrat[eé]gia|analise\s+profunda|racioc[ií]nio|causa\s+raiz|prova\s+matem[aá]tica|teorema|otimiza[cç][aã]o|planejamento\s+estrat[eé]gico|sistema\s+distribu[ií]do|seguran[cç]a|auditoria|compare\s+em\s+detalhes|pr[oó]s\s+e\s+contras)\b/i,
      /\b(why|how\s+should\s+we\s+architect|root\s+cause|system\s+design|mathematical|deduce|step[\s-]by[\s-]step\s+analysis)\b/i,
    ],
  },
  {
    intent: 'document_analysis',
    baseWeight: 2.5,
    patterns: [
      /\b(analise\s+(este|esse|o)\s+(documento|texto|log|contrato|relat[oó]rio|json|csv)|extraia\s+dados|inspecione\s+o\s+documento|revise\s+o\s+contrato|parse|estrutura\s+dos\s+dados)\b/i,
      /\b(analyze\s+this\s+(document|text|log|report|contract)|extract\s+fields)\b/i,
    ],
  },
  {
    intent: 'research',
    baseWeight: 2.2,
    patterns: [
      /\b(pesquise|investigue|compare\s+(ferramentas|modelos|frameworks|provedores)|estado\s+da\s+arte|benchmark|quais\s+s[aã]o\s+as\s+diferen[cç]as|levantamento|explique\s+o\s+conceito)\b/i,
      /\b(research|compare\s+options|literature|overview\s+of|state\s+of\s+the\s+art)\b/i,
    ],
  },
  {
    intent: 'content_generation',
    baseWeight: 2,
    patterns: [
      /\b(escreva|redija|crie\s+(um|uma)\s+(texto|artigo|e-?mail|post|roteiro|documenta[cç][aã]o|readme|proposta|mensagem)|gere\s+um\s+rascunho|copywriting)\b/i,
      /\b(write\s+a|draft\s+an?\s+(email|article|post|doc|readme)|compose)\b/i,
    ],
  },
  {
    intent: 'quick_summary',
    baseWeight: 2.4,
    patterns: [
      /\b(resuma|resumo|sintetize|em\s+t[oó]picos|tl;?dr|em\s+uma\s+frase|traduza|traduzir|defina\s+rapidamente)\b/i,
      /\b(summarize|summary|tl;?dr|bullet\s+points|translate)\b/i,
    ],
  },
];

const INTENT_LABELS: Record<IntentCategory, string> = {
  general_chat: 'Conversa Geral',
  complex_reasoning: 'Raciocínio Complexo',
  coding: 'Programação',
  research: 'Pesquisa e Comparação',
  document_analysis: 'Análise de Documentos',
  content_generation: 'Geração de Conteúdo',
  quick_summary: 'Resumo Rápido',
};

export class IntentClassifier {
  classify(prompt: string): IntentClassification {
    const clean = prompt.trim();
    const scores = new Map<IntentCategory, number>();
    const signals: string[] = [];

    for (const rule of INTENT_RULES) {
      let ruleHits = 0;
      for (const regex of rule.patterns) {
        const match = clean.match(regex);
        if (match) {
          ruleHits += 1;
          signals.push(`${rule.intent}:${match[0].slice(0, 32)}`);
        }
      }
      if (ruleHits > 0) {
        scores.set(rule.intent, ruleHits * rule.baseWeight);
      }
    }

    if (clean.length > 1200 && !scores.has('coding')) {
      scores.set('document_analysis', (scores.get('document_analysis') ?? 0) + 2.5);
      signals.push('length:>1200_chars');
    }

    let bestIntent: IntentCategory = 'general_chat';
    let bestScore = 0;

    for (const [intent, score] of scores.entries()) {
      if (score > bestScore) {
        bestScore = score;
        bestIntent = intent;
      }
    }

    const complexity = this.estimateComplexity(clean, bestIntent, bestScore);
    const confidence =
      bestScore === 0
        ? 0.72
        : Math.min(0.96, Number((0.68 + Math.min(bestScore, 8) * 0.035).toFixed(2)));

    const reasoning =
      bestScore === 0
        ? `Solicitação curta ou conversacional sem marcadores técnicos específicos; classificada como ${INTENT_LABELS[bestIntent]} (${complexity}).`
        : `Classificada como ${INTENT_LABELS[bestIntent]} com complexidade ${this.complexityLabel(complexity)} pelos sinais detectados (${signals.slice(0, 3).join(', ')}).`;

    return {
      intent: bestIntent,
      complexity,
      confidence,
      reasoning,
      signals: signals.slice(0, 6),
    };
  }

  private estimateComplexity(
    prompt: string,
    intent: IntentCategory,
    score: number,
  ): ComplexityLevel {
    if (intent === 'complex_reasoning') {
      return 'high';
    }
    if (intent === 'coding' && (prompt.length > 260 || score >= 6)) {
      return 'high';
    }
    if (intent === 'document_analysis' && prompt.length > 800) {
      return 'high';
    }
    if (intent === 'quick_summary' && prompt.length < 350) {
      return 'low';
    }
    if (intent === 'general_chat' && prompt.length < 180) {
      return 'low';
    }
    if (prompt.length > 700 || /\b(etapas|crit[eé]rios|detalhado|completo|passo a passo)\b/i.test(prompt)) {
      return 'high';
    }
    if (intent === 'coding' || intent === 'research' || intent === 'document_analysis') {
      return 'medium';
    }
    return prompt.length > 240 ? 'medium' : 'low';
  }

  private complexityLabel(level: ComplexityLevel): string {
    switch (level) {
      case 'low':
        return 'baixa';
      case 'medium':
        return 'média';
      case 'high':
        return 'alta';
    }
  }
}
