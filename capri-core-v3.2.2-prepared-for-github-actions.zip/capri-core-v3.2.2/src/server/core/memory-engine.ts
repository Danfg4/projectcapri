import type Database from 'better-sqlite3';
import type { MemoryFact, SessionMessage, SessionRecord } from '../../core/types.ts';
import type { ConversationTurn } from '../adapters/base.ts';
import { SharedMemoryManager } from './shared-memory.ts';
import { applyGlobalContextBudget, estimateConservativeTokens } from './context-budget.ts';
import { MemoryAccessPolicy } from './memory-policy.ts';
import { MemoryRelationExpander } from './memory-relations.ts';


const SYSTEM_BASE_INSTRUCTION = [
  'Você é o núcleo de inteligência Capri Core, uma assistente pessoal avançada com arquitetura multi-LLM.',
  'Responda com precisão técnica, clareza e objetividade no idioma do usuário.',
  'Use a memória como contexto auxiliar; respeite a indicação de confiança e confirmação e não trate inferências como fatos confirmados.',
  'A memória fornecida é compartilhada pelo núcleo e não pertence a um provedor específico.',
  'Memórias private e restricted são confidenciais e nunca fazem parte do contexto enviado ao provedor.',
].join('\n\n');

export interface PortableMemoryContext {
  systemInstruction: string;
  history: ConversationTurn[];
  factsCount: number;
  messagesCount: number;
  estimatedInputTokens: number;
  maxContextTokens: number;
  reservedOutputTokens: number;
  safetyMarginTokens: number;
  omittedMemoryCount: number;
  omittedHistoryCount: number;
  estimationMethod: 'conservative_chars_div_3';
  currentPromptPreserved: true;
}

/** Central memory boundary: retrieval, privacy filtering and context assembly live here. */
export class MemoryEngine {
  readonly store: SharedMemoryManager;
  readonly accessPolicy: MemoryAccessPolicy;
  readonly relationExpander: MemoryRelationExpander;

  constructor(db: Database.Database) {
    this.store = new SharedMemoryManager(db);
    this.accessPolicy = new MemoryAccessPolicy();
    this.relationExpander = new MemoryRelationExpander(this.store, this.accessPolicy);
  }

  // Compatibility surface for existing core callers and integrations.
  listFacts(activeOnly = false): MemoryFact[] { return this.store.listFacts(activeOnly); }
  upsertFact(input: Parameters<SharedMemoryManager['upsertFact']>[0]): MemoryFact { return this.store.upsertFact(input); }
  updateFact(id: string, patch: Parameters<SharedMemoryManager['updateFact']>[1]): MemoryFact | null { return this.store.updateFact(id, patch); }
  confirmFact(id: string): MemoryFact | null { return this.store.confirmFact(id); }
  rejectFact(id: string): MemoryFact | null { return this.store.rejectFact(id); }
  changeSensitivity(id: string, sensitivity: MemoryFact['sensitivity'], confirmDowngrade = false): MemoryFact | null {
    return this.store.changeSensitivity(id, sensitivity, confirmDowngrade);
  }
  deleteFact(id: string): boolean { return this.store.deleteFact(id); }
  extractExplicitMemoryDirectives(prompt: string, sourceModel: string | null): MemoryFact[] {
    return this.store.extractExplicitMemoryDirectives(prompt, sourceModel);
  }
  createSession(title?: string, activeModelOverride?: string | null): SessionRecord {
    return this.store.createSession(title, activeModelOverride);
  }
  ensureSession(id?: string): SessionRecord { return this.store.ensureSession(id); }
  listSessions(): SessionRecord[] { return this.store.listSessions(); }
  getSession(id: string): SessionRecord | null { return this.store.getSession(id); }
  updateSession(id: string, patch: Parameters<SharedMemoryManager['updateSession']>[1]): SessionRecord | null {
    return this.store.updateSession(id, patch);
  }
  deleteSession(id: string): boolean { return this.store.deleteSession(id); }
  getSessionMessages(id: string, limit?: number): SessionMessage[] { return this.store.getSessionMessages(id, limit); }
  addMessage(input: Parameters<SharedMemoryManager['addMessage']>[0]): SessionMessage { return this.store.addMessage(input); }
  relateFacts(from: string, to: string, relation: Parameters<SharedMemoryManager['relateFacts']>[2]): void {
    this.store.relateFacts(from, to, relation);
  }
  getFactHistory(id: string): ReturnType<SharedMemoryManager['getFactHistory']> { return this.store.getFactHistory(id); }

  /** Minimum required prompt footprint used by Smart Router before optional memory/history allocation. */
  estimateMandatoryContextTokens(customSystemPrompt: string | undefined, prompt: string): number {
    const mandatory = [SYSTEM_BASE_INSTRUCTION, customSystemPrompt?.trim() ?? ''].filter(Boolean).join('\n\n');
    return Math.ceil((estimateConservativeTokens(mandatory) + estimateConservativeTokens(prompt)) * 1.08);
  }

  buildPortableContext(
    sessionId: string,
    customSystemPrompt?: string,
    prompt = '',
    options: { maxContextTokens?: number; historyLimit?: number } = {},
  ): PortableMemoryContext {
    const now = new Date().toISOString();
    // Store query is canonical; the engine applies session and outbound privacy policy.
    const eligibleFacts = this.store.listRecoverableFacts(sessionId, now).filter((fact) =>
      this.accessPolicy.canSendToExternalProvider(fact)
      && this.accessPolicy.isRecoverableInSession(fact, sessionId, now)
    );
    const queryTerms = this.tokenize(prompt);
    const scoreFact = (fact: MemoryFact, expanded = false): number => {
      const terms = this.tokenize(`${fact.key} ${fact.content} ${fact.category}`);
      const overlap = queryTerms.length ? queryTerms.filter((term) => terms.includes(term)).length / queryTerms.length : 0;
      const ageDays = Math.max(0, (Date.now() - Date.parse(fact.updatedAt)) / 86400000);
      const recency = 1 / (1 + ageDays / 30);
      const scopeBonus = fact.scope === 'session' ? 0.10 : fact.scope === 'temporary' ? 0.06 : 0;
      const categoryBonus = fact.category === 'preference' ? 0.08 : 0;
      const confirmationBonus = fact.userConfirmed ? 0.05 : 0;
      return overlap * 0.56 + (fact.importance / 10) * 0.16 + fact.confidence * 0.14
        + recency * 0.08 + scopeBonus + categoryBonus + confirmationBonus - (expanded ? 0.10 : 0);
    };

    const roots = eligibleFacts.map((fact) => {
      const factTerms = this.tokenize(`${fact.key} ${fact.content} ${fact.category}`);
      const overlaps = queryTerms.some((term) => factTerms.includes(term));
      const highValuePreference = fact.category === 'preference' && fact.importance >= 8 && fact.userConfirmed;
      return { fact, score: scoreFact(fact), relevant: queryTerms.length === 0 || overlaps || highValuePreference };
    }).filter(({ relevant }) => relevant)
      .sort((a, b) => b.score - a.score || b.fact.importance - a.fact.importance);
    const candidates = new Map<string, { fact: MemoryFact; score: number }>();
    for (const item of roots) candidates.set(item.fact.id, item);

    const relatedFacts = this.relationExpander.expand(roots, sessionId, now, scoreFact, 8, 2);
    for (const item of relatedFacts) candidates.set(item.fact.id, item);

    const ranked = [...candidates.values()].sort((a, b) => b.score - a.score || b.fact.importance - a.fact.importance);
    const memoryCandidates = ranked.map(({ fact, score }) => ({
      id: fact.id,
      score,
      line: `- [${fact.category}; ${fact.scope}; confiança ${fact.confidence.toFixed(2)}${fact.userConfirmed ? '; confirmado' : '; não confirmado'}] ${fact.key}: ${fact.content}`,
    }));
    const systemBase = SYSTEM_BASE_INSTRUCTION;
    const sensitiveContents = this.store.listSensitiveFactContents().sort((a, b) => b.length - a.length);
    const recentHistory = this.store.getSessionMessages(sessionId, options.historyLimit ?? 40)
      .filter((message) => message.role === 'user' || message.role === 'assistant')
      .map((message) => {
        let content = message.content;
        for (const sensitive of sensitiveContents) {
          const escaped = sensitive.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          content = content.replace(new RegExp(escaped, 'giu'), '[conteúdo de memória privada/restrita omitido]');
        }
        return { role: message.role as 'user' | 'assistant', content, modelId: message.modelId };
      });
    const maxContextTokens = options.maxContextTokens ?? 32768;
    const budget = applyGlobalContextBudget({
      maxContextTokens,
      systemBase,
      customSystemPrompt,
      currentPrompt: prompt,
      memoryCandidates,
      recentHistory,
    });
    const selectedIds = budget.selectedMemory.map((item) => item.id);
    if (selectedIds.length) this.store.markFactsAccessed(selectedIds, now);
    const systemInstruction = [
      systemBase,
      customSystemPrompt?.trim() ? `Instruções adicionais do usuário:\n${customSystemPrompt.trim()}` : '',
      budget.selectedMemory.length ? `Memória relevante compartilhada:\n${budget.selectedMemory.map((item) => item.line).join('\n')}` : '',
    ].filter(Boolean).join('\n\n');
    return {
      systemInstruction,
      history: budget.history,
      factsCount: budget.selectedMemory.length,
      messagesCount: budget.history.length,
      estimatedInputTokens: budget.estimatedInputTokens,
      maxContextTokens,
      reservedOutputTokens: budget.reservedOutputTokens,
      safetyMarginTokens: budget.safetyMarginTokens,
      omittedMemoryCount: budget.omittedMemoryCount,
      omittedHistoryCount: budget.omittedHistoryCount,
      estimationMethod: budget.estimationMethod,
      currentPromptPreserved: true,
    };
  }

  private tokenize(value: string): string[] {
    return [...new Set(value.toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .split(/[^a-z0-9]+/).filter((part) => part.length >= 3))];
  }
}
