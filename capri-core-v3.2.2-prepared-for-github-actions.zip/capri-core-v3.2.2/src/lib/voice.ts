/**
 * Browser-native speech output. This deliberately has no dependency on an LLM,
 * provider API key, server endpoint, or paid speech service.
 */
export function isSpeechSynthesisAvailable(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window &&
    typeof SpeechSynthesisUtterance !== 'undefined';
}

export function stopSpeaking(): void {
  if (isSpeechSynthesisAvailable()) {
    window.speechSynthesis.cancel();
  }
}

export function speakText(text: string, language = 'pt-BR', onEnd?: () => void): boolean {
  const cleanText = text.trim();
  if (!cleanText || !isSpeechSynthesisAvailable()) return false;

  stopSpeaking();
  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.lang = language;
  utterance.rate = 1;
  utterance.pitch = 1;
  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = onEnd;
  }
  window.speechSynthesis.speak(utterance);
  return true;
}
