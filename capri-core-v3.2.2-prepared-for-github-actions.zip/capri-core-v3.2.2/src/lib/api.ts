import type {
  HealthResponse,
  IntentCategory,
  MemoryFact,
  ModelCapabilityTier,
  ModelWithStatus,
  OrchestrationRequest,
  OrchestrationResponse,
  ProviderId,
  ProviderSummary,
  RoutingTrace,
  SessionMessage,
  SessionRecord,
  UsageLogEntry,
  UsageSummary,
} from '../core/types.ts';

let apiTokenCache: string | null = null;
let adminTokenCache: string | null = null;

function getApiToken(admin = false): string {
  const cached = admin ? adminTokenCache : apiTokenCache;
  if (cached) return cached;
  const token = window.prompt(
    admin ? 'Informe o token administrativo (CAPRI_ADMIN_TOKEN):' : 'Informe o token de acesso (CAPRI_API_TOKEN):',
  )?.trim() ?? '';
  if (token.length >= 32) {
    if (admin) adminTokenCache = token;
    else apiTokenCache = token;
  }
  return token;
}

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const method = (init?.method ?? 'GET').toUpperCase();
  const adminRequest = ['POST', 'PATCH', 'DELETE'].includes(method)
    && !url.endsWith('/orchestrate');
  const adminAccess = adminRequest || url.includes('/export/zip');
  const token = getApiToken(adminAccess);
  if (token.length < 32) throw new Error('Token de acesso não informado ou inválido.');

  const response = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
      Authorization: `Bearer ${token}`,
    },
  });

  const data = (await response.json().catch(() => ({}))) as T & {
    error?: string | { message?: string };
  };

  if (response.status === 401 || response.status === 403) {
    if (adminAccess) adminTokenCache = null;
    else apiTokenCache = null;
  }
  if (!response.ok && response.status !== 422) {
    const errMsg =
      typeof data.error === 'string'
        ? data.error
        : data.error?.message || `Erro HTTP ${response.status}`;
    throw new Error(errMsg);
  }

  return data;
}

export const capriApi = {
  getHealth: () => requestJson<HealthResponse>('/api/v1/health'),

  orchestrate: (payload: OrchestrationRequest) =>
    requestJson<OrchestrationResponse>('/api/v1/orchestrate', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  listModels: () =>
    requestJson<{ models: ModelWithStatus[]; providers: ProviderSummary[] }>('/api/v1/models'),

  registerModel: (payload: {
    provider: ProviderId;
    modelName: string;
    displayName: string;
    envKey?: string;
    capabilityTier: ModelCapabilityTier;
    strengths: IntentCategory[];
    priority?: number;
    rpmLimit?: number;
    rpdLimit?: number;
    tpdLimit?: number;
    notes?: string;
  }) =>
    requestJson<{ model: ModelWithStatus }>('/api/v1/models', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateModel: (
    id: string,
    patch: Partial<{
      enabled: boolean;
      priority: number;
      rpmLimit: number;
      rpdLimit: number;
      tpdLimit: number;
      notes: string;
    }>,
  ) =>
    requestJson<{ model: ModelWithStatus }>(`/api/v1/models/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),

  listMemory: () => requestJson<{ facts: MemoryFact[] }>('/api/v1/memory'),

  upsertMemory: (payload: {
    category: MemoryFact['category'];
    key: string;
    content: string;
    importance?: number;
    active?: boolean;
  }) =>
    requestJson<{ fact: MemoryFact }>('/api/v1/memory', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateMemory: (
    id: string,
    patch: Partial<{
      category: MemoryFact['category'];
      key: string;
      content: string;
      importance: number;
      active: boolean;
    }>,
  ) =>
    requestJson<{ fact: MemoryFact }>(`/api/v1/memory/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),

  deleteMemory: (id: string) =>
    requestJson<{ ok: boolean }>(`/api/v1/memory/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  confirmMemory: (id: string) =>
    requestJson<{ fact: MemoryFact }>(`/api/v1/memory/${encodeURIComponent(id)}/confirm`, {
      method: 'POST',
    }),

  rejectMemory: (id: string) =>
    requestJson<{ fact: MemoryFact }>(`/api/v1/memory/${encodeURIComponent(id)}/reject`, {
      method: 'POST',
    }),

  changeMemorySensitivity: (id: string, sensitivity: MemoryFact['sensitivity'], confirmDowngrade = false) =>
    requestJson<{ fact: MemoryFact }>(`/api/v1/memory/${encodeURIComponent(id)}/sensitivity`, {
      method: 'PATCH',
      body: JSON.stringify({ sensitivity, confirmDowngrade }),
    }),

  listSessions: () => requestJson<{ sessions: SessionRecord[] }>('/api/v1/sessions'),

  createSession: (title?: string) =>
    requestJson<{ session: SessionRecord }>('/api/v1/sessions', {
      method: 'POST',
      body: JSON.stringify({ title }),
    }),

  getSessionDetail: (id: string) =>
    requestJson<{ session: SessionRecord; messages: SessionMessage[] }>(
      `/api/v1/sessions/${encodeURIComponent(id)}`,
    ),

  updateSession: (
    id: string,
    patch: Partial<{ title: string; activeModelOverride: string | null }>,
  ) =>
    requestJson<{ session: SessionRecord }>(`/api/v1/sessions/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),

  deleteSession: (id: string) =>
    requestJson<{ ok: boolean }>(`/api/v1/sessions/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }),

  getUsage: (limit = 50) =>
    requestJson<{ summary: UsageSummary; logs: UsageLogEntry[] }>(
      `/api/v1/usage?limit=${limit}`,
    ),

  listTraces: (limit = 25) =>
    requestJson<{ traces: RoutingTrace[] }>(`/api/v1/traces?limit=${limit}`),
};
