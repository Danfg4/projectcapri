import type {
  ComplexityLevel,
  IntentCategory,
  ModelAvailabilityStatus,
  ModelCapabilityTier,
  ProviderId,
} from '../core/types.ts';

export const INTENT_LABELS: Record<IntentCategory, string> = {
  general_chat: 'Conversa Geral',
  complex_reasoning: 'Raciocínio Complexo',
  coding: 'Programação',
  research: 'Pesquisa e Comparação',
  document_analysis: 'Análise de Documentos',
  content_generation: 'Geração de Conteúdo',
  quick_summary: 'Resumo Rápido',
};

export const COMPLEXITY_LABELS: Record<ComplexityLevel, string> = {
  low: 'Baixa',
  medium: 'Média',
  high: 'Alta',
};

export const TIER_LABELS: Record<ModelCapabilityTier, string> = {
  fast_economy: 'Econômico / Rápido',
  balanced: 'Equilibrado',
  deep_reasoning: 'Raciocínio Profundo',
};

export const AVAILABILITY_LABELS: Record<ModelAvailabilityStatus, string> = {
  available: 'Disponível',
  disabled: 'Desativado',
  not_configured: 'Sem chave no ambiente',
  quota_exhausted: 'Cota esgotada',
  cooldown: 'Em pausa temporária',
  unverified: 'Aguardando verificação no provedor',
  invalid_model: 'Modelo não disponível na conta',
};

export const PROVIDER_LABELS: Record<ProviderId, string> = {
  gemini: 'Google Gemini',
  groq: 'Groq Cloud',
  openai: 'OpenAI',
  anthropic: 'Anthropic Claude',
  deepseek: 'DeepSeek',
  xai: 'xAI Grok',
};

export const PROVIDER_COLORS: Record<ProviderId, string> = {
  gemini: '#F97316',
  groq: '#EC4899',
  openai: '#A855F7',
  anthropic: '#FB923C',
  deepseek: '#C084FC',
  xai: '#F472B6',
};

export function formatTimeShort(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '--:--';
  }
}

export function formatNumber(n: number | null | undefined): string {
  if (n === null || n === undefined) return '—';
  return n.toLocaleString('pt-BR');
}
