import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const testFile = path.join(root, 'tests/capri-core.test.ts');
const source = fs.readFileSync(testFile, 'utf8');
const tests = [...source.matchAll(/\bit\s*\(\s*(['"`])([\s\S]*?)\1\s*,/g)].map((m) => m[2]);
const concurrencyTestPath = path.join(root, 'tests/certification/sqlite-concurrency.test.ts');
const concurrencyWorkerPath = path.join(root, 'tests/certification/sqlite-concurrency-writer.ts');
const concurrencyTest = fs.existsSync(concurrencyTestPath) ? fs.readFileSync(concurrencyTestPath, 'utf8') : '';
const concurrencyWorker = fs.existsSync(concurrencyWorkerPath) ? fs.readFileSync(concurrencyWorkerPath, 'utf8') : '';
const groups = {
  sqlite_real_driver: /better-sqlite3/.test(source) && /SQLite em arquivo|banco legado|migração v2|migração v3/i.test(source),
  migrations_and_persistence: /migra banco legado preservando|rollback integral da migração|trilha de eventos v2 para v3|mantém fatos e mensagens após fechar e reabrir/i.test(source),
  http_and_authorization: /API REST \/api\/v1/.test(source) && /status\)\.toBe\(401\)/.test(source) && /status\)\.toBe\(403\)/.test(source),
  six_provider_stubs: /envia o mesmo contexto aos seis provedores/.test(source) && /'gemini', 'groq', 'openai', 'anthropic', 'deepseek', 'xai'/.test(source),
  privacy_normal_private_restricted: /exclui memórias private e restricted/.test(source) && /normal_context/.test(source) && /private_context/.test(source) && /restricted_context/.test(source),
  concurrency_single_connection: /serializa gravações concorrentes e evita duplicar a mesma memória/.test(source),
  concurrency_independent_connections: /spawn\(process\.execPath/.test(concurrencyTest) && /sqlite-concurrency-writer\.ts/.test(concurrencyTest) && /createDatabase\(input\.dbPath\)/.test(concurrencyWorker),
};
const expected = 40;
const supplementalConcurrencyTest = groups.concurrency_independent_connections;
const gaps = [];
if (tests.length !== expected) gaps.push(`A suíte principal contém ${tests.length} testes declarados; esperado: ${expected}.`);
for (const [key, present] of Object.entries(groups)) if (!present && key !== 'concurrency_independent_connections') gaps.push(`Cobertura ausente: ${key}.`);
if (groups.concurrency_single_connection && !groups.concurrency_independent_connections) gaps.push('Concorrência parcial: falta stress test com workers e conexões SQLite independentes.');
const report = { generatedAt:new Date().toISOString(), testFile:'tests/capri-core.test.ts', declaredTestCount:tests.length, expectedExistingTestCount:expected, supplementalConcurrencyTest, expectedTotalTests:expected + (supplementalConcurrencyTest ? 1 : 0), testTitles:tests, coverage:groups, status:gaps.length?'INCOMPLETE_BLOCKS_FUNCTIONAL_CERTIFICATION':'COVERAGE_CONTRACT_COMPLETE', gaps, note:'Este inventário é estático. Não representa aprovação ou execução de testes.' };
fs.mkdirSync(path.join(root,'certification/reports'),{recursive:true});
fs.writeFileSync(path.join(root,'certification/reports/coverage-gaps.json'),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(path.join(root,'certification/reports/coverage-gaps.md'),[
 '# Lacunas de cobertura — Capri Core v3.2.2','',`Status: **${report.status}**`,'',`Testes declarados: ${tests.length}/${expected}.`,'','## Matriz',
 ...Object.entries(groups).map(([k,v])=>`- ${k}: ${v?'presente no código-fonte (não significa aprovado)':'AUSENTE'}`),'','## Bloqueios',
 ...(gaps.length?gaps.map(g=>`- ${g}`):['- Nenhuma lacuna estática identificada.']),'',
 'O teste complementar executa quatro processos independentes contra o mesmo arquivo SQLite e verifica integridade e unicidade. Sua presença estática não representa execução/aprovação; o JUnit do workflow deve confirmar seu resultado.',''
].join('\n'));
if(gaps.length){console.error(`Coverage gate blocked: ${gaps.length} gap(s).`);process.exitCode=1;} else console.log('Coverage contract complete.');
