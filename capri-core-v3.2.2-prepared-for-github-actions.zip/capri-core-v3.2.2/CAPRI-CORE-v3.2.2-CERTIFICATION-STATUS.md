# Capri Core v3.2.2 — Estado da certificação

**Classificação: PREPARADA PARA CERTIFICAÇÃO AUTOMATIZADA — NÃO CERTIFICADA FUNCIONALMENTE.**

A atualização adiciona GitHub Actions, relatórios e documentação. Não altera a implementação do Memory Engine nem remove ou modifica os 40 testes existentes. `bun.lock` é preservado byte a byte.

## Ambiente fixado

- Bun `1.4.5` (fixado no workflow); o lockfile existente usa `lockfileVersion: 2` e `configVersion: 1`. Bun 1.4.0 introduziu o formato lockfile v2; releases anteriores não devem ser escolhidas para esse lockfile.
- `oven-sh/setup-bun` v2.2.0, `actions/checkout` v7.0.1, `actions/upload-artifact` v7.0.2.
- Runner `ubuntu-24.04`; permissões `contents: read`.

## Cobertura existente identificada

Os 40 testes existentes incluem: persistência em arquivo com better-sqlite3; migrações e rollback; API REST com autenticação 401/403; adaptadores stub para Gemini, Groq, OpenAI, Anthropic, DeepSeek e xAI; filtro de memória normal/private/restricted; uma verificação de gravações concorrentes em uma conexão; além disso, foi preparado um teste complementar com quatro processos Bun e conexões SQLite independentes.

## Teste complementar aguardando execução

O teste original de concorrência permanece preservado. Foi acrescentado `tests/certification/sqlite-concurrency.test.ts`, que lança quatro processos Bun, cada um com uma conexão `better-sqlite3` independente, grava fatos exclusivos e disputa uma chave idempotente compartilhada; ao final verifica unicidade e `PRAGMA integrity_check`. Esse teste novo ainda não foi executado neste ambiente. O workflow só o considera aprovado se o JUnit registrar sucesso na execução real. Nenhum teste foi inventado como aprovado.

## Execução local nesta entrega

O workflow não foi executado no GitHub porque esta entrega não está conectada a um repositório GitHub do usuário. A instalação, typecheck, Vitest e build não são declarados aprovados nesta etapa. A validação local cobre integridade dos pacotes, estrutura, sintaxe dos scripts e validação estática do workflow.
