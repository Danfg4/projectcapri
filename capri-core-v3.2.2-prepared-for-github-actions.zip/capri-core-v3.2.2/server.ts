import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createDefaultAdapters } from './src/server/adapters/index.ts';
import { CapriCoreOrchestrator } from './src/server/core/orchestrator.ts';
import { createDatabase } from './src/server/db/database.ts';
import { createApiRouter } from './src/server/routes/api.ts';

export function createApp(customDbPath?: string, apiToken = process.env.CAPRI_API_TOKEN, adminToken = process.env.CAPRI_ADMIN_TOKEN) {
  const db = createDatabase(customDbPath);
  const adapters = createDefaultAdapters();
  const orchestrator = new CapriCoreOrchestrator({ db, adapters });

  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.use('/api/v1', createApiRouter(orchestrator, apiToken, adminToken));

  app.use((err: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err instanceof SyntaxError && 'body' in err) {
      res.status(400).json({ error: 'JSON inválido no corpo da requisição.' });
      return;
    }
    next(err);
  });

  return { app, db, orchestrator };
}

async function startServer() {
  const port = Number(process.env.PORT ?? 3000);
  const apiToken = process.env.CAPRI_API_TOKEN;
  const adminToken = process.env.CAPRI_ADMIN_TOKEN;
  if (!apiToken || apiToken.length < 32 || !adminToken || adminToken.length < 32 || apiToken === adminToken) {
    throw new Error('Defina CAPRI_API_TOKEN e CAPRI_ADMIN_TOKEN distintos, ambos com pelo menos 32 caracteres.');
  }
  const { app } = createApp(undefined, apiToken, adminToken);
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  const host = process.env.CAPRI_HOST ?? '127.0.0.1';
  app.listen(port, host, () => {
    console.log(`[Capri Core] Servidor ativo em http://${host}:${port}`);
  });
}

const isEntrypoint =
  process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname);

if (isEntrypoint) {
  startServer().catch((err) => {
    console.error('[Capri Core] Falha ao iniciar servidor:', err);
    process.exit(1);
  });
}
